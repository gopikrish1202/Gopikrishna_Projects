/** 
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define([
    'N/ui/serverWidget', 'N/query', 'N/search', 'N/runtime', 'N/format',
    'N/render', 'N/file', 'N/url', 'N/log', 'N/redirect', 'N/record', 'N/task'
], function (serverWidget, query, search, runtime, format, render, file, url, log, redirect, record, task) {

    function onRequest(context) {
        try {
            var req = context.request;
            var res = context.response;

            // ---------------------------
            // 1. Handle GET form rendering
            // ---------------------------
            if (req.method === 'GET' && req.parameters.download !== 'T') {
                let form = serverWidget.createForm({ title: 'Actual vs AOP Dashboard' });

              

                

                // Accounting Period field
                let accountingPeriod = form.addField({
                    id: 'custpage_acc_period',
                    type: serverWidget.FieldType.SELECT,
                    label: 'Accounting Period'
                });

                // Subsidiary field
                let subsidiaryField = form.addField({
                    id: 'custpage_subsidiary',
                    type: serverWidget.FieldType.SELECT,
                    label: 'Subsidiary'
                });
                subsidiaryField.addSelectOption({ value: '', text: '' });

                // Hidden action field
                let actionField = form.addField({
                    id: 'custpage_action',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Action'
                });
                actionField.updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });

                // Override button
                form.addButton({
                    id: 'custpage_override_btn',
                    label: 'Override Data',
                    functionName: 'setActionOverride'
                });

var CHECKBOX = form.addField({
    id: 'download',
    type: serverWidget.FieldType.CHECKBOX,
    label: 'Download'
});

CHECKBOX.defaultValue = "T";  // checked by default
CHECKBOX.updateDisplayType({
    displayType: serverWidget.FieldDisplayType.HIDDEN
});



                // Inline script
                form.addField({
                    id: 'custpage_inline_script',
                    type: serverWidget.FieldType.INLINEHTML,
                    label: ' '
                }).defaultValue = `
<script>
function setActionOverride(){
    document.getElementById('custpage_action').value = 'override';
    document.forms[0].submit();
}
</script>`;


                // Department (hidden)
                let departmentField = form.addField({
                    id: 'custpage_department',
                    type: serverWidget.FieldType.MULTISELECT,
                    label: 'Department',
                    source: 'department'
                });
                departmentField.updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });

                // Populate subsidiaries
                try {
                    let customSubsSearchObj = search.create({
                        type: "customrecord_tyf_subs_hier_",
                        filters: [],
                        columns: [
                            search.createColumn({ name: "internalid", sort: search.Sort.ASC }),
                            search.createColumn({ name: "name" })
                        ]
                    });
                    let customSubsResults = customSubsSearchObj.run().getRange({ start: 0, end: 1000 });
                    if (customSubsResults.length === 0) {
                        subsidiaryField.addSelectOption({ value: '', text: 'No subsidiaries available' });
                    } else {
                        customSubsResults.forEach(result => {
                            subsidiaryField.addSelectOption({
                                value: result.getValue("internalid"),
                                text: result.getValue("name")
                            });
                        });
                    }
                } catch (e) {
                    log.error('Custom Subsidiary Search Error', e.message);
                }

                // Populate accounting periods
                let currentDate = new Date();
                let formatDate = format.format({
                    value: currentDate,
                    type: format.Type.DATE
                });

                let periodSearch = search.create({
                    type: "accountingperiod",
                    filters: [
                        ["isyear", "is", "F"], "AND",
                        ["isquarter", "is", "F"], "AND",
                        ["startdate", "onorbefore", formatDate]
                    ],
                    columns: [
                        search.createColumn({ name: "periodname" }),
                        search.createColumn({ name: "internalid", sort: search.Sort.DESC })
                    ]
                });

                try {
                    let searchResults = periodSearch.run().getRange({ start: 0, end: 1000 });
                    if (searchResults.length === 0) {
                        accountingPeriod.addSelectOption({ value: '', text: 'No periods available' });
                    } else {
                        searchResults.forEach(result => {
                            accountingPeriod.addSelectOption({
                                value: result.getValue("internalid"),
                                text: result.getValue("periodname")
                            });
                        });
                    }
                } catch (e) {
                    log.error("Search Error", e.message);
                }

                
                // Default submit
                form.addSubmitButton({ label: 'Download Full Year Report' });

                res.writePage(form);
                return;
            }


            if (req.method === 'GET' && req.parameters.download === 'T'){

             try{
                 var subsidiary = req.parameters.custpage_subsidiary;
                var accountingPeriod = req.parameters.custpage_acc_period;

                var fileId = getFileId(subsidiary, accountingPeriod);
                if (fileId) {
                    var fileObj = file.load({ id: fileId });
                    res.write(fileObj.getContents());
                } else {
                    res.write("No pre processed data found for given Subsidiary & Accounting Period.");
                }
             }
             catch(e){
               log.error("error in displaying report",e)
               res.write("No pre processed data found for given Subsidiary & Accounting Period.");
             }
             
           }

            // ---------------------------
            // 2. Handle GET + download=T
            // ---------------------------
            // if (req.method === 'POST' && req.parameters.download === 'T') {
            //     var subsidiary = req.parameters.custpage_subsidiary;
            //     var accountingPeriod = req.parameters.custpage_acc_period;

            //     var fileId = getFileId(subsidiary, accountingPeriod);
            //     if (fileId) {
            //         var fileObj = file.load({ id: fileId });
            //         res.write(fileObj.getContents());
            //     } else {
            //         res.write("No pre processed data found for given Subsidiary & Accounting Period.");
            //     }
            //     return;
            // }

            // ---------------------------
            // 3. Handle POST
            // ---------------------------
            if (req.method === 'POST') {
                var subsidiary = req.parameters.custpage_subsidiary;
                var accountingPeriod = req.parameters.custpage_acc_period;
                var action = req.parameters.custpage_action;
                var context=context.request.parameters;
                log.debug("context",context)
                if (action === "override") {
                    try {
                        var mrTask = task.create({
                            taskType: task.TaskType.MAP_REDUCE,
                            scriptId: 'customscript_actuals_vs_aop_map_red_',
                            deploymentId: 'customdeploy_actuals_vs_aop_map_red_',
                            params: {
                                custscript_acc_period_param1: parseInt(accountingPeriod)
                            }
                        });

                        var taskId = mrTask.submit();

var accountingPeriodName=getAccountingPeriodName(accountingPeriod)

                        // ----------------------------------
                        // Write the styled HTML (your design)
                        // ----------------------------------
res.write(`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Master Generation Started</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <style>
    :root{
      --bg:#f4f7fb;
      --card:#ffffff;
      --accent:#2563eb;
      --muted:#6b7280;
      --success:#10b981;
      --shadow: 0 10px 30px rgba(37,99,235,0.08);
      --radius:12px;
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    }
    html,body{height:100%;}
    body{
      margin:0;
      background: linear-gradient(180deg, #f7fbff 0%, var(--bg) 100%);
      display:flex;
      align-items:center;
      justify-content:center;
      padding:24px;
      -webkit-font-smoothing:antialiased;
    }
    .card{
      width:100%;
      max-width:820px;
      background:var(--card);
      border-radius:var(--radius);
      box-shadow:var(--shadow);
      padding:28px;
      display:flex;
      gap:24px;
      align-items:center;
      justify-content:space-between;
    }
    .left { flex:1; min-width:0; }
    h1{ margin:0 0 8px 0; font-size:20px; color:#0f172a; letter-spacing:-0.2px; }
    p.lead { margin:0 0 14px 0; color:var(--muted); font-size:14px; line-height:1.45; }
    .badge {
      display:inline-flex;
      align-items:center;
      gap:8px;
      background:rgba(16,185,129,0.12);
      color:var(--success);
      padding:8px 12px;
      border-radius:999px;
      font-weight:600;
      font-size:13px;
    }
    .right {
      width:200px;
      text-align:center;
      display:flex;
      flex-direction:column;
      gap:14px;
      align-items:center;
    }
    .spinner {
      width:76px; height:76px; border-radius:50%;
      display:inline-block; position:relative;
      box-shadow: inset 0 -6px 0 rgba(0,0,0,0.03);
    }
    .spinner:before, .spinner:after{
      content:""; position:absolute; inset:6px; border-radius:50%;
      border:6px solid transparent;
      border-top-color:var(--accent);
      border-right-color:rgba(37,99,235,0.25);
      animation:spin 1.4s linear infinite;
    }
    .spinner:after {
      inset:14px; border-width:4px;
      border-top-color:rgba(16,185,129,0.92);
      border-right-color:rgba(16,185,129,0.25);
      animation-duration:1.1s;
    }
    @keyframes spin{to{transform:rotate(360deg);}}
    .countdown { font-weight:700; color:#0f172a; font-size:18px; }
    .actions{ display:flex; gap:10px; margin-top:10px; flex-wrap:wrap; }
    .btn{
      display:inline-flex; align-items:center; justify-content:center;
      gap:8px; padding:10px 14px; border-radius:10px; border:none;
      text-decoration:none; font-weight:600; cursor:pointer; font-size:13px;
    }
    .btn-primary{ background:var(--accent); color:white; box-shadow:0 6px 18px rgba(37,99,235,0.12); }
    .note{ margin-top:8px; color:var(--muted); font-size:13px; }
    @media (max-width:700px){
      .card{flex-direction:column; align-items:center; text-align:center;}
      .right{width:100%;}
      .left{width:100%;}
    }
  </style>
</head>
<body>
  <div class="card" role="status" aria-live="polite">
    <div class="left">
      <div class="badge">⏳ Master Generation Started</div>
      <h1>Actuals vs AOP Master reports generation in progress, for the selected period - ${accountingPeriodName}</h1>
      <p class="lead">The background process has started; Task ID reference - ${taskId}</p>
      <div class="note">
        This operation may take some time because it creates masters by aggregating transactions of all subsidiaries for the selected accounting period.<br/>Once the process is complete, click the 'Download Generated Report' button to download the report.
      </div>
      <div class="actions" style="margin-top:16px; display:flex; flex-direction:column; align-items:flex-end; gap:12px;">
        <div class="right">
          <div class="spinner"></div>
          <div id="countdown" class="countdown"></div>
        </div>
        <div id="statusBox" style="margin-top:10px; text-align:right; font-size:13px; color:var(--muted);">
          Status: Processing...
        </div>
      </div>
    </div>
  </div>
<script>
(function(){
  // Countdown with drift correction
  var DURATION = 3600; // seconds
  var endTime = sessionStorage.getItem('taskEndTime_${taskId}') 
    ? parseInt(sessionStorage.getItem('taskEndTime_${taskId}')) 
    : Date.now() + DURATION * 1000;
  sessionStorage.setItem('taskEndTime_${taskId}', endTime);
  var el = document.getElementById('countdown');

  function pad(n){ return n<10?'0'+n:n; }
  function updateCountdown(){
    var remaining = Math.max(0, Math.floor((endTime - Date.now())/1000));
    var hrs = Math.floor(remaining/3600);
    var mins = Math.floor((remaining%3600)/60);
    var secs = remaining%60;
    el.textContent = pad(hrs)+':'+pad(mins)+':'+pad(secs);
    if(remaining<=0){
      clearInterval(timer);
      el.textContent = 'Completed (check status)';
      sessionStorage.removeItem('taskEndTime_${taskId}');
    }
  }
  var timer = setInterval(updateCountdown, 1000);
  updateCountdown();

  // Polling for task status with retries
  var POLL_INTERVAL = 5000;
  var MAX_RETRIES = 15;
  var retryCount = 0;
  var pollTimer = setInterval(function(){
    pollStatus("${taskId}");
  }, POLL_INTERVAL);
  var isComplete = false;

  function pollStatus(taskId){
    if (!taskId) {
      document.getElementById('statusBox').innerText = 'Error: Invalid Task ID';
      console.error('Invalid taskId:', taskId);
      clearInterval(pollTimer);
      return;
    }
    console.log('Polling for taskId:', taskId, 'Retry count:', retryCount);
    fetch('/app/site/hosting/scriptlet.nl?script=1223&deploy=1&taskId=' + taskId)
      .then(res => {
        if (!res.ok) throw new Error('HTTP error: ' + res.status);
        retryCount = 0; // Reset retries on success
        return res.json();
      })
      .then(data => {
        console.log('Poll response:', data);
        var box = document.getElementById('statusBox');
        console.log('statusBox element:', box);
        var percent = data.percentComplete ? parseFloat(data.percentComplete).toFixed(2) : 0;
        var stageText = data.stage ? 'Stage: ' + data.stage + ' | ' : (percent >= 100 ? 'Stage: SUMMARIZE | ' : '');

        // Check for complete (overall COMPLETE or stage null at 100%)
        if ((data.status === 'COMPLETE' || (data.stage === null && percent >= 100)) && !isComplete) {
          box.innerText = 'Status: COMPLETE | Progress: 100%';
          var btn = document.createElement('a');
          btn.href = '/app/site/hosting/scriptlet.nl?script=900&deploy=1'
            + '&custpage_subsidiary=${subsidiary}'
            + '&custpage_acc_period=${accountingPeriod}'
            + '&download=T';
          btn.textContent = 'Download Generated Report';
          btn.className = 'btn btn-primary';
          btn.style.marginTop = '12px';
          btn.style.display = 'block';
          box.appendChild(btn);
          isComplete = true;
          clearInterval(pollTimer);
          sessionStorage.removeItem('taskEndTime_${taskId}');
        } else if(data.status === 'FAILED'){
          box.innerHTML = '<span style="color:red;font-weight:bold;">Status: FAILED | Progress: ' + percent + '%</span>';
          clearInterval(pollTimer);
          sessionStorage.removeItem('taskEndTime_${taskId}');
        } else {
          box.innerText = stageText + 'Status: ' + data.status + ' | Progress: ' + percent + '%';
        }
      })
      .catch(err => {
        console.error('Fetch error:', err, 'Retry count:', retryCount);
        if (retryCount < MAX_RETRIES) {
          retryCount++;
          box.innerText = 'Status: Retrying (' + retryCount + '/' + MAX_RETRIES + ')...';
          setTimeout(() => pollStatus(taskId), POLL_INTERVAL);
        } else {
          console.error('Max retries reached for taskId:', taskId);
          box.innerText = 'Error fetching status: Max retries reached';
          clearInterval(pollTimer);
          sessionStorage.removeItem('taskEndTime_${taskId}');
        }
      });
  }

  // Initial poll
  pollStatus("${taskId}");
})();
</script>
</body>
</html>`);
                    } catch (e) {
                        if (e.name === "MAP_REDUCE_ALREADY_RUNNING") {
                            res.write(`<div style="font-family:Arial,sans-serif;padding:20px;background:#f0f4f8;">
                              Master generation already running for another accounting period, please try after sometime
                            </div>`);
                        } else {
                            log.error("Error scheduling MR", e.message);
                            res.write("Error while scheduling MR: " + e.message);
                        }
                    }
                } else if(action !== "override") {
                     var subsidiary = req.parameters.custpage_subsidiary;
                var accountingPeriod = req.parameters.custpage_acc_period;

                var fileId = getFileId(subsidiary, accountingPeriod);
                if (fileId) {
                    var fileObj = file.load({ id: fileId });
                    res.write(fileObj.getContents());
                } else {
                    res.write("No pre processed data found for given Subsidiary & Accounting Period.");
                }
                return;
                }
            }
        } catch (error) {
            log.error('Error occurred:', error.message);
        }
    }

     function getAccountingPeriodName(periodId) {
        var periodLookup = search.lookupFields({
            type: 'accountingperiod',
            id: periodId,
            columns: ['periodname']
        });

        // periodLookup.periodname returns the name
        return periodLookup.periodname;
    }


  function getFileId(subsidiary, accountingPeriod) {
    var customrecord_sut_report_table_SearchObj = search.create({
        type: "customrecord_sut_report_table_",
        filters: [
            ["custrecord_report_subs_hier_", "anyof", subsidiary],
            "AND",
            ["custrecord_report_acc_period_", "anyof", accountingPeriod]
        ],
        columns: [
            search.createColumn({ name: "internalid" }),
            search.createColumn({ name: "custrecord_report_subs_hier_" }),
            search.createColumn({ name: "custrecord_report_acc_period_" }),
            search.createColumn({ name: "custrecord_monthly_report_doc_" }),
            search.createColumn({ name: "custrecord_quarter_report_" }),
            search.createColumn({ name: "custrecord_year_to_date_report_" }),
            search.createColumn({ name: "custrecord_full_year_report" }),
            search.createColumn({ name: "custrecord_full_dashboard_report_doc_" }),
            search.createColumn({ name: "custrecord_monthl_rep_gen_" }),
            search.createColumn({ name: "custrecord_qtd_rep_gen_" }),
            search.createColumn({ name: "custrecord_yearly_report_chk_" }),
            search.createColumn({ name: "custrecord_full_year_rpt_chk_" }),
            search.createColumn({ name: "custrecord_act_vs_aop_db_gen_" })
        ]
    });

    var results = customrecord_sut_report_table_SearchObj.run().getRange({ start: 0, end: 1 });
    log.debug("Total Results", results.count);

 var fileId = null;
    if (results && results.length > 0) {
        fileId = results[0].getValue({ name: 'custrecord_full_year_report' }); 
    }


    log.debug("First File ID", fileId);
    return fileId;
}


    return { onRequest: onRequest };
});
