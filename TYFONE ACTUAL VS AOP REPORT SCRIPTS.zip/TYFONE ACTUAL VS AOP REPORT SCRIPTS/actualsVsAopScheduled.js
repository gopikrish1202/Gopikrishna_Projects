/**
 * @NApiVersion 2.x
 * @NScriptType ScheduledScript
 */
define(['N/task', 'N/log', 'N/search'], function(task, log, search) {

    function execute(context) {
        try {
            var today = new Date();
          log.debug("today.getDate() first check",today.getDate())

            // Run only on 7th day of the month
            if (today.getDate() === 7) {
                log.debug('Date Check', 'Today is 7th, proceeding...');
              log.debug("today.getDate() inside if block",today.getDate())

                // Get previous month’s accounting period
                var prevMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
                var monthPeriodId = getAccountingPeriodId(prevMonthDate);
                log.debug('Previous Accounting Period ID', monthPeriodId);

                if (monthPeriodId) {
                    var mrTask = task.create({
                        taskType: task.TaskType.MAP_REDUCE,
                        scriptId: 'customscript_act_vs_aop_map_red_aut_', 
                        deploymentId: 'customdeploy_act_vs_aop_map_red_aut_',
                        params: {
                            custscript_acc_period_param2: monthPeriodId
                        }
                    });

                    var taskId = mrTask.submit();
                    log.debug('MR Task Submitted', 'Task ID: ' + taskId);
                } else {
                    log.error('Error', 'No accounting period found for previous month.');
                }

            } else {
                log.debug('Date Check', 'Not 7th of the month. No action taken.');
            }
        } catch (e) {
            log.error('Error', e.toString());
        }
    }

    /**
     * Helper: Find accounting period internal ID for given date
     */
    function getAccountingPeriodId(dateObj) {
        var month = dateObj.getMonth() + 1; // 1-12
        var year = dateObj.getFullYear();

        var monthNames = [
            'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
        ];
        var periodName = monthNames[month - 1] + ' ' + year;

        var accPeriodSearch = search.create({
            type: 'accountingperiod',
            filters: [['periodname', 'is', periodName]],
            columns: ['internalid']
        });

        var result = accPeriodSearch.run().getRange({ start: 0, end: 1 });
        return result.length > 0 ? result[0].getValue('internalid') : null;
    }

    return {
        execute: execute
    };
});
