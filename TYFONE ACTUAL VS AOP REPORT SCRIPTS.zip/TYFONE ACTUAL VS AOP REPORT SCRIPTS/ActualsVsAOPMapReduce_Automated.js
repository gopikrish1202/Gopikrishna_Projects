/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
define(['N/query', 'N/search', 'N/runtime', 'N/format', 'N/file', 'N/log', 'N/record', 'N/task'], function (query, search, runtime, format, file, log, record, task) {
    function getInputData() {
    var results = [];
    var accountingPeriod = runtime.getCurrentScript().getParameter({
        name: 'custscript_acc_period_param2'
    });
    log.debug("input function initiated, units left", runtime.getCurrentScript().getRemainingUsage());

   
    var aprilId = getAprilId(accountingPeriod);
    var previousYearPeriod = getPreviousYearAccountingPeriod(accountingPeriod);

    var monthlyCurrs = [accountingPeriod];
    var monthlyPrevs = [previousYearPeriod];

    var qtdInfo = getQuarterMonthIds(accountingPeriod);
    var qtdCurrs = qtdInfo.quarterMonthIds;
    var qtdPrevs = getPreviousYearAccountingPeriods(qtdCurrs);

    var ytdCurrs = getFinancialYearMonthsYTD(accountingPeriod).monthIds;
    var ytdPrevs = getPreviousYearAccountingPeriods(ytdCurrs);

    var fullCurrs = getFinancialYearMonthsFullYear(accountingPeriod).monthIds;
    var fullPrevs = getPreviousYearAccountingPeriods(fullCurrs);

    var queryTypes = [
        { type: 'monthly', currs: monthlyCurrs, prevs: monthlyPrevs },
        { type: 'qtd',     currs: qtdCurrs,     prevs: qtdPrevs },
        { type: 'ytd',     currs: ytdCurrs,     prevs: ytdPrevs },
        { type: 'fullyear',currs: fullCurrs,    prevs: fullPrevs }
    ];

    var searchObj = search.create({
        type: "customrecord_tyf_subs_hier_",
        filters: [["isinactive", "is", "F"]],
        columns: [
            search.createColumn({ name: "internalid", sort: search.Sort.ASC }),
            "custrecord_subsidiary_hierarchy",
            "name"
        ]
    });

    searchObj.run().each(function (result) {
        var parentId = result.getValue("internalid");
        var parentName = result.getValue("name");
        var childSubsidiaries = result.getValue("custrecord_subsidiary_hierarchy");

        if (childSubsidiaries) {
            childSubsidiaries.split(",").forEach(function (childId) {
                childId = childId.trim();
                if (childId) {
                    queryTypes.forEach(function (qt) {
                        for (var i = 0; i < qt.currs.length; i++) {
                            results.push({
                                parentId: parentId,
                                parentName: parentName,
                                childSubsidiaryId: parseInt(childId, 10),
                                accountingPeriod: accountingPeriod,
                                aprilId: aprilId,
                                queryType: qt.type,
                                currPeriod: parseInt(qt.currs[i], 10),
                                prevPeriod: qt.prevs[i]
                            });
                        }
                    });
                }
            });
        }
        return true;
    });

    log.debug("Expanded Input Results Count", results.length);
    return results;
}





function map(context) {
    try {
        log.debug("map function initiated, units left", runtime.getCurrentScript().getRemainingUsage());
        log.debug("raw context.value", context.value);

        var result = JSON.parse(context.value);
        log.debug("Parsed result from input", result);

        var subsidiary = result.parentId;
        log.debug("subsidiary before passing", subsidiary);
        var subsidiaryIds = [Number(result.childSubsidiaryId)];
        log.debug("subsidiary ids from iteration", subsidiaryIds);
        var subsidiaryName = result.parentName;
        log.debug("subsidiary name", subsidiaryName);
        var accountingPeriod = result.accountingPeriod;
        log.debug("Accounting period", accountingPeriod);
        var aprilId = result.aprilId;
        log.debug("aprilId", aprilId);
        var currPeriod = result.currPeriod;
        log.debug("currPeriod", currPeriod);
        var prevPeriod = result.prevPeriod;
        log.debug("prevPeriod", prevPeriod);


        var monthlyQueryExecution = null;
        var qtdQueryExecution = null;
        var ytdQueryExecution = null;
        var fullYearQueryExecution = null;

        var monthNumber = parseInt(getMonthNumber(accountingPeriod), 10);

        log.debug("monthNumber in map",monthNumber)

        if (result.queryType === "monthly") {
            log.debug("monthly current month params before passing", result.currPeriod);
            log.debug("previous month params before passing month wise", result.prevPeriod);
            log.debug("subs", subsidiaryIds);
            try {
                if (!result.currPeriod || !result.prevPeriod || !subsidiaryIds || !subsidiaryIds.length) {
                    throw new Error("Invalid parameters for monthlyQueryRun: " + JSON.stringify({
                        currPeriod: result.currPeriod,
                        prevPeriod: result.prevPeriod,
                        subsidiaryIds
                    }));
                }
                monthlyQueryExecution = monthlyQueryRun(result.currPeriod, result.prevPeriod, subsidiaryIds);
                log.debug("monthly function results", monthlyQueryExecution);
            } catch (e) {
                log.error("Error in monthlyQueryRun", {
                    errorMessage: e.message || 'No error message provided',
                    errorStack: e.stack || 'No stack trace available',
                    errorType: e.type || typeof e,
                    error: JSON.stringify(e, null, 2),
                    currPeriod: result.currPeriod,
                    prevPeriod: result.prevPeriod,
                    subsidiaryIds
                });
                monthlyQueryExecution = { parentData: [], childData: [] };
            }
        } else if (result.queryType === "qtd") {
            log.debug("current qtd params before passing", result.currPeriod);
            log.debug("previous qtd params before passing month wise", result.prevPeriod);
            try {
                if (!result.currPeriod || !result.prevPeriod || !subsidiaryIds || !subsidiaryIds.length) {
                    throw new Error("Invalid parameters for quarterlyQueryRun: " + JSON.stringify({
                        currPeriod: result.currPeriod,
                        prevPeriod: result.prevPeriod,
                        subsidiaryIds
                    }));
                }
                qtdQueryExecution = quarterlyQueryRun(result.currPeriod, result.prevPeriod, subsidiaryIds);
                log.debug("qtd function results", qtdQueryExecution);
            } catch (e) {
                log.error("Error in quarterlyQueryRun", {
                    errorMessage: e.message || 'No error message provided',
                    errorStack: e.stack || 'No stack trace available',
                    errorType: e.type || typeof e,
                    error: JSON.stringify(e, null, 2),
                    currPeriod: result.currPeriod,
                    prevPeriod: result.prevPeriod,
                    subsidiaryIds
                });
                qtdQueryExecution = { parentData: [], childData: [] };
            }
        } else if (result.queryType === "ytd") {
            log.debug("current ytd params before passing", result.currPeriod);
            log.debug("previous ytd params before passing month wise", result.prevPeriod);
            try {
                if (!result.currPeriod || !result.prevPeriod || !subsidiaryIds || !subsidiaryIds.length) {
                    throw new Error("Invalid parameters for ytdQueryRun: " + JSON.stringify({
                        currPeriod: result.currPeriod,
                        prevPeriod: result.prevPeriod,
                        subsidiaryIds
                    }));
                }
                ytdQueryExecution = ytdQueryRun(result.currPeriod, result.prevPeriod, subsidiaryIds);
                log.debug("ytd function results", ytdQueryExecution);
            } catch (e) {
                log.error("Error in ytdQueryRun", {
                    errorMessage: e.message || 'No error message provided',
                    errorStack: e.stack || 'No stack trace available',
                    errorType: e.type || typeof e,
                    error: JSON.stringify(e, null, 2),
                    currPeriod: result.currPeriod,
                    prevPeriod: result.prevPeriod,
                    subsidiaryIds
                });
                ytdQueryExecution = { parentData: [], childData: [] };
            }
        } else if (result.queryType === "fullyear") {
            log.debug("current full year params before passing", result.currPeriod);
            log.debug("previous full year params before passing month wise", result.prevPeriod);
            try {
                if (!result.currPeriod || !result.prevPeriod || !subsidiaryIds || !subsidiaryIds.length || !monthNumber) {
                    throw new Error("Invalid parameters for fullYearQueryRun: " + JSON.stringify({
                        currPeriod: result.currPeriod,
                        prevPeriod: result.prevPeriod,
                        subsidiaryIds,
                        monthNumber
                    }));
                }
                fullYearQueryExecution = fullYearQueryRun(result.currPeriod, result.prevPeriod, subsidiaryIds, monthNumber);
                log.debug("full year function results", fullYearQueryExecution);
            } catch (e) {
                log.error("Error in fullYearQueryRun", {
                    errorMessage: e.message || 'No error message provided',
                    errorStack: e.stack || 'No stack trace available',
                    errorType: e.type || typeof e,
                    error: JSON.stringify(e, null, 2),
                    currPeriod: result.currPeriod,
                    prevPeriod: result.prevPeriod,
                    subsidiaryIds,
                    monthNumber
                });
                fullYearQueryExecution = { parentData: [], childData: [] };
            }
        } else {
            log.error("Invalid queryType in map", result.queryType);
            return;
        }

        var output = {
            accountingPeriod: accountingPeriod,
            subsidiary: subsidiary,
            subsidiaryName: subsidiaryName,
            subsidiaryIds: subsidiaryIds,
            aprilId: aprilId,
            queryType: result.queryType,
            currPeriod: currPeriod,
            prevPeriod: prevPeriod,
            monthlyResults: monthlyQueryExecution,
            qtdQueryResults: qtdQueryExecution,
            ytdQueryResults: ytdQueryExecution,
            fullYearQueryResults: fullYearQueryExecution
        };
        log.debug("Output to reduce", output);
        context.write({
            key: subsidiary,
            value: JSON.stringify(output)
        });
    } catch (e) {
        log.error('Error in map stage', {
            errorMessage: e.message || 'No error message provided',
            errorStack: e.stack || 'No stack trace available',
            errorType: e.type || typeof e,
            error: JSON.stringify(e, null, 2),
            input: context.value
        });
        context.write({
            key: context.value || 'unknown',
            value: JSON.stringify({ error: 'Map stage failed', details: e.message || 'Unknown error' })
        });
    }
}

function reduce(context) {
    try {
        log.debug("Reduce stage started", { key: context.key, valueCount: context.values.length });

        var subsidiaryId = parseInt(context.key, 10);
        var values = context.values;
        var accountingPeriod, subsidiary, subsidiaryName, aprilId, previousYearPeriod, monthNumber;
        var subsidiaryIds = [];

        // Initialize data arrays for each query type
        var allMonthlyParentData = [], allMonthlyChildData = [];
        var allQuarterlyParentData = [], allQuarterlyChildData = [];
        var allYtdParentData = [], allYtdChildData = [];
        var allFullYearParentData = [], allFullYearChildData = [];

        // Track errors for partial results
        var parseErrors = [];

        // Collect metadata and query results
        values.forEach((val, index) => {
            try {
                // Validate JSON format
                if (typeof val !== 'string' || !val.trim() || !val.startsWith('{') || !val.endsWith('}')) {
                    throw new Error('Invalid JSON format');
                }

                log.debug('Processing value', { index, valuePreview: val.substring(0, 1000), length: val.length });

                var parsed = JSON.parse(val);
                if (parsed.error) {
                    log.error('Map stage error detected', { index, error: parsed });
                    parseErrors.push({ index, error: 'Map stage error', details: parsed });
                    return;
                }

                // Collect metadata once
                if (!accountingPeriod && parsed.accountingPeriod) accountingPeriod = parseInt(parsed.accountingPeriod, 10);
                if (!previousYearPeriod && parsed.prevPeriod) previousYearPeriod = parseInt(parsed.prevPeriod, 10);
                if (!monthNumber && parsed.monthNumber) monthNumber = parsed.monthNumber;
                if (!subsidiary && parsed.subsidiary) subsidiary = parsed.subsidiary;
                if (!subsidiaryName && parsed.subsidiaryName) subsidiaryName = parsed.subsidiaryName;
                if (!aprilId && parsed.aprilId) aprilId = parseInt(parsed.aprilId, 10);
                if (parsed.subsidiaryIds) {
                    subsidiaryIds = [...new Set([...subsidiaryIds, ...parsed.subsidiaryIds.map(id => parseInt(id, 10))])];
                }

                // Aggregate query results
                if (parsed.queryType === "monthly" && parsed.monthlyResults) {
                    if (parsed.monthlyResults.parentData) allMonthlyParentData.push(...parsed.monthlyResults.parentData);
                    if (parsed.monthlyResults.childData) allMonthlyChildData.push(...parsed.monthlyResults.childData);
                } else if (parsed.queryType === "qtd" && parsed.qtdQueryResults) {
                    if (parsed.qtdQueryResults.parentData) allQuarterlyParentData.push(...parsed.qtdQueryResults.parentData);
                    if (parsed.qtdQueryResults.childData) allQuarterlyChildData.push(...parsed.qtdQueryResults.childData);
                } else if (parsed.queryType === "ytd" && parsed.ytdQueryResults) {
                    if (parsed.ytdQueryResults.parentData) allYtdParentData.push(...parsed.ytdQueryResults.parentData);
                    if (parsed.ytdQueryResults.childData) allYtdChildData.push(...parsed.ytdQueryResults.childData);
                } else if (parsed.queryType === "fullyear" && parsed.fullYearQueryResults) {
                    if (parsed.fullYearQueryResults.parentData) allFullYearParentData.push(...parsed.fullYearQueryResults.parentData);
                    if (parsed.fullYearQueryResults.childData) allFullYearChildData.push(...parsed.fullYearQueryResults.childData);
                } else {
                    log.error("Invalid or missing queryType/results", { index, queryType: parsed.queryType });
                    parseErrors.push({ index, error: 'Invalid queryType', queryType: parsed.queryType });
                }
            } catch (e) {
                log.error("Error parsing map output", {
                    index,
                    valuePreview: val.substring(0, 1000),
                    valueLength: val.length,
                    errorMessage: e.message || 'No error message provided',
                    errorStack: e.stack || 'No stack trace available',
                    errorType: e.type || typeof e
                });
                parseErrors.push({ index, error: e.message, valuePreview: val.substring(0, 1000) });
                // Attempt partial parsing for truncated JSON
                try {
                    var partial = JSON.parse(val + '}');
                    parseErrors.push({ index, warning: 'Recovered partial data', partial });
                } catch (partialError) {
                    log.debug('Partial parsing failed', { index, error: partialError });
                }
            }
        });

        // Log summary of processing
        log.debug('Reduce data aggregation', {
            processed: values.length - parseErrors.length,
            errors: parseErrors.length,
            errorDetails: parseErrors
        });

        // Validate required metadata
        if (!subsidiaryId || !accountingPeriod || !subsidiary || !subsidiaryName) {
            log.error('Missing required metadata', { subsidiaryId, accountingPeriod, subsidiary, subsidiaryName });
            context.write({
                key: subsidiaryId,
                value: JSON.stringify({ error: 'Missing metadata', parseErrors })
            });
            return;
        }

        // Fetch subsidiary logo
        var sub_img = '';
        try {
            var parentSubsidiaryQuery = `SELECT custrecord_cons_sub_parent_ FROM customrecord_tyf_subs_hier_ WHERE id = ?`;
            var parentSubsidiary = query.runSuiteQL({ query: parentSubsidiaryQuery, params: [subsidiaryId] }).asMappedResults();
            var parentSubsidiaryId = parentSubsidiary.length > 0 ? parseInt(parentSubsidiary[0].custrecord_cons_sub_parent_, 10) : 0;
            if (parentSubsidiaryId) {
                var subsidiaryRecord = record.load({ type: 'subsidiary', id: parentSubsidiaryId });
                var logoId = subsidiaryRecord.getValue({ fieldId: 'logo' });
                sub_img = logoId ? file.load({ id: logoId }).url : '';
            }
        } catch (e) {
            log.debug('Error fetching logo for subsidiary ' + subsidiary, e);
            parseErrors.push({ error: 'Failed to fetch logo', details: e.message });
        }

        // Initialize HTML table
        var subsidiaryChildPlaceHolders = subsidiaryIds.map(() => "?").join(",");
        var tableHtml = `<html><head>
<title style="font-size: 20px; background-color: #9AFF9A; text-align: center; font-weight: bold;">Generated Report</title>
<style>
    @media print {
        @page { size: A2 landscape; margin: 10mm; }
        h1 { text-align: center !important; }
    }
    .subcategory-toggle.plus-state { background-color: #4CAF50; color: white; border: none; padding: 2px 6px; }
    .toggle-button { cursor: pointer; }
    .positive { color: black; }
    .negative { color: red; }
    .button-container {
        position: absolute; top: 10px; right: 10px; display: flex; align-items: center; gap: 10px; z-index: 1000;
    }
    .print-btn, .toggle-btn {
        position: static; padding: 15px 25px; color: white; border: none; border-radius: 8px; cursor: pointer;
        font-size: 18px; font-weight: bold; box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.3); font-family: 'Arial', sans-serif;
        white-space: nowrap;
    }
    h1 { margin-top: 60px; font-family: 'Arial', sans-serif; text-transform: uppercase; }
    .table-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: 30px; align-items: start; }
    .client-data { background-color: #e6f3ff; font-family: 'Arial', sans-serif; }
    .table-wrapper { min-width: 0; overflow-x: auto; text-transform: uppercase; }
    table { border-collapse: collapse; margin-bottom: 0px; font-family: 'Arial', sans-serif; text-transform: uppercase; }
    th { color: black; border: 1px solid #444; padding: 10px; background-color: white; text-align: center; font-family: 'Arial', sans-serif; font-size: 28pt; font-weight: 800; text-transform: uppercase; }
    td { border: 1px solid #444; padding: 10px; text-align: right; word-wrap: break-word; font-family: 'Arial', sans-serif; text-transform: uppercase; }
    td:first-child { text-align: left !important; font-family: 'Arial', sans-serif; }
    .child-table, .parent-row, .subcategory-row, .child-row, .total-row, .arrtable, .summary-rows, .classification-section { font-family: 'Arial', sans-serif; text-transform: uppercase; }
    .child-table { background-color: #f8f8f8; }
    .parent-row { background-color: white; }
    .subcategory-row { background-color: #f0f0f0; }
    .child-row { background-color: rgb(217, 217, 217); }
    .total-row { background-color: #A7C7FF; font-weight: bold; }
    .arrtable, .summary-rows { background-color: rgb(0, 112, 192); color: white; font-weight: bold; }
    .classification-section { background-color: rgb(166, 166, 166); font-weight: 800; }
    .toggle-button { cursor: pointer; padding: 2px 8px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; margin-right: 5px; text-transform: uppercase; }
    body { background-color: rgb(217, 217, 217); font-family: 'Arial', sans-serif; text-transform: uppercase; }
</style>
</head>
<body>
<div class="button-container">
    <img src="https://9031920.app.netsuite.com/core/media/media.nl?id=208885&c=9031920&h=5gRkS262kNk5Z28Qx15H4_pgMPaPNdCBb5P3XZNDk2RAzd8Y" alt="Print PDF" title="Print PDF" onclick="printPDF()" style="cursor: pointer; width: 40px; height: 40px;" />
    <img id="toggleAllBtn" src="https://9031920.app.netsuite.com/core/media/media.nl?id=208884&c=9031920&h=Vd0_O6oznEYrolZVAL_6y4LCMI3ErMErwddefTubVluPy-7l" alt="Expand All" title="Expand All" class="action-btn toggle-btn" onclick="toggleAllRows()" style="cursor: pointer; width: 40px; height: 40px;" />
</div>
<div style="display: flex; justify-content: space-between; align-items: center;">
    <div><img src="${sub_img}" width="300" height="150"></div>
    <h1 style="font-size: 22pt; align: center; padding-left: 125px;"> <b>Actual vs AOP Dashboard</b> </h1>
    <div style="width: 200px;"></div>
</div>
<div class="table-container">`;

        // Aggregate data for each query type
        var monthlyAggregateFunction = { parents: [], children: [] };
        var qtdAggregateFunction = { parents: [], children: [] };
        var ytdAggregateFunction = { parents: [], children: [] };
        var fullYearAggregateFunction = { parents: [], children: [] };
        try {
            monthlyAggregateFunction = aggregateWithValidation(allMonthlyParentData, allMonthlyChildData, "monthly");
            qtdAggregateFunction = aggregateWithValidation(allQuarterlyParentData, allQuarterlyChildData, "qtd");
            ytdAggregateFunction = aggregateWithValidation(allYtdParentData, allYtdChildData, "ytd");
            fullYearAggregateFunction = aggregateWithValidation(allFullYearParentData, allFullYearChildData, "fullyear");

            log.audit("full year parent data before aggregation",allFullYearParentData)
            log.audit("full year child data before aggregation",allFullYearChildData)
            log.audit("full year after aggregation",fullYearAggregateFunction)
        } catch (e) {
            log.error('Error in aggregateWithValidation', { error: e });
            parseErrors.push({ error: 'Aggregation failed', details: e.message });
        }

        // Prepare parameters and year name
        var yearName = getYearName(accountingPeriod) || 'Unknown Year';
        var parameters = [accountingPeriod, accountingPeriod, previousYearPeriod, previousYearPeriod, ...subsidiaryIds];

        // Check if record exists or create a new one
        var tableRecord;
        var stagingTableId;
        try {
            var existenceCheck = recordNotExistCheck(subsidiaryId, accountingPeriod);
            log.debug('Record existence check', { subsidiaryId, accountingPeriod, existenceCheck });

            var existingAndFilesNotGeneratedRecordsArr = existingAndFilesNotGeneratedRecords(subsidiaryId, accountingPeriod);
            log.debug("existingAndFilesNotGeneratedRecordsArr", existingAndFilesNotGeneratedRecordsArr);

            if (existingAndFilesNotGeneratedRecordsArr && existingAndFilesNotGeneratedRecordsArr.length > 0) {
                stagingTableId = existingAndFilesNotGeneratedRecordsArr[0];
                log.debug("Processing existing staging table", { stagingTableId });
                try {
                    record.submitFields({
                        type: 'customrecord_sut_report_table_',
                        id: stagingTableId,
                        values: { custrecord_year_name_: yearName }
                    });
                    tableRecord = stagingTableId;
                } catch (e) {
                    log.error('Failed to update existing table record', { stagingTableId, error: e });
                    parseErrors.push({ error: 'Failed to update table record', details: e.message });
                    // Continue by creating a new record
                    throw new Error('Update failed, attempting to create new record');
                }
            } else {
                log.debug('No existing staging record found or all files generated', {
                    subsidiaryId,
                    accountingPeriod,
                    existenceCheck
                });
                // Create a new record instead of exiting
                try {
                    tableRecord = record.create({ type: 'customrecord_sut_report_table_' });
                    tableRecord.setValue({ fieldId: 'custrecord_report_subs_hier_', value: subsidiary });
                    tableRecord.setValue({ fieldId: 'custrecord_report_acc_period_', value: accountingPeriod });
                    tableRecord.setValue({ fieldId: 'custrecord_year_name_', value: yearName });
                    tableRecord = tableRecord.save();
                    stagingTableId = tableRecord;
                    log.debug('Created new staging table record', { stagingTableId });
                } catch (e) {
                    log.error('Failed to create new table record', { subsidiaryId, accountingPeriod, error: e });
                    parseErrors.push({ error: 'Failed to create table record', details: e.message });
                    context.write({
                        key: subsidiaryId,
                        value: JSON.stringify({ error: 'Failed to create table record', parseErrors })
                    });
                    return;
                }
            }
        } catch (e) {
            log.error('Error in record existence check', { subsidiaryId, accountingPeriod, error: e });
            // Fallback to creating a new record
            try {
                tableRecord = record.create({ type: 'customrecord_sut_report_table_' });
                tableRecord.setValue({ fieldId: 'custrecord_report_subs_hier_', value: subsidiary });
                tableRecord.setValue({ fieldId: 'custrecord_report_acc_period_', value: accountingPeriod });
                tableRecord.setValue({ fieldId: 'custrecord_year_name_', value: yearName });
                tableRecord = tableRecord.save();
                stagingTableId = tableRecord;
                log.debug('Created new staging table record after existence check failure', { stagingTableId });
            } catch (createError) {
                log.error('Failed to create fallback table record', { subsidiaryId, accountingPeriod, error: createError });
                parseErrors.push({ error: 'Failed to create fallback table record', details: createError.message });
                context.write({
                    key: subsidiaryId,
                    value: JSON.stringify({ error: 'Failed to create table record', parseErrors })
                });
                return;
            }
        }

        // Generate reports
        var monthlyFunction, qtdFunction, ytdFunction, fullYearFunction;
        try {
            monthlyFunction = monthlyQueryResults(
                monthlyAggregateFunction.parents, monthlyAggregateFunction.children, parameters, subsidiaryChildPlaceHolders,
                subsidiaryIds, accountingPeriod, previousYearPeriod, subsidiary, aprilId, tableHtml
            );
            log.debug('monthlyQueryResults output', monthlyFunction);
        } catch (e) {
            log.error('Error in monthlyQueryResults', { error: e });
            parseErrors.push({ error: 'Monthly report generation failed', details: e.message });
        }

        var arrPart = monthlyFunction?.arrPart || [];
        var arrActTotal = monthlyFunction?.arrActTotal || [];
        var arrAopTotal = monthlyFunction?.arrAopTotal || [];
        var arrDiff = monthlyFunction?.arrDiff || [];
        var arrPer = monthlyFunction?.arrPer || [];
        var yearName = (monthlyFunction && monthlyFunction.fyName) ? monthlyFunction.fyName : "";
        var monthNumber = monthlyFunction?.monthNumber || monthNumber;

        try {
            qtdFunction = generateQtdReport(
                qtdAggregateFunction.parents, qtdAggregateFunction.children, stagingTableId, subsidiaryChildPlaceHolders,
                subsidiaryIds, accountingPeriod, subsidiary, aprilId, tableHtml, yearName,
                arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer
            );
            log.debug('generateQtdReport output', qtdFunction);
        } catch (e) {
            log.error('Error in generateQtdReport', { error: e });
            parseErrors.push({ error: 'QTD report generation failed', details: e.message });
        }

        try {
            ytdFunction = generateYtdReport(ytdAggregateFunction.parents, ytdAggregateFunction.children, stagingTableId, subsidiaryChildPlaceHolders, subsidiaryIds, accountingPeriod, subsidiary, aprilId, tableHtml, yearName, arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer);
            log.debug('generateYtdReport output', ytdFunction);
        } catch (e) {
            log.error('Error in generateYtdReport', { error: e });
            parseErrors.push({ error: 'YTD report generation failed', details: e.message });
        }

        try {
            fullYearFunction = generateFullYearReport(
                fullYearAggregateFunction.parents, fullYearAggregateFunction.children, stagingTableId, subsidiaryChildPlaceHolders,
                subsidiaryIds, accountingPeriod, subsidiary, aprilId, tableHtml, yearName,
                arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer, monthNumber
            );
            log.debug('generateFullYearReport output', fullYearFunction);
        } catch (e) {
            log.error('Error in generateFullYearReport', { error: e });
            parseErrors.push({ error: 'Full year report generation failed', details: e.message });
        }

        // Update table record with report results
        var fieldUpdates = {};
        if (monthlyFunction) {
            if (monthlyFunction.fileId) fieldUpdates['custrecord_monthly_report_doc_'] = monthlyFunction.fileId;
            if (monthlyFunction.monthsTableFileId) fieldUpdates['custrecord_monthly_html_tables_'] = monthlyFunction.monthsTableFileId;
            fieldUpdates['custrecord_monthl_rep_gen_'] = true;
            if (monthlyFunction.yearName) fieldUpdates['custrecord_year_name_'] = monthlyFunction.yearName;
        }
        if (qtdFunction) {
            if (qtdFunction.fileId) fieldUpdates['custrecord_quarter_report_'] = qtdFunction.fileId;
            if (qtdFunction.qtdOnlyTablesFileId) fieldUpdates['custrecord_qtd_tables_'] = qtdFunction.qtdOnlyTablesFileId;
            fieldUpdates['custrecord_qtd_rep_gen_'] = true;
        }
        if (ytdFunction) {
            if (ytdFunction.fileId) fieldUpdates['custrecord_year_to_date_report_'] = ytdFunction.fileId;
            if (ytdFunction.ytdTablesOnlyFileId) fieldUpdates['custrecord_ytd_tables_'] = ytdFunction.ytdTablesOnlyFileId;
            fieldUpdates['custrecord_yearly_report_chk_'] = true;
        }
        if (fullYearFunction) {
            if (fullYearFunction.fileId) fieldUpdates['custrecord_full_year_report'] = fullYearFunction.fileId;
            if (fullYearFunction.fullYOnlyTableFileId) fieldUpdates['custrecord_fullyear_tables_'] = fullYearFunction.fullYOnlyTableFileId;
            fieldUpdates['custrecord_full_year_rpt_chk_'] = true;
        }

        if (Object.keys(fieldUpdates).length > 0) {
            try {
                log.debug("Attempting to save record", { tableRecord, stagingTableId });
                record.submitFields({
                    type: 'customrecord_sut_report_table_',
                    id: tableRecord,
                    values: fieldUpdates
                });
                log.debug("Updated staging table with report fields", { stagingTableId, updates: fieldUpdates });
            } catch (e) {
                log.error("Error submitting fieldUpdates", { stagingTableId, error: e });
                parseErrors.push({ error: 'Failed to update fieldUpdates', details: e.message });
            }
        }

        // Generate full dashboard
        var fullDashboardHtmlContent = '';
        try {
            var monthsHtmlContent = '';
            var qtdHtmlContent = '';
            var ytdHtmlContent = '';
            var fullYHtmlContent = '';

            var lookup = search.lookupFields({
                type: 'customrecord_sut_report_table_',
                id: stagingTableId,
                columns: [
                    'custrecord_monthly_html_tables_',
                    'custrecord_qtd_tables_',
                    'custrecord_ytd_tables_',
                    'custrecord_fullyear_tables_'
                ]
            });

            var monthsOnlyHtmlFile = getFileId(lookup.custrecord_monthly_html_tables_);
            var quarterOnlyHtmlFile = getFileId(lookup.custrecord_qtd_tables_);
            var ytdOnlyHtmlFile = getFileId(lookup.custrecord_ytd_tables_);
            var fullYearOnlyHtml = getFileId(lookup.custrecord_fullyear_tables_);

            log.debug("Resolved file IDs", { monthsOnlyHtmlFile, quarterOnlyHtmlFile, ytdOnlyHtmlFile, fullYearOnlyHtml });

            if (monthsOnlyHtmlFile || quarterOnlyHtmlFile || ytdOnlyHtmlFile || fullYearOnlyHtml) {
                fullDashboardHtmlContent = `${tableHtml}`;
                if (monthsOnlyHtmlFile) {
                    try {
                        monthsHtmlContent = file.load({ id: monthsOnlyHtmlFile }).getContents();
                        fullDashboardHtmlContent += `<div class="table-wrapper">${monthsHtmlContent}</div>`;
                    } catch (e) {
                        log.error('Failed to load monthly HTML file', { fileId: monthsOnlyHtmlFile, error: e });
                        parseErrors.push({ error: 'Failed to load monthly HTML', details: e.message });
                    }
                }
                if (quarterOnlyHtmlFile) {
                    try {
                        qtdHtmlContent = file.load({ id: quarterOnlyHtmlFile }).getContents();
                        fullDashboardHtmlContent += `<div class="table-wrapper">${qtdHtmlContent}</div>`;
                    } catch (e) {
                        log.error('Failed to load QTD HTML file', { fileId: quarterOnlyHtmlFile, error: e });
                        parseErrors.push({ error: 'Failed to load QTD HTML', details: e.message });
                    }
                }
                if (ytdOnlyHtmlFile) {
                    try {
                        ytdHtmlContent = file.load({ id: ytdOnlyHtmlFile }).getContents();
                        fullDashboardHtmlContent += `<div class="table-wrapper">${ytdHtmlContent}</div>`;
                    } catch (e) {
                        log.error('Failed to load YTD HTML file', { fileId: ytdOnlyHtmlFile, error: e });
                        parseErrors.push({ error: 'Failed to load YTD HTML', details: e.message });
                    }
                }
                if (fullYearOnlyHtml) {
                    try {
                        fullYHtmlContent = file.load({ id: fullYearOnlyHtml }).getContents();
                        fullDashboardHtmlContent += `<div class="table-wrapper">${fullYHtmlContent}</div>`;
                    } catch (e) {
                        log.error('Failed to load full year HTML file', { fileId: fullYearOnlyHtml, error: e });
                        parseErrors.push({ error: 'Failed to load full year HTML', details: e.message });
                    }
                }
            } else {
                log.debug("No report files available, generating fallback dashboard", { stagingTableId });
                fullDashboardHtmlContent = `${tableHtml}<div class="table-wrapper"><p>No report data available. Errors: ${JSON.stringify(parseErrors)}</p></div>`;
            }

            fullDashboardHtmlContent += `
                </div>
                <script>
                    function printPDF() { window.print(); }
                    let isExpanded = false;
                    function toggleAllRows() {
                        const allRows = document.querySelectorAll('[data-group]');
                        allRows.forEach(row => {
                            row.style.display = isExpanded ? 'none' : 'table-row';
                        });
                        const buttons = document.querySelectorAll('.toggle-button, .subcategory-toggle');
                        buttons.forEach(button => {
                            button.textContent = isExpanded ? '+' : '-';
                            button.classList.toggle('plus-state', button.textContent === '+');
                        });
                        isExpanded = !isExpanded;
                        document.getElementById('toggleAllBtn').title = isExpanded ? "Collapse All" : "Expand All";
                    }
                    function toggleRows(group, btn) {
                        const rows = document.querySelectorAll('[data-group="' + group + '"]');
                        const isVisible = rows.length > 0 && rows[0].style.display === 'table-row';
                        rows.forEach(row => {
                            row.style.display = isVisible ? 'none' : 'table-row';
                        });
                        btn.textContent = isVisible ? '+' : '-';
                        btn.classList.toggle('plus-state', btn.textContent === '+');
                    }
                </script>
                </body></html>`;

            // Validate folder
            var folderId = 11905;
            try {
                var folder = record.load({ type: 'folder', id: folderId });
                if (!folder) throw new Error('Folder does not exist');
            } catch (e) {
                log.error('Invalid folder ID', { folderId, error: e });
                parseErrors.push({ error: 'Invalid folder ID', details: e.message });
                context.write({
                    key: subsidiaryId,
                    value: JSON.stringify({ error: 'Invalid folder for dashboard', parseErrors })
                });
                return;
            }

            var monthAndYear = getMonthAndYear(accountingPeriod) || 'Unknown';
            var fullDashboardReportFile = file.create({
                name: 'fullDashboardReport_' + subsidiaryName + '_' + monthAndYear + '.html',
                fileType: file.Type.HTMLDOC,
                contents: fullDashboardHtmlContent,
                folder: folderId
            });
            var fullDashboardReportFileId = fullDashboardReportFile.save();
            log.debug("Full dashboard generated", { fullDashboardReportFileId });


            var now = new Date();
var formattedDateTime = format.format({
    value: now,
    type: format.Type.DATETIME
});

var parsedDateTime = format.parse({
    value: formattedDateTime,
    type: format.Type.DATETIME
});



            try {
                record.submitFields({
                    type: 'customrecord_sut_report_table_',
                    id: stagingTableId,
                    values: {
                        custrecord_full_dashboard_report_doc_: fullDashboardReportFileId,
                        custrecord_act_vs_aop_db_gen_: true,
                        custrecord_last_updated_: parsedDateTime
                    }
                });
                log.debug("Updated staging table with dashboard file", { stagingTableId, fullDashboardReportFileId });
            } catch (e) {
                log.error("Error updating dashboard file ID", { stagingTableId, error: e });
                parseErrors.push({ error: 'Failed to update dashboard file ID', details: e.message });
            }
        } catch (e) {
            log.error("Error in generating full dashboard", {
                errorMessage: e.message || 'No error message provided',
                errorStack: e.stack || 'No stack trace available',
                errorType: e.type || typeof e
            });
            parseErrors.push({ error: 'Dashboard generation failed', details: e.message });
        }

        // Construct final result with all query types
        var finalResult = {
            parentId: subsidiaryId,
            accountingPeriod: accountingPeriod,
            subsidiary: subsidiary,
            subsidiaryName: subsidiaryName,
            aprilId: aprilId,
            monthly: {
                parents: monthlyAggregateFunction.parents,
                children: monthlyAggregateFunction.children
            },
            qtd: {
                parents: qtdAggregateFunction.parents,
                children: qtdAggregateFunction.children
            },
            ytd: {
                parents: ytdAggregateFunction.parents,
                children: ytdAggregateFunction.children
            },
            fullyear: {
                parents: fullYearAggregateFunction.parents,
                children: fullYearAggregateFunction.children
            },
            errors: parseErrors
        };

        context.write({
            key: subsidiaryId,
            value: JSON.stringify(finalResult)
        });
    } catch (e) {
        log.error("Error in reduce stage", {
            errorMessage: e.message || 'No error message provided',
            errorStack: e.stack || 'No stack trace available',
            errorType: e.type || typeof e,
            error: JSON.stringify(e, null, 2)
        });
        context.write({
            key: subsidiaryId,
            value: JSON.stringify({ error: 'Reduce stage failed', details: e.message || 'Unknown error', parseErrors: parseErrors || [] })
        });
    }
}




        function summarize(summary) {
        // Number of subsidiaries processed (unique keys from reduce)
        var processedSubsidiaries = 0;
        summary.output.iterator().each(function(key, value) {
            processedSubsidiaries++;
            return true; // continue iteration
        });

        // Total yields
        var totalYields = summary.yields ? summary.yields.length : 0;

        // Concurrency info
        var concurrency = summary.concurrency;

        // Log results
        log.debug('Map/Reduce Summary', 
            'Number of subsidiaries processed: ' + processedSubsidiaries +
            '\nTotal yields: ' + totalYields +
            '\nConcurrency: ' + concurrency
        );

        // Optionally, log errors from map/reduce stages
        summary.mapSummary.errors.iterator().each(function(key, error, executionNo) {
            log.error('Map Error on key ' + key, error);
            return true;
        });
        summary.reduceSummary.errors.iterator().each(function(key, error, executionNo) {
            log.error('Reduce Error on key ' + key, error);
            return true;
        });
    }


    function getMonthNumber(accountingPeriod){
        
var monthName;

               var accountingperiodSearchObj = search.create({
                type: "accountingperiod",
                filters: [["internalid", "anyof", accountingPeriod]],
                columns: [
                    search.createColumn({
                        name: "formulatext",
                        formula: "TO_CHAR({startdate}, 'Month')",
                        label: "Month Name"
                    }),
                    search.createColumn({ name: "parent" }),
                    search.createColumn({ name: "periodname", label: "Period Name" })
                ]
            });

            accountingperiodSearchObj.run().each(function (result) {
                monthName = result.getValue({
                    name: "formulatext",
                    formula: "UPPER(TO_CHAR({startdate}, 'Month'))"
                });
                var periodName = result.getValue({ name: "periodname" });
                quarterSelected = result.getValue({ name: "parent" });
                var parts = periodName.split(' ');
                if (parts.length >= 2) {
                    var fullYear = parts[parts.length - 1];
                    if (/\d{4}/.test(fullYear)) {
                        yearName = fullYear.slice(-2);
                    } else {
                        log.error("Year not found in period name", periodName);
                        yearName = " ";
                    }
                } else {
                    log.error("Invalid period name format", periodName);
                    yearName = " ";
                }
                log.debug("Extracted Year (last two digits)", yearName);
                return false;
            });

            var accountingperiodSearchObj1 = search.create({
                type: "accountingperiod",
                filters: [["internalid", "anyof", quarterSelected]],
                columns: [search.createColumn({ name: "parent", label: "Parent" })]
            });

            accountingperiodSearchObj1.run().each(function (result) {
                fyName = result.getText({ name: "parent" });
                return false;
            });

            log.debug("Extracted Month Name", monthName);
            const months = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
                "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
            monthNumber = months.indexOf(monthName.trim().toUpperCase()) + 1;
            log.debug("month number", monthNumber);
            log.debug("yearName", yearName);

            return monthNumber;

        
    }

    function getMonthName(accountingPeriod){
        var monthName;
        
               var accountingperiodSearchObj = search.create({
                type: "accountingperiod",
                filters: [["internalid", "anyof", accountingPeriod]],
                columns: [
                    search.createColumn({
                        name: "formulatext",
                        formula: "TO_CHAR({startdate}, 'Month')",
                        label: "Month Name"
                    }),
                    search.createColumn({ name: "parent" }),
                    search.createColumn({ name: "periodname", label: "Period Name" })
                ]
            });

            accountingperiodSearchObj.run().each(function (result) {
                monthName = result.getValue({
                    name: "formulatext",
                    formula: "UPPER(TO_CHAR({startdate}, 'Month'))"
                });
            });

            return monthName;

    }

    function getFileId(fieldVal) {
    if (!fieldVal) return '';
    if (Array.isArray(fieldVal) && fieldVal.length > 0) return fieldVal[0].value;
    if (fieldVal.value) return fieldVal.value;
    return fieldVal; // fallback if it’s already an ID
}



/**
 * Aggregates and sorts parent & child results
 */

function aggregateWithValidation(parentData, childData, queryType) {
    var childIdCheck = (queryType === 'fullyear')
        ? (item) => item && typeof item === 'object' && item.heading_id && item.accountsearchdisplaynamecopy
        : (item) => item && typeof item === 'object' && item.id && item.accountsearchdisplaynamecopy;

    if (
        parentData && Array.isArray(parentData) && parentData.length > 0 &&
        childData && Array.isArray(childData) && childData.length > 0 &&
        parentData.every(item => item && typeof item === 'object' && item.id && item.custrecord_dashboard_classification) &&
        childData.every(childIdCheck)
    ) {
        log.debug('Aggregating ' + queryType + ' data', {
            parentCount: parentData.length,
            childCount: childData.length
        });
        return aggregateParentChild(parentData, childData, queryType);
    } else {
        log.error('Invalid ' + queryType + ' data for aggregation', {
            parentData: JSON.stringify(parentData || []),
            childData: JSON.stringify(childData || [])
        });
        return { parents: [], children: [] };
    }
}

function aggregateParentChild(parentArr, childArr, queryType) {
    var parentMap = {};
    var childMap = {};

    if (parentArr && Array.isArray(parentArr)) {
        parentArr.forEach(item => {
            if (!item || typeof item !== 'object' || !item.id || !item.custrecord_dashboard_classification) {
                log.error('Invalid parentArr item', { item: JSON.stringify(item) });
                return;
            }
            let key = item.id + '_' + item.custrecord_dashboard_classification;
            if (!parentMap[key]) {
                parentMap[key] = Object.assign({}, item);
            } else {
                ['actuals', 'aop', 'variance', 'pre_actuals', 'pre_variance2'].forEach(f => {
                    parentMap[key][f] = (Number(parentMap[key][f]) || 0) + (Number(item[f]) || 0);
                });
            }
        });
    }

    if (childArr && Array.isArray(childArr)) {
        childArr.forEach(item => {
            var childIdField = (queryType === 'fullyear') ? item.heading_id : item.id;
            if (!item || typeof item !== 'object' || !childIdField || !item.accountsearchdisplaynamecopy) {
                log.error('Invalid childArr item', { item: JSON.stringify(item), queryType });
                return;
            }
            let key = childIdField + '_' + item.accountsearchdisplaynamecopy;
            if (!childMap[key]) {
                childMap[key] = Object.assign({}, item);
            } else {
                ['actuals', 'aop', 'variance', 'pre_actuals', 'pre_variance2'].forEach(f => {
                    childMap[key][f] = (Number(childMap[key][f]) || 0) + (Number(item[f]) || 0);
                });
            }
        });
    }

    var parents = Object.values(parentMap).sort((a, b) => {
        return Number(a.custrecord_dashboard_classification) - Number(b.custrecord_dashboard_classification);
    });

    var children = Object.values(childMap).sort((a, b) => {
        return a.accountsearchdisplaynamecopy.localeCompare(b.accountsearchdisplaynamecopy);
    });

    log.debug('Aggregation completed', {
        queryType: queryType,
        parentCount: parents.length,
        childCount: children.length
    });

    return { parents: parents, children: children };
}


        function getYearName(accountingPeriod) {
       try{
        var accountingperiodSearchObj = search.create({
            type: "accountingperiod",
            filters: [["internalid", "anyof", accountingPeriod]],
            columns: [
                search.createColumn({
                    name: "formulatext",
                    formula: "TO_CHAR({startdate}, 'Month')",
                    label: "Month Name"
                }),
                search.createColumn({ name: "parent" }),
                search.createColumn({ name: "periodname", label: "Period Name" })
            ]
        });

        accountingperiodSearchObj.run().each(function (result) {
            monthName = result.getValue({
                name: "formulatext",
                formula: "UPPER(TO_CHAR({startdate}, 'Month'))"
            });
            var periodName = result.getValue({ name: "periodname" });
            quarterSelected = result.getValue({ name: "parent" });
            var parts = periodName.split(' ');
            if (parts.length >= 2) {
                var fullYear = parts[parts.length - 1];
                if (/\d{4}/.test(fullYear)) {
                    yearName = fullYear.slice(-2);
                } else {
                    log.error("Year not found in period name", periodName);
                    yearName = " ";
                }
            } else {
                log.error("Invalid period name format", periodName);
                yearName = " ";
            }
            log.debug("Extracted Year (last two digits)", yearName);
            return false;
        });
        return yearName;
     }
    catch(e){
        log.error("error in getYearName function",e)
        
    } 
}


function monthlyQueryRun(currPeriod, prevPeriod, subsidiaryIds){
    log.debug("attempting monthly query, units left", runtime.getCurrentScript().getRemainingUsage())
    let results=[];
    let results1=[];

 if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null)){
            log.debug("accounting period before passing month query", currPeriod)
                log.debug("subsidiary id before passing month query", subsidiaryIds)
                        log.debug("previous year period before passing month query", prevPeriod)


         results = query.runSuiteQL({
            query: "select  \
  z.id, \
  z.Classification, \
  z.name, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Actuals * -1)) \
    else round(sum(z.Actuals)) \
  end as actuals, \
  round(sum(z.AOP)) as aop, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Actuals * -1) - sum(z.AOP)) \
    else round(sum(z.AOP) - sum(z.Actuals)) \
  end as Variance, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Pre_Actuals * -1)) \
    else round(sum(z.Pre_Actuals)) \
  end as pre_actuals, \
  round(sum(z.Pre_AOP)) as Pre_aop, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Pre_Actuals * -1) - sum(z.Pre_AOP)) \
    else round(sum(z.Pre_AOP) - sum(z.Pre_Actuals)) \
  end as Pre_Variance1, \
  case  \
   WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals)) \
  end as Pre_Variance2, \
  z.custrecord_dashboard_classification \
from ( \
    select  \
      (select id from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      sum(bm.amount) as AOP, \
      0 as Pre_Actuals, \
      0 as Pre_AOP, \
      b.subsidiary \
    from budgetsmachine bm  \
      join budgets b on bm.budget = b.id   \
      join account a on a.id = b.account  \
      where b.category = 4  \
      and bm.period = "+currPeriod+" \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by a.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, b.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      sum(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) as Actuals, \
      0 as AOP, \
      0 as Pre_Actuals, \
      0 as Pre_AOP, \
      a.subsidiary \
    from transactionline a, transaction b, transactionaccountingline c, account ac \
    where a.transaction = b.id  \
      and a.id = c.transactionline \
      and b.id = c.transaction  \
      and ac.id = c.account  \
      and a.expenseaccount = ac.id \
      and b.postingperiod = "+currPeriod+" \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by ac.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, a.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      0 as AOP, \
      0 as Pre_Actuals, \
      sum(bm.amount) as Pre_AOP, \
      b.subsidiary \
    from budgetsmachine bm  \
      join budgets b on bm.budget = b.id   \
      join account a on a.id = b.account  \
    where b.category = 4  \
      and bm.period = "+prevPeriod+" \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by a.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, b.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      0 as AOP, \
      sum(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) as Pre_Actuals, \
      0 as Pre_AOP, \
      a.subsidiary \
    from transactionline a, transaction b, transactionaccountingline c, account ac \
    where a.transaction = b.id  \
      and a.id = c.transactionline \
      and b.id = c.transaction  \
      and ac.id = c.account  \
      and a.expenseaccount = ac.id \
      and b.postingperiod = "+prevPeriod+"  \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by ac.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, a.subsidiary \
) z \
where z.subsidiary = "+ subsidiaryIds + " \
group by  \
  z.name,  \
  z.custrecord_dashboard_classification,  \
  z.Classification,  \
  z.id \
order by  \
  z.custrecord_dashboard_classification,  \
  z.id;"
        }).asMappedResults();
    }
    else{
        results=[]
    }
        var startTime = new Date();
        log.debug("Query 1 executed in", (new Date() - startTime) / 1000 + " seconds");
        log.debug("parent results", results)
       
     
            log.debug("attempting child query")
            startTime = new Date();
 if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null)){
            results1 = query.runSuiteQL({
            query: "SELECT  \
  z.id, \
  z.Classification, \
  z.name, \
  z.accountsearchdisplaynamecopy, \
  z.subcategory, \
  z.acctnumber, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1)) \
    ELSE ROUND(SUM(z.Actuals)) \
  END AS actuals, \
  ROUND(SUM(z.AOP)) AS aop, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP)) \
    ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals)) \
  END AS Variance, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals)) \
  END AS pre_actuals, \
  ROUND(SUM(z.Pre_AOP)) AS Pre_aop, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Pre_Actuals * -1) - SUM(z.Pre_AOP)) \
    ELSE ROUND(SUM(z.Pre_AOP) - SUM(z.Pre_Actuals)) \
  END AS Pre_Variance1, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals)) \
  END AS Pre_Variance2, \
  z.custrecord_dashboard_classification \
FROM ( \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    SUM(bm.amount) AS AOP, \
    0 AS Pre_Actuals, \
    0 AS Pre_AOP, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary \
  FROM budgetsmachine bm  \
    JOIN budgets b ON bm.budget = b.id   \
    JOIN account a ON a.id = b.account  \
  WHERE b.category = 4  \
    AND bm.period = "+currPeriod+" \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    a.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary, \
    a.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals, \
    0 AS AOP, \
    0 AS Pre_Actuals, \
    0 AS Pre_AOP, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary \
  FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id  \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  \
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id \
  WHERE b.postingperiod = "+currPeriod+" \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    ac.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary, \
    ac.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    0 AS AOP, \
    0 AS Pre_Actuals, \
    SUM(bm.amount) AS Pre_AOP, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary \
  FROM budgetsmachine bm  \
    JOIN budgets b ON bm.budget = b.id   \
    JOIN account a ON a.id = b.account  \
  WHERE b.category = 4  \
    AND bm.period = "+prevPeriod+" \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    a.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary, \
    a.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    0 AS AOP, \
    SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Pre_Actuals, \
    0 AS Pre_AOP, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary \
  FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id  \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  \
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id \
  WHERE b.postingperiod = "+prevPeriod+" \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    ac.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary, \
    ac.custrecord_tyfone_subcategory_dashboard \
) z \
WHERE z.subsidiary = "+ subsidiaryIds + " \
GROUP BY  \
  z.id, \
  z.Classification, \
  z.name, \
  z.custrecord_dashboard_classification, \
  z.accountsearchdisplaynamecopy, \
  z.subcategory, \
  z.acctnumber \
ORDER BY  \
  z.custrecord_dashboard_classification, \
  z.id, \
  z.accountsearchdisplaynamecopy, \
  z.acctnumber;"
        }).asMappedResults();
    }
    else{
        results1=[]
    }
        log.debug("Query 2 executed in", (new Date() - startTime) / 1000 + " seconds");

       return {
    parentId: subsidiaryIds,             // the array you passed in (child subsidiaries)
    accountingPeriod: currPeriod,  // context info
    parentData: results,                 // aggregated parent totals
    childData: results1                  // granular child-level details
};
}

function quarterlyQueryRun(currPeriod, prevPeriod, subsidiaryIds){
  try {
        log.debug("attempting quarter query, units left", runtime.getCurrentScript().getRemainingUsage())
   log.debug("accounting period before passing month query", currPeriod)
                log.debug("subsidiary id before passing month query",subsidiaryIds)
                        log.debug("previous year period before passing month query",prevPeriod)

     

            var quarterQueryResults1=[]
            var quarterQueryResults2=[]


            log.debug("running qtd query...")
         if((currPeriod!=null) && (prevPeriod!=null) && (subsidiaryIds!=null)){


            quarterQueryResults1 = query.runSuiteQL({
                query: "select  \
  z.id, \
  z.Classification, \
  z.name, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Actuals * -1)) \
    else round(sum(z.Actuals)) \
  end as actuals, \
  round(sum(z.AOP)) as aop, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Actuals * -1) - sum(z.AOP)) \
    else round(sum(z.AOP) - sum(z.Actuals)) \
  end as Variance, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Pre_Actuals * -1)) \
    else round(sum(z.Pre_Actuals)) \
  end as pre_actuals, \
  round(sum(z.Pre_AOP)) as Pre_aop, \
  case  \
    when z.custrecord_dashboard_classification in (1,2,3)  \
         then round(sum(z.Pre_Actuals * -1) - sum(z.Pre_AOP)) \
    else round(sum(z.Pre_AOP) - sum(z.Pre_Actuals)) \
  end as Pre_Variance1, \
  case  \
   WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals)) \
  end as Pre_Variance2, \
  z.custrecord_dashboard_classification \
from ( \
    select  \
      (select id from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      sum(bm.amount) as AOP, \
      0 as Pre_Actuals, \
      0 as Pre_AOP, \
      b.subsidiary \
    from budgetsmachine bm  \
      join budgets b on bm.budget = b.id   \
      join account a on a.id = b.account  \
      where b.category = 4  \
      and bm.period = " +currPeriod+ "\
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by a.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, b.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      sum(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) as Actuals, \
      0 as AOP, \
      0 as Pre_Actuals, \
      0 as Pre_AOP, \
      a.subsidiary \
    from transactionline a, transaction b, transactionaccountingline c, account ac \
    where a.transaction = b.id  \
      and a.id = c.transactionline \
      and b.id = c.transaction  \
      and ac.id = c.account  \
      and a.expenseaccount = ac.id \
      and b.postingperiod = " +currPeriod+ " \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by ac.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, a.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      0 as AOP, \
      0 as Pre_Actuals, \
      sum(bm.amount) as Pre_AOP, \
      b.subsidiary \
    from budgetsmachine bm  \
      join budgets b on bm.budget = b.id   \
      join account a on a.id = b.account  \
    where b.category = 4  \
      and bm.period = " +prevPeriod+ " \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by a.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, b.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      0 as AOP, \
      sum(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) as Pre_Actuals, \
      0 as Pre_AOP, \
      a.subsidiary \
    from transactionline a, transaction b, transactionaccountingline c, account ac \
    where a.transaction = b.id  \
      and a.id = c.transactionline \
      and b.id = c.transaction  \
      and ac.id = c.account  \
      and a.expenseaccount = ac.id \
      and b.postingperiod = " +prevPeriod+ " \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by ac.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, a.subsidiary \
) z \
where z.subsidiary = " +subsidiaryIds+ " \
group by  \
  z.name,  \
  z.custrecord_dashboard_classification,  \
  z.Classification,  \
  z.id \
order by  \
  z.custrecord_dashboard_classification,  \
  z.id;"}).asMappedResults();
            }
            else{
                quarterQueryResults1=[]
            }
            log.debug("quarter parent", quarterQueryResults1)
           
                     if((currPeriod!=null) && (prevPeriod!=null) && (subsidiaryIds!=null)){

            quarterQueryResults2 = query.runSuiteQL({
                query: "SELECT  \
  z.id, \
  z.Classification, \
  z.name, \
  z.accountsearchdisplaynamecopy, \
  z.subcategory, \
  z.acctnumber, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1)) \
    ELSE ROUND(SUM(z.Actuals)) \
  END AS actuals, \
  ROUND(SUM(z.AOP)) AS aop, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP)) \
    ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals)) \
  END AS Variance, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals)) \
  END AS pre_actuals, \
  ROUND(SUM(z.Pre_AOP)) AS Pre_aop, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Pre_Actuals * -1) - SUM(z.Pre_AOP)) \
    ELSE ROUND(SUM(z.Pre_AOP) - SUM(z.Pre_Actuals)) \
  END AS Pre_Variance1, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals)) \
  END AS Pre_Variance2, \
  z.custrecord_dashboard_classification \
FROM ( \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    SUM(bm.amount) AS AOP, \
    0 AS Pre_Actuals, \
    0 AS Pre_AOP, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary \
  FROM budgetsmachine bm  \
    JOIN budgets b ON bm.budget = b.id   \
    JOIN account a ON a.id = b.account  \
  WHERE b.category = 4  \
    AND bm.period = " +currPeriod+ " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    a.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary, \
    a.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals, \
    0 AS AOP, \
    0 AS Pre_Actuals, \
    0 AS Pre_AOP, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary \
  FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id  \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  \
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id \
  WHERE b.postingperiod = " +currPeriod+ " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    ac.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary, \
    ac.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    0 AS AOP, \
    0 AS Pre_Actuals, \
    SUM(bm.amount) AS Pre_AOP, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary \
  FROM budgetsmachine bm  \
    JOIN budgets b ON bm.budget = b.id   \
    JOIN account a ON a.id = b.account  \
  WHERE b.category = 4  \
    AND bm.period = " +prevPeriod+ " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    a.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary, \
    a.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    0 AS AOP, \
    SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Pre_Actuals, \
    0 AS Pre_AOP, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary \
  FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id  \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  \
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id \
  WHERE b.postingperiod = " +prevPeriod+ " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    ac.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary, \
    ac.custrecord_tyfone_subcategory_dashboard \
) z \
WHERE z.subsidiary = " +subsidiaryIds+ " \
GROUP BY  \
  z.id, \
  z.Classification, \
  z.name, \
  z.custrecord_dashboard_classification, \
  z.accountsearchdisplaynamecopy, \
  z.subcategory, \
  z.acctnumber \
ORDER BY  \
  z.custrecord_dashboard_classification, \
  z.id, \
  z.accountsearchdisplaynamecopy, \
  z.acctnumber;" }).asMappedResults();
            log.debug("quarter child", quarterQueryResults2)
        }
        else{
            quarterQueryResults2=[]
        }
    }
        catch (e) {
            log.error("error in quarter query execution", e)
            
        }
          return {
    parentId: subsidiaryIds,             // the array you passed in (child subsidiaries)
    accountingPeriod: currPeriod,  // context info
    parentData: quarterQueryResults1,                 // aggregated parent totals
    childData: quarterQueryResults2                  // granular child-level details
};
}

function ytdQueryRun(currPeriod, prevPeriod, subsidiaryIds){
try{
                log.debug("attempting ytd query, units left", runtime.getCurrentScript().getRemainingUsage())
                   log.debug("accounting period before passing month query",currPeriod)
                log.debug("subsidiary id before passing month query", subsidiaryIds)
                        log.debug("previous year period before passing month query", prevPeriod)


     var ytdMappedResults
        var parentResults = []
        var childResults = []
       
     

 if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null)){
           parentResults =
            query.runSuiteQL({
                query: "select \
  z.id, \
  z.Classification, \
  z.name, \
  case \
    when z.custrecord_dashboard_classification in (1,2,3) \
         then round(sum(z.Actuals * -1)) \
    else round(sum(z.Actuals)) \
  end as actuals, \
  round(sum(z.AOP)) as aop, \
  case \
    when z.custrecord_dashboard_classification in (1,2,3) \
         then round(sum(z.Actuals * -1) - sum(z.AOP)) \
    else round(sum(z.AOP) - sum(z.Actuals)) \
  end as Variance, \
  case \
    when z.custrecord_dashboard_classification in (1,2,3) \
         then round(sum(z.Pre_Actuals * -1)) \
    else round(sum(z.Pre_Actuals)) \
  end as pre_actuals, \
  round(sum(z.Pre_AOP)) as Pre_aop, \
  case \
    when z.custrecord_dashboard_classification in (1,2,3) \
         then round(sum(z.Pre_Actuals * -1) - sum(z.Pre_AOP)) \
    else round(sum(z.Pre_AOP) - sum(z.Pre_Actuals)) \
  end as Pre_Variance1, \
  case \
   WHEN z.custrecord_dashboard_classification IN (1,2,3) \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals)) \
  end as Pre_Variance2, \
  z.custrecord_dashboard_classification \
from ( \
    select \
      (select id from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      sum(bm.amount) as AOP, \
      0 as Pre_Actuals, \
      0 as Pre_AOP, \
      b.subsidiary \
    from budgetsmachine bm  \
      join budgets b on bm.budget = b.id   \
      join account a on a.id = b.account  \
      where b.category = 4  \
      and bm.period = "+ currPeriod + " \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by a.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, b.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      sum(BUILTIN.CONSOLIDATE(c.amount, \'INCOME\', \'DEFAULT\', \'DEFAULT\', 7, b.postingperiod, \'DEFAULT\')) as Actuals, \
      0 as AOP, \
      0 as Pre_Actuals, \
      0 as Pre_AOP, \
      a.subsidiary \
    from transactionline a, transaction b, transactionaccountingline c, account ac \
    where a.transaction = b.id  \
      and a.id = c.transactionline \
      and b.id = c.transaction  \
      and ac.id = c.account  \
      and a.expenseaccount = ac.id \
      and b.postingperiod = "+ currPeriod + " \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by ac.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, a.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = a.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      0 as AOP, \
      0 as Pre_Actuals, \
      sum(bm.amount) as Pre_AOP, \
      b.subsidiary \
    from budgetsmachine bm  \
      join budgets b on bm.budget = b.id   \
      join account a on a.id = b.account  \
    where b.category = 4  \
      and bm.period = "+ prevPeriod + " \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by a.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, b.subsidiary \
    union all \
    select  \
      (select id from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as id, \
      (select name from customrecord_dashboard1_classification where id = custrecord_dashboard_classification) as Classification, \
      (select name from customrecord_dashboard1_heading where id = ac.custrecord_dashboard1_heading_tyfone) as name, \
      custrecord_dashboard_classification, \
      0 as Actuals, \
      0 as AOP, \
      sum(BUILTIN.CONSOLIDATE(c.amount, \'INCOME\', \'DEFAULT\', \'DEFAULT\', 7, b.postingperiod, \'DEFAULT\')) as Pre_Actuals, \
      0 as Pre_AOP, \
      a.subsidiary \
    from transactionline a, transaction b, transactionaccountingline c, account ac \
    where a.transaction = b.id  \
      and a.id = c.transactionline \
      and b.id = c.transaction  \
      and ac.id = c.account  \
      and a.expenseaccount = ac.id \
      and b.postingperiod = "+ prevPeriod + " \
      and custrecord_dashboard_classification in (1,2,3,4,5,6,7) \
    group by ac.custrecord_dashboard1_heading_tyfone, custrecord_dashboard_classification, a.subsidiary \
) z \
where z.subsidiary = "+ subsidiaryIds + " \
group by  \
  z.name,  \
  z.custrecord_dashboard_classification,  \
  z.Classification,  \
  z.id \
order by  \
  z.custrecord_dashboard_classification,  \
  z.id;"

                // params: [stringArray, stringArray, previousYearsMonths, previousYearsMonths, subsidiaryIds]
            }).asMappedResults()
        }
        else{
            parentResults=[]
        }

        log.debug("ytd parent results", parentResults)



    if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null)){
        // run child query for this subsidiary
        childResults = query.runSuiteQL({
            query: "SELECT  \
  z.id, \
  z.Classification, \
  z.name, \
  z.accountsearchdisplaynamecopy, \
  z.subcategory, \
  z.acctnumber, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1)) \
    ELSE ROUND(SUM(z.Actuals)) \
  END AS actuals, \
  ROUND(SUM(z.AOP)) AS aop, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP)) \
    ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals)) \
  END AS Variance, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals)) \
  END AS pre_actuals, \
  ROUND(SUM(z.Pre_AOP)) AS Pre_aop, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Pre_Actuals * -1) - SUM(z.Pre_AOP)) \
    ELSE ROUND(SUM(z.Pre_AOP) - SUM(z.Pre_Actuals)) \
  END AS Pre_Variance1, \
  CASE  \
    WHEN z.custrecord_dashboard_classification IN (1,2,3)  \
      THEN ROUND(SUM(z.Actuals * -1) - SUM(z.Pre_Actuals * -1)) \
    ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals)) \
  END AS Pre_Variance2, \
  z.custrecord_dashboard_classification \
FROM ( \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    SUM(bm.amount) AS AOP, \
    0 AS Pre_Actuals, \
    0 AS Pre_AOP, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary \
  FROM budgetsmachine bm  \
    JOIN budgets b ON bm.budget = b.id   \
    JOIN account a ON a.id = b.account  \
  WHERE b.category = 4  \
    AND bm.period = "+ currPeriod + " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    a.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary, \
    a.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals, \
    0 AS AOP, \
    0 AS Pre_Actuals, \
    0 AS Pre_AOP, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary \
  FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id  \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  \
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id \
  WHERE b.postingperiod = "+ currPeriod + " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    ac.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary, \
    ac.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    0 AS AOP, \
    0 AS Pre_Actuals, \
    SUM(bm.amount) AS Pre_AOP, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary \
  FROM budgetsmachine bm  \
    JOIN budgets b ON bm.budget = b.id   \
    JOIN account a ON a.id = b.account  \
  WHERE b.category = 4  \
    AND bm.period = "+ prevPeriod + " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    a.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    a.accountsearchdisplaynamecopy, \
    a.acctnumber, \
    b.subsidiary, \
    a.custrecord_tyfone_subcategory_dashboard \
 \
  UNION ALL \
 \
  SELECT  \
    (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id, \
    (SELECT name FROM customrecord_dashboard1_classification WHERE id = custrecord_dashboard_classification) AS Classification, \
    (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name, \
    (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
    custrecord_dashboard_classification, \
    0 AS Actuals, \
    0 AS AOP, \
    SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Pre_Actuals, \
    0 AS Pre_AOP, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary \
  FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id  \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  \
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id \
  WHERE b.postingperiod = "+ prevPeriod + " \
    AND custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
  GROUP BY  \
    ac.custrecord_dashboard1_heading_tyfone, \
    custrecord_dashboard_classification, \
    ac.accountsearchdisplaynamecopy, \
    ac.acctnumber, \
    a.subsidiary, \
    ac.custrecord_tyfone_subcategory_dashboard \
) z \
WHERE z.subsidiary = "+ subsidiaryIds + " \
GROUP BY  \
  z.id, \
  z.Classification, \
  z.name, \
  z.custrecord_dashboard_classification, \
  z.accountsearchdisplaynamecopy, \
  z.subcategory, \
  z.acctnumber \
ORDER BY  \
  z.custrecord_dashboard_classification, \
  z.id, \
  z.accountsearchdisplaynamecopy, \
  z.acctnumber;"
            //   params: [stringArray, stringArray, previousYearsMonths, previousYearsMonths, subsidiaryIds]
        }).asMappedResults()

    }
    else{
        childResults=[]
    }
        log.debug("ytd child results", childResults)

    }
    catch(e){
        log.error("error in ytd query function",e)
    }
return {
    parentId: subsidiaryIds,             // the array you passed in (child subsidiaries)
    accountingPeriod: currPeriod,  // context info
    parentData: parentResults,                 // aggregated parent totals
    childData: childResults                  // granular child-level details
};

}

function fullYearQueryRun(currPeriod, prevPeriod, subsidiaryIds, monthNumber){
    try{
            log.debug("attempting full year query, units left", runtime.getCurrentScript().getRemainingUsage())
               log.debug("accounting period before passing month query", currPeriod)
                log.debug("subsidiary id before passing month query", subsidiaryIds)
                        log.debug("previous year period before passing month query", prevPeriod)


  

        var parentResults = [];
        var childResults = [];


        // var fullYMonthNumbers = getMonthNumbersFromPeriods(financialYearMonthsFullY);
        // log.debug("fullY month numbers", fullYMonthNumbers)
        // var fullYPlaceHolders = fullYMonthNumbers.map(() => '?').join(',');



var budgetId=getBudgetId(monthNumber);



          try{
        if (monthNumber!= 3) {
         
 if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null) && (budgetId!=null)){

            parentResults = query.runSuiteQL({
                query: "SELECT \
    z.id, \
    z.Classification, \
    z.name, \
    ROUND(SUM(z.Actuals)) AS actuals, \
    ROUND(SUM(z.AOP))     AS aop, \
    CASE \
        WHEN z.custrecord_dashboard_classification IN (1,2,3) \
             THEN ROUND(SUM(z.Actuals) - SUM(z.AOP)) \
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals)) \
    END AS Variance, \
    CASE \
        WHEN z.custrecord_dashboard_classification IN (1,2,3) \
             THEN ROUND(SUM(z.prev_Actuals) * -1) \
        ELSE ROUND(SUM(z.prev_Actuals)) \
    END AS pre_actuals, \
    CASE \
        WHEN z.custrecord_dashboard_classification IN (1,2,3) \
             THEN ROUND(SUM(z.Actuals) - (SUM(z.prev_Actuals * -1))) \
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals)) \
    END AS Pre_Variance2, \
    z.custrecord_dashboard_classification \
FROM ( \
    /* ───── Budget AOP ───── */ \
    SELECT \
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification, \
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
        a.custrecord_dashboard_classification, \
        0                       AS Actuals, \
        SUM(bm.amount)          AS AOP, \
        0                       AS prev_Actuals, \
        0                       AS prev_AOP, \
        b.subsidiary            AS subsidiary, \
        b.department            AS department \
    FROM budgetsmachine bm \
    JOIN budgets  b ON bm.budget = b.id \
    JOIN account  a ON a.id     = b.account \
    WHERE b.category = 4 \
      AND bm.period = "+ currPeriod +" \
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY \
        a.custrecord_dashboard_classification, \
        a.custrecord_dashboard1_heading_tyfone, \
        b.subsidiary, \
        b.department \
 \
    UNION ALL \
 \
    /* ───── Current Actuals ───── */ \
    SELECT \
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification, \
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
        a.custrecord_dashboard_classification, \
        SUM(bm.amount)          AS Actuals, \
        0                       AS AOP, \
        0                       AS prev_Actuals, \
        0                       AS prev_AOP, \
        b.subsidiary            AS subsidiary, \
        b.department            AS department \
    FROM budgetsmachine bm \
    JOIN budgets  b ON bm.budget = b.id \
    JOIN account  a ON a.id     = b.account \
    WHERE b.category ="+ budgetId +" \
      AND bm.period = "+ currPeriod +" \
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY \
        a.custrecord_dashboard_classification, \
        a.custrecord_dashboard1_heading_tyfone, \
        b.subsidiary, \
        b.department \
 \
    UNION ALL \
 \
    /* ───── Previous AOP ───── */ \
    SELECT \
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id, \
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification, \
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
        a.custrecord_dashboard_classification, \
        0                       AS Actuals, \
        0                       AS AOP, \
        0                       AS prev_Actuals, \
        SUM(bm.amount)          AS prev_AOP, \
        b.subsidiary            AS subsidiary, \
        b.department            AS department \
    FROM budgetsmachine bm \
    JOIN budgets  b ON bm.budget = b.id \
    JOIN account  a ON a.id     = b.account \
    WHERE b.category = 4 \
      AND bm.period = "+ prevPeriod +" \
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY \
        a.custrecord_dashboard_classification, \
        a.custrecord_dashboard1_heading_tyfone, \
        b.subsidiary, \
        b.department \
 \
    UNION ALL \
 \
    /* ───── Previous Actuals ───── */ \
    SELECT \
        h.id, \
        dc.name                           AS Classification, \
        h.name, \
        dc.id                             AS custrecord_dashboard_classification, \
        0                                 AS Actuals, \
        0                                 AS AOP, \
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS prev_Actuals, \
        0                                 AS prev_AOP, \
        a.subsidiary                      AS subsidiary, \
        a.department                      AS department \
    FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction \
    JOIN account ac ON ac.id = c.account \
    JOIN customrecord_dashboard1_heading       h  ON h.id  = ac.custrecord_dashboard1_heading_tyfone \
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification \
    WHERE b.postingperiod = "+ prevPeriod +" \
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY \
        dc.id, dc.name, \
        h.id, h.name, \
        a.subsidiary, \
        a.department \
) z \
WHERE z.subsidiary = "+ subsidiaryIds +" \
GROUP BY \
    z.id, \
    z.Classification, \
    z.name, \
    z.custrecord_dashboard_classification \
ORDER BY \
    z.custrecord_dashboard_classification, \
    z.id;"
            }).asMappedResults()
        }
        else{
            parentResults=[]
        }
            log.debug("parent results if Part", parentResults)

 if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null)){

            childResults = query.runSuiteQL({
                query: "SELECT \
    z.heading_id, \
    z.Classification, \
    z.name, \
    z.accountsearchdisplaynamecopy, \
    z.acctnumber, \
    z.subcategory, \
    ROUND(SUM(z.Actuals))              AS actuals, \
    ROUND(SUM(z.AOP))                  AS aop, \
 \
    /* current variance */ \
    CASE \
        WHEN z.custrecord_dashboard_classification IN (1,2,3) \
             THEN ROUND(SUM(z.Actuals) - SUM(z.AOP)) \
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals)) \
    END                                AS Variance, \
 \
    /* previous actuals (sign-flip for 1-3) */ \
    CASE \
        WHEN z.custrecord_dashboard_classification IN (1,2,3) \
             THEN ROUND(SUM(z.prev_Actuals) * -1) \
        ELSE ROUND(SUM(z.prev_Actuals)) \
    END                                AS pre_actuals, \
 \
    /* variance vs. previous period */ \
    CASE \
        WHEN z.custrecord_dashboard_classification IN (1,2,3) \
             THEN ROUND(SUM(z.Actuals)        - (SUM(z.prev_Actuals) * -1)) \
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals)) \
    END                                AS Pre_Variance2, \
 \
    z.custrecord_dashboard_classification \
FROM ( \
    /* ───── Budget AOP ───── */ \
    SELECT \
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS heading_id, \
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification, \
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
        a.accountsearchdisplaynamecopy, \
        a.acctnumber, \
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD \
                WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
        a.custrecord_dashboard_classification, \
        0                       AS Actuals, \
        SUM(bm.amount)          AS AOP, \
        0                       AS prev_Actuals, \
        0                       AS prev_AOP, \
        b.subsidiary \
    FROM budgetsmachine bm \
    JOIN budgets  b ON bm.budget = b.id \
    JOIN account  a ON a.id     = b.account \
    WHERE b.category = 4 \
      AND bm.period = "+ currPeriod + " \
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY a.custrecord_dashboard1_heading_tyfone, \
             a.custrecord_dashboard_classification, \
             a.accountsearchdisplaynamecopy, \
             a.acctnumber, \
             a.custrecord_tyfone_subcategory_dashboard, \
             b.subsidiary \
 \
    UNION ALL \
 \
    /* ───── Current Actuals ───── */ \
    SELECT \
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS heading_id, \
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification, \
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
        a.accountsearchdisplaynamecopy, \
        a.acctnumber, \
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD \
                WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
        a.custrecord_dashboard_classification, \
        SUM(bm.amount)          AS Actuals, \
        0                       AS AOP, \
        0                       AS prev_Actuals, \
        0                       AS prev_AOP, \
        b.subsidiary \
    FROM budgetsmachine bm \
    JOIN budgets  b ON bm.budget = b.id \
    JOIN account  a ON a.id     = b.account \
    WHERE b.category = "+ budgetId + " \
      AND bm.period = "+ currPeriod + " \
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY a.custrecord_dashboard1_heading_tyfone, \
             a.custrecord_dashboard_classification, \
             a.accountsearchdisplaynamecopy, \
             a.acctnumber, \
             a.custrecord_tyfone_subcategory_dashboard, \
             b.subsidiary \
 \
    UNION ALL \
 \
    /* ───── Previous AOP ───── */ \
    SELECT \
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS heading_id, \
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification, \
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name, \
        a.accountsearchdisplaynamecopy, \
        a.acctnumber, \
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD \
                WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
        a.custrecord_dashboard_classification, \
        0                       AS Actuals, \
        0                       AS AOP, \
        0                       AS prev_Actuals, \
        SUM(bm.amount)          AS prev_AOP, \
        b.subsidiary \
    FROM budgetsmachine bm \
    JOIN budgets  b ON bm.budget = b.id \
    JOIN account  a ON a.id     = b.account \
    WHERE b.category = 4 \
      AND bm.period = "+ prevPeriod + " \
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY a.custrecord_dashboard1_heading_tyfone, \
             a.custrecord_dashboard_classification, \
             a.accountsearchdisplaynamecopy, \
             a.acctnumber, \
             a.custrecord_tyfone_subcategory_dashboard, \
             b.subsidiary \
 \
    UNION ALL \
 \
    /* ───── Previous Actuals ───── */ \
    SELECT \
        h.id                           AS heading_id, \
        dc.name                        AS Classification, \
        h.name, \
        ac.accountsearchdisplaynamecopy, \
        ac.acctnumber, \
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD \
                WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory, \
        dc.id                          AS custrecord_dashboard_classification, \
        0                              AS Actuals, \
        0                              AS AOP, \
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS prev_Actuals, \
        0                              AS prev_AOP, \
        a.subsidiary \
    FROM transactionline a \
    JOIN transaction b ON a.transaction = b.id \
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction \
    JOIN account ac ON ac.id = c.account \
    JOIN customrecord_dashboard1_heading       h  ON h.id  = ac.custrecord_dashboard1_heading_tyfone \
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification \
    WHERE b.postingperiod = "+ prevPeriod + " \
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) \
    GROUP BY dc.id, dc.name, h.id, h.name, \
             ac.accountsearchdisplaynamecopy, \
             ac.acctnumber, \
             ac.custrecord_tyfone_subcategory_dashboard, \
             a.subsidiary \
) z \
WHERE z.subsidiary = "+ subsidiaryIds + " \
GROUP BY \
    z.heading_id, \
    z.Classification, \
    z.name, \
    z.accountsearchdisplaynamecopy, \
    z.acctnumber, \
    z.subcategory, \
    z.custrecord_dashboard_classification \
ORDER BY \
    z.custrecord_dashboard_classification, \
    z.heading_id, \
    z.subcategory;"
            }).asMappedResults()
        }
            log.debug("child results", childResults)

        }
        else {
            log.audit("else part of fullyear",monthNumber)
                  var subsidiaryArray = Array.isArray(subsidiaryIds) ? subsidiaryIds : [subsidiaryIds];
    // Ensure the single value is numeric and valid
    subsidiaryArray = subsidiaryArray.filter(function(id) {
        return id != null && !isNaN(id) && Number.isInteger(Number(id));
    });

    log.audit("subsidiary id after sanitation",subsidiaryArray)
var parameters=[currPeriod, currPeriod, prevPeriod, prevPeriod, subsidiaryArray[0]]
log.audit("parameters before passing",parameters)
 if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null)){
            parentResults = query.runSuiteQL({
                query: `SELECT
            z.id,
            z.Classification,
            z.name,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.Actuals * -1))
                ELSE ROUND(SUM(z.Actuals))
            END AS actuals,
            ROUND(SUM(z.AOP)) AS aop,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP))
                ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
            END AS Variance,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.Pre_Actuals * -1))
                ELSE ROUND(SUM(z.Pre_Actuals))
            END AS pre_actuals,
            ROUND(SUM(z.Pre_AOP)) AS Pre_aop,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.Actuals * -1) - (SUM(z.Pre_Actuals * -1)))
                ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals))
            END AS Pre_Variance2,
            z.custrecord_dashboard_classification
        FROM (
            -- Budget AOP
            SELECT
                (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
                (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
                (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
                a.custrecord_dashboard_classification,
                0 AS Actuals,
                SUM(bm.amount) AS AOP,
                0 AS Pre_Actuals,
                0 AS Pre_AOP,
                b.subsidiary AS subsidiary
            FROM budgetsmachine bm
            JOIN budgets b ON bm.budget = b.id
            JOIN account a ON a.id = b.account
            WHERE b.category IN (4)
                AND bm.period = ?
                AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                a.custrecord_dashboard_classification,
                a.custrecord_dashboard1_heading_tyfone,
                b.subsidiary
            UNION ALL
            -- Actuals
            SELECT
                (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id,
                (SELECT name FROM customrecord_dashboard1_classification WHERE id = ac.custrecord_dashboard_classification) AS Classification,
                (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name,
                ac.custrecord_dashboard_classification,
                SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals,
                0 AS AOP,
                0 AS Pre_Actuals,
                0 AS Pre_AOP,
                a.subsidiary AS subsidiary
            FROM transactionline a
            JOIN transaction b ON a.transaction = b.id
            JOIN transactionaccountingline c ON b.id = c.transaction AND a.id = c.transactionline
            JOIN account ac ON ac.id = c.account
            WHERE a.expenseaccount = ac.id
                AND b.postingperiod = ?
                AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                ac.custrecord_dashboard1_heading_tyfone,
                ac.custrecord_dashboard_classification,
                a.subsidiary
            UNION ALL
            -- Previous AOP
            SELECT
                (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
                (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
                (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
                a.custrecord_dashboard_classification,
                0 AS Actuals,
                0 AS AOP,
                0 AS Pre_Actuals,
                SUM(bm.amount) AS Pre_AOP,
                b.subsidiary AS subsidiary
            FROM budgetsmachine bm
            JOIN budgets b ON bm.budget = b.id
            JOIN account a ON a.id = b.account
            WHERE b.category = 4
                AND bm.period = ?
                AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                a.custrecord_dashboard_classification,
                a.custrecord_dashboard1_heading_tyfone,
                b.subsidiary
            UNION ALL
            -- Previous Actuals
            SELECT
                h.id,
                dc.name AS Classification,
                h.name,
                dc.id AS custrecord_dashboard_classification,
                0 AS Actuals,
                0 AS AOP,
                SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Pre_Actuals,
                0 AS Pre_AOP,
                a.subsidiary AS subsidiary
            FROM transactionline a
            JOIN transaction b ON a.transaction = b.id
            JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
            JOIN account ac ON ac.id = c.account
            JOIN customrecord_dashboard1_heading h ON h.id = ac.custrecord_dashboard1_heading_tyfone
            JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification
            WHERE b.postingperiod = ?
                AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                dc.id,
                dc.name,
                h.id,
                h.name,
                a.subsidiary
        ) z
        WHERE z.subsidiary = ?
        GROUP BY
            z.name,
            z.custrecord_dashboard_classification,
            z.Classification,
            z.id
        ORDER BY
            z.custrecord_dashboard_classification,
            z.id`, params: parameters}).asMappedResults()
            }
            else{
                parentResults=[]
            }
            log.debug("parent results", parentResults)
 if(currPeriod!=null && (subsidiaryIds!=null) && (prevPeriod!=null)){
            childResults = query.runSuiteQL({
                query: `SELECT
            z.heading_id,
            z.Classification,
            z.name,
            z.accountsearchdisplaynamecopy,
            z.acctnumber,
            z.subcategory,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.Actuals * -1))
                ELSE ROUND(SUM(z.Actuals))
            END AS actuals,
            ROUND(SUM(z.AOP)) AS aop,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP))
                ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
            END AS Variance,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.prev_Actuals * -1))
                ELSE ROUND(SUM(z.prev_Actuals))
            END AS pre_actuals,
            ROUND(SUM(z.prev_AOP)) AS prev_aop1,
            CASE
                WHEN z.custrecord_dashboard_classification IN (1,2,3)
                    THEN ROUND(SUM(z.Actuals * -1) - (SUM(z.prev_Actuals * -1)))
                ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals))
            END AS Pre_Variance2,
            z.custrecord_dashboard_classification
        FROM (
            -- Budget AOP
            SELECT
                (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS heading_id,
                (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
                (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
                a.accountsearchdisplaynamecopy,
                a.acctnumber,
                (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory,
                a.custrecord_dashboard_classification,
                0 AS Actuals,
                SUM(bm.amount) AS AOP,
                0 AS prev_Actuals,
                0 AS prev_AOP,
                b.subsidiary AS subsidiary
            FROM budgetsmachine bm
            JOIN budgets b ON bm.budget = b.id
            JOIN account a ON a.id = b.account
            WHERE b.category IN (4)
                AND bm.period = ?
                AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                a.custrecord_dashboard1_heading_tyfone,
                a.custrecord_dashboard_classification,
                a.accountsearchdisplaynamecopy,
                a.acctnumber,
                a.custrecord_tyfone_subcategory_dashboard,
                b.subsidiary
            UNION ALL
            -- Actuals
            SELECT
                (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS heading_id,
                (SELECT name FROM customrecord_dashboard1_classification WHERE id = ac.custrecord_dashboard_classification) AS Classification,
                (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name,
                ac.accountsearchdisplaynamecopy,
                ac.acctnumber,
                (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory,
                ac.custrecord_dashboard_classification,
                SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals,
                0 AS AOP,
                0 AS prev_Actuals,
                0 AS prev_AOP,
                a.subsidiary AS subsidiary
            FROM transactionline a
            JOIN transaction b ON a.transaction = b.id
            JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
            JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id
            WHERE b.postingperiod = ?
                AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                ac.custrecord_dashboard1_heading_tyfone,
                ac.custrecord_dashboard_classification,
                ac.accountsearchdisplaynamecopy,
                ac.acctnumber,
                ac.custrecord_tyfone_subcategory_dashboard,
                a.subsidiary
            UNION ALL
            -- Previous AOP
            SELECT
                (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS heading_id,
                (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
                (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
                a.accountsearchdisplaynamecopy,
                a.acctnumber,
                (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory,
                a.custrecord_dashboard_classification,
                0 AS Actuals,
                0 AS AOP,
                0 AS prev_Actuals,
                SUM(bm.amount) AS prev_AOP,
                b.subsidiary AS subsidiary
            FROM budgetsmachine bm
            JOIN budgets b ON bm.budget = b.id
            JOIN account a ON a.id = b.account
            WHERE b.category = 4
                AND bm.period = ?
                AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                a.custrecord_dashboard1_heading_tyfone,
                a.custrecord_dashboard_classification,
                a.accountsearchdisplaynamecopy,
                a.acctnumber,
                a.custrecord_tyfone_subcategory_dashboard,
                b.subsidiary
            UNION ALL
            -- Previous Actuals
            SELECT
                h.id AS heading_id,
                dc.name AS Classification,
                h.name,
                ac.accountsearchdisplaynamecopy,
                ac.acctnumber,
                (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory,
                dc.id AS custrecord_dashboard_classification,
                0 AS Actuals,
                0 AS AOP,
                SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS prev_Actuals,
                0 AS prev_AOP,
                a.subsidiary AS subsidiary
            FROM transactionline a
            JOIN transaction b ON a.transaction = b.id
            JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
            JOIN account ac ON ac.id = c.account
            JOIN customrecord_dashboard1_heading h ON h.id = ac.custrecord_dashboard1_heading_tyfone
            JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification
            WHERE b.postingperiod = ?
                AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
            GROUP BY
                dc.id,
                dc.name,
                h.id,
                h.name,
                ac.accountsearchdisplaynamecopy,
                ac.acctnumber,
                ac.custrecord_tyfone_subcategory_dashboard,
                a.subsidiary
        ) z
        WHERE z.subsidiary = ?
        GROUP BY
            z.heading_id,
            z.Classification,
            z.name,
            z.accountsearchdisplaynamecopy,
            z.acctnumber,
            z.subcategory,
            z.custrecord_dashboard_classification
        ORDER BY
            z.custrecord_dashboard_classification,
            z.heading_id,
            z.subcategory`, params: parameters}).asMappedResults()
            }
            else{
                childResults=[]
            }

            log.debug("child results", childResults)


        }
    }
        catch(e){
            log.error("error in full year query execution",e)
            

        }
    }
    catch(error){
log.error("error in full year query function",error)
    }

return {
    parentId: subsidiaryIds,             // the array you passed in (child subsidiaries)
    accountingPeriod: currPeriod,  // context info
    parentData: parentResults,                 // aggregated parent totals
    childData: childResults                  // granular child-level details
};



}

    function monthlyQueryResults(results, results1, parameters, subsidiaryChildPlaceHolders, subsidiaryIds, accountingPeriod, previousYearPeriod, subsidiary, aprilId, tableHtml) {

try{
                    log.debug("main month function, units left", runtime.getCurrentScript().getRemainingUsage())

    // subsidiaryChildPlaceHolders = subsidiaryIds.map(item => "?").join(",");

    log.debug("subsidiaryChildPlaceHolders",subsidiaryChildPlaceHolders)
    log.debug("subsidiary ids for parameters",subsidiaryIds)

        log.debug("subsidiary in entry month function", subsidiary)
        var arrPart = '';
        var arrActTotal;
        var arrAopTotal;
        var arrDiff;
        var arrPer;
        var yearName;
        var monthName;

        var monthNumber = 0;


        var quarterSelected;
        try {
            var accountingperiodSearchObj = search.create({
                type: "accountingperiod",
                filters: [["internalid", "anyof", accountingPeriod]],
                columns: [
                    search.createColumn({
                        name: "formulatext",
                        formula: "TO_CHAR({startdate}, 'Month')",
                        label: "Month Name"
                    }),
                    search.createColumn({ name: "parent" }),
                    search.createColumn({ name: "periodname", label: "Period Name" })
                ]
            });

            accountingperiodSearchObj.run().each(function (result) {
                monthName = result.getValue({
                    name: "formulatext",
                    formula: "UPPER(TO_CHAR({startdate}, 'Month'))"
                });
                var periodName = result.getValue({ name: "periodname" });
                quarterSelected = result.getValue({ name: "parent" });
                var parts = periodName.split(' ');
                if (parts.length >= 2) {
                    var fullYear = parts[parts.length - 1];
                    if (/\d{4}/.test(fullYear)) {
                        yearName = fullYear.slice(-2);
                    } else {
                        log.error("Year not found in period name", periodName);
                        yearName = " ";
                    }
                } else {
                    log.error("Invalid period name format", periodName);
                    yearName = " ";
                }
                log.debug("Extracted Year (last two digits)", yearName);
                return false;
            });

            var accountingperiodSearchObj1 = search.create({
                type: "accountingperiod",
                filters: [["internalid", "anyof", quarterSelected]],
                columns: [search.createColumn({ name: "parent", label: "Parent" })]
            });

            accountingperiodSearchObj1.run().each(function (result) {
                fyName = result.getText({ name: "parent" });
                return false;
            });

            log.debug("Extracted Month Name", monthName);
            const months = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
                "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
            monthNumber = months.indexOf(monthName.trim().toUpperCase()) + 1;
            log.debug("month number", monthNumber);
            log.debug("yearName", yearName);
            



        }
        catch (e) {
            log.error("heading generation error", e)
        }







        var clientParams = [accountingPeriod, ...subsidiaryIds];

        let clientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period = ? 
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;
`;

        let aprilExistingClientsQuery = `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary
    UNION ALL
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;
`;

        let arrNetQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
 z.period = ? and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;
`;

        let newClientsAop = 0, attritionAop = 0, existingAop = 0, existingAct = 0, attritionAct = 0, newClientsAct = 0;
        let totalClientsAct = 0, totalClientsAop = 0;
log.debug("attempting to run client results query")
log.debug("clientQuery", clientQuery);
log.debug("clientParams", JSON.stringify(clientParams));
log.debug("subsidiaryIds", JSON.stringify(subsidiaryIds));
log.debug("accountingPeriod", accountingPeriod);
let clientResults;
 if((accountingPeriod!=null) && (subsidiaryIds.length>0)){
         clientResults= query.runSuiteQL({ query: clientQuery, params: clientParams }).asMappedResults();
 }
 else{
    clientResults=[]
 }
        log.debug("client results month", JSON.stringify(clientResults));
        clientResults.forEach(row => {
            newClientsAct += Number(row.newclient_actuals1) || 0;
            attritionAct += Number(row.attrition_actuals1) || 0;
            newClientsAop += Number(row.newclients_aop1) || 0;
            attritionAop += Number(row.attrition_aop1) || 0;
        });
log.debug("attempting to run aprilExistingClientsQueryResults query")
let aprilExistingClientsQueryResults=[]
 if((aprilId!=null) && (subsidiaryIds.length>0)){
         aprilExistingClientsQueryResults = query.runSuiteQL({ query: aprilExistingClientsQuery, params: clientParams }).asMappedResults();
        
    }
    else{
        aprilExistingClientsQueryResults=[]
    }
    aprilExistingClientsQueryResults.forEach(row => {
            existingAct += Number(row.existing_actuals1);
            existingAop += Number(row.existing_aop1);
        });
        totalClientsAct = newClientsAct + attritionAct + existingAct;
        totalClientsAop = newClientsAop + attritionAop + existingAop;

        log.debug("parameters monthwise", JSON.stringify(parameters));
        // Before queries
        var startTime = new Date();
        log.debug("Start query execution", "Starting...");
        if(runtime.getCurrentScript().getRemainingUsage()<=1000){
                log.debug("rescheduling at monthly query execution, low units left...",runtime.getCurrentScript().getRemainingUsage())
                
            }
            
            let netArrResultSet;
 if((aprilId!=null) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0)){
         netArrResultSet = query.runSuiteQL({ query: arrNetQuery, params: clientParams });
        log.debug("Query 3 executed in", (new Date() - startTime) / 1000 + " seconds");
 }
 else{
    netArrResultSet=[]
 }
        startTime = new Date();

        log.debug("subsidiary ids before running nrr query",subsidiaryIds)
        log.debug("place holders before nrr query",subsidiaryChildPlaceHolders)

        let netArrResults = netArrResultSet.asMappedResults();
        log.debug("Results mapped in", (new Date() - startTime) / 1000 + " seconds");
        log.debug("results", JSON.stringify(netArrResults));

        let netNewAop = 0, netNewActuals = 0, netNewVariance = 0, netNewVariancePer = 0;
        let netNewActualsSum = 0, netNewAopSum = 0, netNewVarianceSum = 0, netNewVariancePerSum = 0;

        let netNewBookings = netArrResultSet.asMappedResults();
        netNewBookings.forEach(row => {
            netNewAop = row.arr_netnew_aop1;
            netNewActuals = row.arr_netnew_actuals1;
            netNewVariance = netNewActuals - netNewAop;
            netNewVariancePer = (netNewVariance / netNewAop) * 100;
            netNewActualsSum += netNewActuals;
            netNewAopSum += netNewAop;
            log.debug("accumulating net new aop", netNewAopSum);
            netNewVarianceSum += netNewVariance;
            netNewVariancePerSum += netNewVariancePer;
        });

        let totalNetNewActuals = netNewActualsSum;
        let totalNetNewAop = netNewAopSum;
        let totalNetNewVariance = totalNetNewActuals - totalNetNewAop;
        let totalNetNewVariancePer = totalNetNewAop !== 0 ? ((totalNetNewVariance / totalNetNewAop) * 100).toFixed(1) : 0;

        let salesAndMarketingActuals = 0, productActuals = 0, generaladminActuals = 0, customersuccessActuals = 0, randdActuals = 0, profservicesActuals = 0, headcounttotalActuals = 0;
        let salesAndMarketingAop, perspectiveActuals = 0, productAop = 0, generalAdminAop = 0, customersuccessAop = 0, randdAop = 0, profservicesAop = 0, headcounttotalAop = 0;

        let headCountQuery = `SELECT 
  period,  
  SUM(z.SM_HC_aop) AS SM_HC_aop1, 
  SUM(z.Product_HC_aop) AS Product_HC_aop1, 
  SUM(z.GA_HC_AOP) AS GA_HC_AOP1,
  SUM(z.Cs_hc_aop) AS Cs_hc_aop1, 
  SUM(z.rd_hc_aop) AS rd_hc_aop1,
  SUM(z.pso_hc_aop) AS pso_hc_aop1,
  SUM(z.salesandmarketting) AS salesandmarketting, 
  SUM(z.product) AS product1,
  SUM(z.generaladmin) AS generaladmin1,
  SUM(z.customersuccess) AS customersuccess1,
  SUM(z.randd) AS randd1,
  SUM(z.profservices) AS profservices1
FROM (
  SELECT  
    bm.period,
    b.subsidiary,
    SUM(bm.amount) AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2301
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    SUM(bm.amount) AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2302
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    SUM(bm.amount) AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2303
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    SUM(bm.amount) AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2304
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    SUM(bm.amount) AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2305
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    SUM(bm.amount) AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2306
  GROUP BY bm.period, b.subsidiary
  UNION ALL
  SELECT  
    custrecord1 AS period,
    custrecord_tyfone_subsidiary_dashboard2 AS subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    custrecord_ty_headcount_sal_mar AS salesandmarketting, 
    custrecord_ty_headcount_product_report AS product, 
    custrecord_ty_headcount_generaladmin AS generaladmin, 
    custrecord_ty_headcount_cust_success_ AS customersuccess, 
    custrecord_ty_headcount_rd_report AS randd, 
    custrecord_ty_headcount_profser_report AS profservices
  FROM CUSTOMRECORD_TYFONE_HEADCOUNT_REPORT
) z
WHERE 
  z.period = ?
  AND z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period;
`;

log.debug("subsidiaryIds before head count query",subsidiaryIds)
        log.debug("place holders before headcount query",subsidiaryChildPlaceHolders)
        log.debug("clientParams before headcount",clientParams)
        var headCountResults;

  if((aprilId!=null) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0)){
         headCountResults = query.runSuiteQL({ query: headCountQuery, params: clientParams }).asMappedResults();
         log.debug("headcount results", headCountResults)
 }

 else{
    headCountResults=[]
 }

      headCountResults.forEach((row, index) => {
    try {
        // Actuals
        salesAndMarketingActuals = Number(row.salesandmarketting) || 0;
        productActuals = Number(row.product1) || 0;
        generaladminActuals = Number(row.generaladmin1) || 0;
        customersuccessActuals = Number(row.customersuccess1) || 0;
        randdActuals = Number(row.randd1) || 0;
        profservicesActuals = Number(row.profservices1) || 0;
        headcounttotalActuals = salesAndMarketingActuals + productActuals + generaladminActuals + customersuccessActuals + randdActuals + profservicesActuals;

        // AOP
        salesAndMarketingAop = Number(row.sm_hc_aop1) || 0;
        productAop = Number(row.product_hc_aop1) || 0;
        generalAdminAop = Number(row.ga_hc_aop1) || 0;
        customersuccessAop = Number(row.cs_hc_aop1) || 0;
        randdAop = Number(row.rd_hc_aop1) || 0;
        profservicesAop = Number(row.pso_hc_aop1) || 0; // Fixed: Use pso_hc_aop1
        headcounttotalAop = salesAndMarketingAop + productAop + generalAdminAop + customersuccessAop + randdAop + profservicesAop;

        log.debug('Headcount Row Processed', {
            rowIndex: index,
            salesAndMarketingActuals,
            productActuals,
            generaladminActuals,
            customersuccessActuals,
            randdActuals,
            profservicesActuals,
            headcounttotalActuals,
            salesAndMarketingAop,
            productAop,
            generalAdminAop,
            customersuccessAop,
            randdAop,
            profservicesAop,
            headcounttotalAop
        });
    } catch (rowError) {
        log.error('Error processing headCountResults row', {
            rowIndex: index,
            message: rowError.message,
            stack: rowError.stack,
            row: JSON.stringify(row)
        });
        // Continue processing other rows
    }
});

        let groupedResults = {};
        let totalActuals = 0, totalAOP = 0, totalDifference = 0;
        let totalOperatingRevenueActuals = 0, totalOperatingRevenueAOP = 0, totalOperatingRevenueDiff = 0;
        let totalOperatingRevenuePreActuals = 0, totalOperatingRevenuePreVariance = 0;
        let totalRevenuePreActuals = 0, totalRevenuePreActualsVariance = 0;
        let totalOperatingRevenuePreAOP = 0, totalCostOfRevenuePreActuals = 0, totalCostOfRevenuePreAOP = 0;
        let totalOperatingRevenuePer = '';
        let totalRevenueActuals = 0, totalRevenueAOP = 0, totalRevenueDiff = 0, totalRevenuePer = 0;
        let totalCostOfRevenueActuals = 0, totalCostOfRevenueAOP = 0, totalCostOfRevenueDiff = 0;
        let operatingExpensesPreActuals = 0, otherOperatingExpensesPreActuals = 0, otherIncomePreActuals = 0, otherExpensesPreActuals = 0;
        let grossMarginActuals = 0, grossMarginAOP = 0, grossMarginDiff = 0, grossMarginPer = '';
        let grossMarginPerActuals = '', grossMarginPerAOP = '', grossMarginPerDiff = '';
        let grossMarginPreActualVariance = 0, grossMarginPreActuals = 0, grossMarginPreActPer = 0, grossMarginPreAOP = 0;
        let grossProfitNumeratorActuals = 0, grossProfitDenominatorActuals = 0, grossProfitNumeratorAOP = 0, grossProfitDenominatorAOP = 0;
        let grossProfitPercentActuals = 0, grossProfitPercentAOP = 0;
        let otherIncomeTotalActuals = 0, otherIncomeTotalAOP = 0;
        let thirdPartyCostActualsTotal = 0, thirdPartyCostAOPTotal = 0;
        let thirdPartyNfiniaActuals = 0, thirdPartyNfiniaAOP = 0, thirdPartyCubusActuals = 0, thirdPartyCubusAOP = 0;
        let dataCentreSupportActuals = 0, dataCentreSupportAOP = 0;
        let operatingExpensesActualTotal = 0, operatingExpensesAOPTotal = 0, operatingExpensesDiff = 0, operatingExpensesPer = '';
        let otherOperatingExpensesActualTotal = 0, otherOperatingExpensesAOPTotal = 0, otherOperatingExpensesDiff = 0, otherOperatingExpensesPer = '';
        let netProfitActuals, netProfitAOP, netProfitDiff, netProfitPer;
        let otherExpensesTotalActuals, otherExpensesTotalAOP, otherExpensesTotalDiff, otherExpensesTotalPer;
        let totalOperatingActualExpenses = 0, totalOperatingAOPExpenses = 0, totalOperatingDiff = 0, totalOperatingPer = 0;
        let grossProfitsPercentActualsNumerator = 0, grossProfitsPercentActualsDenominator = 0;
        let grossProfitsPercentAOPNumerator = 0, grossProfitsPercentAOPDenominator = 0;
        let grossProfitPercentActualsIncl = 0, grossProfitPercentAOPIncl = 0, grossProfitPercentDiffIncl = 0;
        let preGrossMarginPer = 0, preGrossMarginPerVariance = 0, preTotalOperatingExpenses = 0;
        let preOperatingExpensesVariance = 0, preOperatingExpensesPer = '';

        log.debug("results from map",results)
        results.forEach(row => {
            if (!groupedResults[row.classification]) groupedResults[row.classification] = [];
            groupedResults[row.classification].push(row);
            if (row.classification === 'Recurring Revenue' || row.classification === 'Non Recurring Revenue') {
                totalOperatingRevenueActuals += Number(row.actuals) || 0;
                totalOperatingRevenueAOP += Number(row.aop) || 0;
                totalOperatingRevenueDiff += Number(row.variance) || 0;
                totalOperatingRevenuePreActuals += Number(row.pre_actuals) || 0;
                totalOperatingRevenuePreVariance += Number(row.pre_variance2) || 0;
            }
            if (row.classification === 'Cost of Revenue') {
                totalCostOfRevenueActuals += Number(row.actuals) || 0;
                totalCostOfRevenueAOP += Number(row.aop) || 0;
                totalCostOfRevenueDiff += Number(row.variance) || 0;
                totalCostOfRevenuePreActuals += Number(row.pre_actuals) || 0;
            }
            totalActuals += Number(row.actuals) || 0;
            totalAOP += Number(row.aop) || 0;
            totalDifference += Number(row.variance) || 0;
        });

        totalOperatingRevenuePer = totalOperatingRevenueAOP !== 0
            ? (totalOperatingRevenueDiff && totalOperatingRevenueAOP
                ? ((totalOperatingRevenueDiff / totalOperatingRevenueAOP) * 100).toFixed(1)
                : 0)
            : 0;

        let childData = {};
        let subcategoryTotals = {};
        results1.forEach(childRow => {
            const classification = childRow.classification;
            const parentName = childRow.name;
            const subcategory = childRow.subcategory || parentName; // Default if null
            if (!childData[classification]) {
                childData[classification] = {};
                subcategoryTotals[classification] = {};
            }
            if (!childData[classification][parentName]) {
                childData[classification][parentName] = {};
                subcategoryTotals[classification][parentName] = {};
            }
            if (!childData[classification][parentName][subcategory]) {
                childData[classification][parentName][subcategory] = [];
                subcategoryTotals[classification][parentName][subcategory] = {
                    actuals: 0,
                    aop: 0,
                    variance: 0,
                    pre_actuals: 0,
                    pre_variance2: 0
                };
            }
            childData[classification][parentName][subcategory].push(childRow);
            subcategoryTotals[classification][parentName][subcategory].actuals += Number(childRow.actuals) || 0;
            subcategoryTotals[classification][parentName][subcategory].aop += Number(childRow.aop) || 0;
            subcategoryTotals[classification][parentName][subcategory].variance += Number(childRow.variance) || 0;
            subcategoryTotals[classification][parentName][subcategory].pre_actuals += Number(childRow.pre_actuals) || 0;
            subcategoryTotals[classification][parentName][subcategory].pre_variance2 += Number(childRow.pre_variance2) || 0;

            if (parentName === 'Third Party Cost') {
                thirdPartyCostActualsTotal += Number(childRow.actuals) || 0;
                thirdPartyCostAOPTotal += Number(childRow.aop) || 0;
            }
            const displayName = childRow.accountsearchdisplaynamecopy.toLowerCase();
            if (displayName.includes('nfinia') && classification === 'Recurring Revenue') {
                thirdPartyNfiniaActuals += Number(childRow.actuals) || 0;
                thirdPartyNfiniaAOP += Number(childRow.aop) || 0;
            } else if (displayName.includes('cubus') && classification === 'Recurring Revenue') {
                thirdPartyCubusActuals += Number(childRow.actuals) || 0;
                thirdPartyCubusAOP += Number(childRow.aop) || 0;
            } else if (displayName.includes('data centre & support') && (classification === 'Total Revenue' || classification === 'TOTAL REVENUE')) {
                dataCentreSupportActuals += Number(childRow.actuals) || 0;
                dataCentreSupportAOP += Number(childRow.aop) || 0;
            }
        });

        var arrActTotal = 0, arrAopTotal = 0, arrDiff = 0, arrPer = 0, arrPart = '';
        var preArrActTotal = 0, preArrDiff = 0;

        var monthlyHtml = ''


        var subsidiaryRec = record.load({
            type: 'customrecord_tyf_subs_hier_',
            id: subsidiary
        });
        var subsidiaryName = ''
        subsidiaryName = subsidiaryRec.getValue({ fieldId: 'name' });
        log.debug("table html before concat", tableHtml)

        log.debug("monthly html after concatenating with table html", monthlyHtml)


        monthlyHtml += `
<table width="100%" style="page-break-before: auto;"><thead>
    <tr><th colspan="8" style="text-align: center; font-size: 17pt; color: white; background-color: #454444;">${subsidiaryName}  - ${monthName}  ' ${fyName}</th></tr>

    

    <tr>
        <td width="30%">Particulars</th>
        <td width="10%">Actuals</th>
        <td width="10%">AOP</th>
        <td width="10%">Variance</th>
        <td width="10%">Variance (%)</th>
        <td width="10%">Previous Year<br/>Actuals </th>
        <td width="10%">Previous Year<br/>Variance </th>
        <td width="10%">Previous Year<br/>Variance (%) </th>
    </tr></thead>`;

        let parentIndex = 0;
        for (let classification in groupedResults) {
            classificationTotal = { actuals: 0, aop: 0, difference: 0, pre_actuals: 0, pre_variance: 0 };
            groupedResults[classification].forEach(parentRow => {
                const pre_actuals = Number(parentRow.pre_actuals) || 0;
                const pre_variance = Number(parentRow.pre_variance2);
                classificationTotal.actuals += Number(parentRow.actuals) || 0;
                classificationTotal.aop += Number(parentRow.aop) || 0;
                classificationTotal.difference += Number(parentRow.variance) || 0;
                classificationTotal.pre_actuals += pre_actuals;
                classificationTotal.pre_variance += pre_variance;
            });

            if (classification === 'Recurring Revenue') {
                arrActTotal = classificationTotal.actuals * 12;
                arrAopTotal = classificationTotal.aop * 12;
                arrDiff = arrActTotal - arrAopTotal;
                arrPer = arrAopTotal !== 0 ? (arrDiff && arrAopTotal ? `${((arrDiff / arrAopTotal) * 100).toFixed(1)}%` : 0) : 0;
                preArrActTotal = classificationTotal.pre_actuals * 12;
                arrPart = `
            <tr class="arrtable">
                <td>ARR Recognized (Last month MRR x 12)</td>
                <td>${Math.round(arrActTotal).toLocaleString()}</td>
                <td>${Math.round(arrAopTotal).toLocaleString()}</td>
                <td>${Math.round(arrDiff).toLocaleString()}</td>
                <td>${arrPer}</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>`;
            }

            monthlyHtml += `<tr><td class="classification-section" colspan="8">${classification}</td></tr>`;

            groupedResults[classification].forEach(parentRow => {
                parentIndex++;
                const parentId = `parent_month_${parentIndex}`;
                const parentGroup = `${parentId}_subcats`;
                const actuals = Number(parentRow.actuals) || 0;
                var actuals_class = Number(actuals) < 0 ? 'negative' : 'positive';
                const aop = Number(parentRow.aop) || 0;
                var aop_class = Number(aop) < 0 ? 'negative' : 'positive';
                const difference = Number(parentRow.variance) || 0;
                const pre_actuals = Number(parentRow.pre_actuals);
                var pre_actuals_class = Number(pre_actuals) < 0 ? 'negative' : 'positive';
                const pre_variance = Number(parentRow.pre_variance2);
                var pre_variance_class = Number(pre_variance) < 0 ? 'negative' : 'positive';
                const parentName = parentRow.name;
                const variancePercent = (aop !== 0) && (difference && aop) ? (difference / aop * 100).toFixed(1) : 0;
                const pre_variance_per = (pre_actuals !== 0) && (pre_variance && pre_actuals) ? (pre_variance / pre_actuals * 100).toFixed(1) : 0;
                const varianceClass = Number(difference) < 0 ? 'negative' : 'positive';
                const hasSubcategories = childData[classification]?.[parentName] && Object.keys(childData[classification][parentName]).length > 0;
                monthlyHtml += `
            <tr class="parent-row" id="${parentId}">
                <td width="30%">${hasSubcategories ? `<button class="toggle-button" onclick="toggleRows('${parentGroup}', this)">+</button>` : ''}${parentName}</td>
                <td width="10%" class="${actuals_class}">${Math.round(actuals).toLocaleString()}</td>
                <td width="10%" class="${aop_class}">${Math.round(aop).toLocaleString()}</td>
                <td width="10%" class="${Number(difference) < 0 ? 'negative' : 'positive'}">${Math.round(difference).toLocaleString()}</td>
                <td width="10%" class="${Number(variancePercent) < 0 ? 'negative' : 'positive'}">${variancePercent}%</td>
                <td width="10%" class="${pre_actuals_class}">${Math.round(pre_actuals).toLocaleString()}</td>
                <td width="10%" class="${pre_variance_class}">${Math.round(pre_variance).toLocaleString()}</td>
                <td width="10%" class="${Number(pre_variance_per) < 0 ? 'negative' : 'positive'}">${pre_variance_per}%</td>
            </tr>`;

                if (hasSubcategories) {
                    let subcatIndex = 0;
                    for (let subcategory in childData[classification][parentName]) {
                        subcatIndex++;
                        const subcatId = `subcat_${parentIndex}_${subcatIndex}`;
                        const subcatGroup = `month_subcat_${subcatId}_children`;
                        const subcatTotal = subcategoryTotals[classification][parentName][subcategory];
                        const subcatActuals = subcatTotal.actuals;
                        const subcatAop = subcatTotal.aop;
                        const subcatDifference = subcatTotal.variance;
                        const subcatPreActuals = subcatTotal.pre_actuals;
                        const subcatPreVariance = subcatTotal.pre_variance2;
                        const subcatVariancePercent = (subcatAop !== 0) && (subcatDifference && subcatAop) ? (subcatDifference / subcatAop * 100).toFixed(1) : 0;
                        const subcatPreVariancePer = (subcatPreActuals !== 0) && (subcatPreVariance && subcatPreActuals) ? (subcatPreVariance / subcatPreActuals * 100).toFixed(1) : 0;

                        monthlyHtml += `
                <tr class="subcategory-row" data-group="${parentGroup}" style="display:none;">
                    <td width="30%"><button class="subcategory-toggle plus-state" onclick="toggleRows('${subcatGroup}', this)">+</button>${subcategory}</td>
                    <td width="10%" class="${Number(subcatActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatAop) < 0 ? 'negative' : 'positive'}">${Math.round(subcatAop).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatDifference) < 0 ? 'negative' : 'positive'}">${Math.round(subcatDifference).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatVariancePercent) < 0 ? 'negative' : 'positive'}">${subcatVariancePercent}%</td>
                    <td width="10%" class="${Number(subcatPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreVariance).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariancePer) < 0 ? 'negative' : 'positive'}">${subcatPreVariancePer}%</td>
                </tr>`;

                        childData[classification][parentName][subcategory].forEach(childRow => {
                            const childActuals = Number(childRow.actuals) || 0;
                            const childAop = Number(childRow.aop) || 0;
                            const childDifference = Number(childRow.variance) || 0;
                            const childVariancePercent = (childAop !== 0) && (childDifference && childAop) ? (childDifference / childAop * 100).toFixed(1) : 0;
                            const childVarianceClass = Number(childDifference) < 0 ? 'negative' : 'positive';
                            const chld_pre_actuals = Number(childRow.pre_actuals);
                            const chld_pre_variance = Number(childRow.pre_variance2);
                            const child_pre_variance_per = (chld_pre_actuals !== 0) && (chld_pre_variance && chld_pre_actuals) ? (chld_pre_variance / chld_pre_actuals * 100).toFixed(1) : 0;

                            monthlyHtml += `
                    <tr class="child-row" data-group="${subcatGroup}" style="display:none;">
                        <td width="30%">${childRow.acctnumber}&nbsp;${childRow.accountsearchdisplaynamecopy}</td>
                        <td width="10%" class="${Number(childActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(childAop) < 0 ? 'negative' : 'positive'}">${Math.round(childAop).toLocaleString()}</td>
                        <td width="10%" class="${Number(childDifference) < 0 ? 'negative' : 'positive'}">${Math.round(childDifference).toLocaleString()}</td>
                        <td width="10%" class="${Number(childVariancePercent) < 0 ? 'negative' : 'positive'}">${childVariancePercent}%</td>
                        <td width="10%" class="${Number(chld_pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(chld_pre_actuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(chld_pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(chld_pre_variance).toLocaleString()}</td>
                        <td width="10%" class="${Number(child_pre_variance_per) < 0 ? 'negative' : 'positive'}">${child_pre_variance_per}%</td>
                    </tr>`;
                        });
                    }
                }
            });

            const totalVariancePercent = (classificationTotal.aop !== 0) && (classificationTotal.difference && classificationTotal.aop)
                ? (classificationTotal.difference / classificationTotal.aop * 100).toFixed(1)
                : 0;
            const totalVarianceClass = classificationTotal.difference < 0 ? 'negative' : 'positive';
            var total_pre_variance_per = (classificationTotal.pre_actuals !== 0) && (classificationTotal.pre_variance && classificationTotal.pre_actuals)
                ? (classificationTotal.pre_variance / classificationTotal.pre_actuals * 100).toFixed(1)
                : 0;
            if (classificationTotal.pre_variance < 0 && classificationTotal.pre_actuals < 0) {
                total_pre_variance_per = total_pre_variance_per * (-1);
            }
            const pre_variance_class = classificationTotal.pre_variance < 0 ? 'negative' : 'positive';

            if (classification === 'Non Recurring Revenue') {
                const preOpRevVariance = totalOperatingRevenueActuals - totalOperatingRevenuePreActuals;
                const preOpRevVariancePer = (totalOperatingRevenueActuals !== 0) && (preOpRevVariance && totalOperatingRevenueActuals)
                    ? ((preOpRevVariance / totalOperatingRevenueActuals) * 100).toFixed(1)
                    : 0;
                monthlyHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                <td class="${Number(total_pre_variance_per) < 0 ? 'negative' : 'positive'}">${total_pre_variance_per}%</td>
            </tr>
            <tr class="summary-rows">
                <td>TOTAL OPERATING REVENUE</td>
                <td class="${Number(totalOperatingRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingRevenueActuals).toLocaleString()}</td>
                <td class="${Number(totalOperatingRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingRevenueAOP).toLocaleString()}</td>
                <td class="${Number(totalOperatingRevenueDiff) < 0 ? 'negative' : 'positive'}">${totalOperatingRevenueDiff.toLocaleString()}</td>
                <td class="${Number(totalOperatingRevenueDiff) < 0 ? 'negative' : 'positive'}">${totalOperatingRevenuePer}%</td>
                <td class="${Number(totalOperatingRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingRevenuePreActuals).toLocaleString()}</td>
                <td class="${Number(preOpRevVariance) < 0 ? 'negative' : 'positive'}">${Math.round(preOpRevVariance).toLocaleString()}</td>
                <td class="${Number(preOpRevVariancePer) < 0 ? 'negative' : 'positive'}">${preOpRevVariancePer}%</td>
            </tr>`;
            } else if (classification === 'OPERATING EXPENSES') {
                monthlyHtml += `
            <tr class="total-row">
                <td>HEADCOUNT COST</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                <td class="${pre_variance_class}">${total_pre_variance_per}%</td>
            </tr>`;
                operatingExpensesActualTotal = classificationTotal.actuals;
                operatingExpensesAOPTotal = classificationTotal.aop;
                operatingExpensesDiff = operatingExpensesAOPTotal - operatingExpensesActualTotal;
                operatingExpensesPer = (operatingExpensesAOPTotal !== 0) && (operatingExpensesDiff && operatingExpensesAOPTotal)
                    ? `${((operatingExpensesDiff / operatingExpensesAOPTotal) * 100).toFixed(1)}%`
                    : 0;
                operatingExpensesPreActuals = Number(classificationTotal.pre_actuals) || 0;
                log.debug("classification total ", operatingExpensesActualTotal);
            } else if (classification === 'OTHER INCOME') {
                totalRevenueActuals = totalOperatingRevenueActuals + Math.round(classificationTotal.actuals);
                totalRevenueAOP = totalOperatingRevenueAOP + Math.round(classificationTotal.aop);
                totalRevenueDiff = totalRevenueActuals - totalRevenueAOP;
                totalRevenuePer = (totalRevenueAOP !== 0) && (totalRevenueDiff && totalRevenueAOP)
                    ? `${((totalRevenueDiff / totalRevenueAOP) * 100).toFixed(1)}`
                    : 0;
                if (totalRevenueDiff < 0 && totalRevenueAOP < 0) {
                    totalRevenuePer = totalRevenuePer * (-1);
                }
                totalRevenuePreActuals = totalOperatingRevenuePreActuals + Math.round(classificationTotal.pre_actuals);
                totalRevenuePreActualsVariance = totalOperatingRevenuePreVariance + Math.round(classificationTotal.pre_variance);
                totalRevenuePreActualsVariancePer = (totalRevenuePreActuals !== 0) && (totalRevenuePreActualsVariance && totalRevenuePreActuals)
                    ? `${((totalRevenuePreActualsVariance / totalRevenuePreActuals) * 100).toFixed(1)}`
                    : 0;
                if (totalRevenuePreActualsVariance < 0 && totalRevenuePreActuals < 0) {
                    totalRevenuePreActualsVariancePer = totalRevenuePreActualsVariancePer * (-1);
                }
                otherIncomeTotalActuals = classificationTotal.actuals;
                otherIncomeTotalAOP = classificationTotal.aop;
                otherIncomePreActuals = Number(classificationTotal.pre_actuals) || 0;
                monthlyHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification} </td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                <td class="${Number(total_pre_variance_per) < 0 ? 'negative' : 'positive'}">${total_pre_variance_per}%</td>
            </tr>
            <tr class="summary-rows">
                <td>Total Revenue</td>
                <td class="${Number(totalRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(totalRevenueActuals).toLocaleString()}</td>
                <td class="${Number(totalRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(totalRevenueAOP).toLocaleString()}</td>
                <td class="${Number(totalRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(totalRevenueDiff).toLocaleString()}</td>
                <td class="${Number(totalRevenuePer) < 0 ? 'negative' : 'positive'}">${totalRevenuePer}%</td>
                <td class="${Number(totalRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(totalRevenuePreActuals).toLocaleString()}</td>
                <td class="${Number(totalRevenuePreActualsVariance) < 0 ? 'negative' : 'positive'}">${Math.round(totalRevenuePreActualsVariance).toLocaleString()}</td>
                <td class="${Number(totalRevenuePreActualsVariancePer) < 0 ? 'negative' : 'positive'}">${totalRevenuePreActualsVariancePer}%</td>
            </tr>`;
            } else if (classification === 'Cost of Revenue') {
                grossMarginActuals = totalOperatingRevenueActuals - totalCostOfRevenueActuals;
                grossMarginAOP = totalOperatingRevenueAOP - totalCostOfRevenueAOP;
                grossMarginDiff = (grossMarginAOP) - (grossMarginActuals);
                grossMarginPer = (grossMarginAOP !== 0) && (grossMarginDiff && grossMarginAOP)
                    ? `${((grossMarginDiff / grossMarginAOP) * 100).toFixed(1)}`
                    : 0;
                if (grossMarginDiff < 0 && grossMarginAOP < 0) {
                    grossMarginPer = grossMarginPer * (-1);
                }
                grossMarginPerActuals = (totalOperatingRevenueActuals !== 0) && (grossMarginActuals && totalOperatingRevenueActuals)
                    ? Number((grossMarginActuals / totalOperatingRevenueActuals * 100).toFixed(1))
                    : 0;
                grossMarginPerAOP = totalOperatingRevenueAOP !== 0 ? Number((grossMarginAOP / totalOperatingRevenueAOP * 100)) : 0;
                grossMarginPerDiff = (grossMarginPerActuals) - (grossMarginPerAOP);
                grossMarginPreActuals = (totalOperatingRevenuePreActuals) - (totalCostOfRevenuePreActuals);
                grossMarginPreActualVariance = (grossMarginPreActuals) - (grossMarginActuals);
                grossMarginPreActPer = (grossMarginPreActuals !== 0) && (grossMarginPreActualVariance && grossMarginPreActuals)
                    ? Number((grossMarginPreActualVariance / grossMarginPreActuals * 100).toFixed(1))
                    : 0;
                preGrossMarginPer = (totalRevenuePreActuals !== 0) && (grossMarginActuals && totalRevenuePreActuals)
                    ? Number(((grossMarginActuals / totalRevenuePreActuals) * 100).toFixed(1))
                    : 0;
                if (grossMarginActuals < 0 && totalRevenuePreActuals < 0) {
                    preGrossMarginPer = preGrossMarginPer * (-1);
                }
                preGrossMarginPerVariance = (grossMarginPerActuals) - (preGrossMarginPer);
                if (grossMarginPreActualVariance < 0 && grossMarginPreActuals < 0) {
                    grossMarginPreActPer = grossMarginPreActPer * (-1);
                }
                var grossProfitPercentageExclActualsNumerator = (totalRevenueActuals - otherIncomeTotalActuals - thirdPartyNfiniaActuals - thirdPartyCubusActuals) - dataCentreSupportActuals;
                var grossProfitPercentageExclActualsDenominator = (totalRevenueActuals - otherIncomeTotalActuals - thirdPartyNfiniaActuals - thirdPartyCubusActuals);
                var grossProfitExclActualsPer = (grossProfitPercentageExclActualsNumerator && grossProfitPercentageExclActualsDenominator) ? ((grossProfitPercentageExclActualsNumerator / grossProfitPercentageExclActualsDenominator).toFixed(1)) + '%' : '';
                var grossProfitPercentageExclAOPNumerator = (totalRevenueAOP - otherIncomeTotalAOP - thirdPartyNfiniaAOP - thirdPartyCubusAOP) - dataCentreSupportAOP;
                var grossProfitPercentageExclAOPDenominator = (totalRevenueAOP - otherIncomeTotalAOP - thirdPartyNfiniaAOP - thirdPartyCubusAOP);
                var grossProfitExclAOPPer = grossProfitPercentageExclAOPNumerator / grossProfitPercentageExclAOPDenominator;
                var grossProfitPerExclDiff = grossProfitExclActualsPer - grossProfitExclAOPPer;
                monthlyHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification} </td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${(classificationTotal.pre_actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${(classificationTotal.pre_variance).toLocaleString()}</td>
                <td class="${Number(total_pre_variance_per) < 0 ? 'negative' : 'positive'}">${total_pre_variance_per}%</td>
            </tr>
            <tr class="summary-rows">
                <td>Gross Margin (excl. other income)</td>
                <td class="${Number(grossMarginActuals) < 0 ? 'negative' : 'positive'}">${Math.round(grossMarginActuals).toLocaleString()}</td>
                <td class="${Number(grossMarginAOP) < 0 ? 'negative' : 'positive'}">${Math.round(grossMarginAOP).toLocaleString()}</td>
                <td class="${Number(grossMarginDiff) < 0 ? 'negative' : 'positive'}">${Math.round(grossMarginDiff).toLocaleString()}</td>
                <td class="${Number(grossMarginPer) < 0 ? 'negative' : 'positive'}">${grossMarginPer}%</td>
                <td class="${Number(grossMarginPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(grossMarginPreActuals).toLocaleString()}</td>
                <td class="${Number(grossMarginPreActualVariance) < 0 ? 'negative' : 'positive'}">${Math.round(grossMarginPreActualVariance).toLocaleString()}</td>
                <td class="${Number(grossMarginPreActPer) < 0 ? 'negative' : 'positive'}">${grossMarginPreActPer}%</td>
            </tr>
            <tr class="summary-rows">
                <td>Gross Margin (%)</td>
                <td class="${Number(grossMarginPerActuals) < 0 ? 'negative' : 'positive'}">${(grossMarginPerActuals)}%</td>
                <td class="${Number(grossMarginPerAOP) < 0 ? 'negative' : 'positive'}">${grossMarginAOP ? (grossMarginPerAOP).toFixed(1) : 0}%</td>
                <td></td>
                <td class="${Number(grossMarginPerDiff) < 0 ? 'negative' : 'positive'}">${grossMarginPerDiff ? ((grossMarginPerDiff).toFixed(1)) : '0'}%</td>
                <td class="${Number(preGrossMarginPer) < 0 ? 'negative' : 'positive'}">${preGrossMarginPer ? ((preGrossMarginPer).toFixed(1)) : '0'}%</td>
                <td></td>
                <td class="${Number(preGrossMarginPerVariance) < 0 ? 'negative' : 'positive'}">${preGrossMarginPerVariance ? ((preGrossMarginPerVariance).toFixed(1)) : 0}%</td>
            </tr>`;
            } else if ((classification === "Other Operating Expenses ") || (classification === "Other Operating Expenses")) {
                otherOperatingExpensesActualTotal = classificationTotal.actuals;
                otherOperatingExpensesAOPTotal = classificationTotal.aop;
                otherOperatingExpensesDiff = otherOperatingExpensesAOPTotal - otherOperatingExpensesActualTotal;
                otherOperatingExpensesPer = (otherOperatingExpensesAOPTotal !== 0) && (operatingExpensesDiff && otherOperatingExpensesAOPTotal)
                    ? `${((operatingExpensesDiff / otherOperatingExpensesAOPTotal) * 100).toFixed(1)}`
                    : 0;
                if (operatingExpensesDiff < 0 && otherOperatingExpensesAOPTotal < 0) {
                    otherOperatingExpensesPer = otherOperatingExpensesPer * (-1);
                }
                otherOperatingExpensesPreActuals = Number(classificationTotal.pre_actuals) || 0;
                totalOperatingActualExpenses = operatingExpensesActualTotal + otherOperatingExpensesActualTotal;
                totalOperatingAOPExpenses = operatingExpensesAOPTotal + otherOperatingExpensesAOPTotal;
                totalOperatingDiff = totalOperatingAOPExpenses - totalOperatingActualExpenses;
                totalOperatingPer = (totalOperatingAOPExpenses !== 0) && (totalOperatingDiff && totalOperatingAOPExpenses)
                    ? `${((totalOperatingDiff / totalOperatingAOPExpenses) * 100).toFixed(1)}`
                    : 0;
                if (totalOperatingDiff < 0 && totalOperatingAOPExpenses < 0) {
                    totalOperatingPer = totalOperatingPer * (-1);
                }
                preTotalOperatingExpenses = operatingExpensesPreActuals + otherOperatingExpensesPreActuals;
                preOperatingExpensesVariance = preTotalOperatingExpenses - totalOperatingActualExpenses;
                preOperatingExpensesPer = (preTotalOperatingExpenses !== 0) && (preOperatingExpensesVariance && preTotalOperatingExpenses)
                    ? ((preOperatingExpensesVariance / preTotalOperatingExpenses) * 100).toFixed(1)
                    : 0;
                if (preOperatingExpensesVariance < 0 && preTotalOperatingExpenses < 0) {
                    preOperatingExpensesPer = preOperatingExpensesPer * (-1);
                }
                const proFormaEbitaActuals = grossMarginActuals - totalOperatingActualExpenses;
                const proFormaEbitaAOP = grossMarginAOP - totalOperatingAOPExpenses;
                const proFormaEbitaDiff = proFormaEbitaActuals - proFormaEbitaAOP;
                var proformaEbitaPer = (proFormaEbitaAOP !== 0) && (proFormaEbitaDiff && proFormaEbitaAOP)
                    ? `${((proFormaEbitaDiff / proFormaEbitaAOP) * 100).toFixed(1)}`
                    : 0;
                if (proFormaEbitaDiff < 0 && proFormaEbitaAOP < 0) {
                    proformaEbitaPer = parseFloat(proformaEbitaPer) * (-1);
                }
                const proFormaEbitaPerActuals = (totalOperatingRevenueActuals !== 0) && (proFormaEbitaActuals && totalOperatingRevenueActuals)
                    ? ((proFormaEbitaActuals / totalOperatingRevenueActuals) * 100).toFixed(1)
                    : 0;
                const proFormaEbitaPerAOP = (totalOperatingRevenueAOP !== 0) && (proFormaEbitaAOP && totalOperatingRevenueAOP)
                    ? ((proFormaEbitaAOP / totalOperatingRevenueAOP) * 100).toFixed(1)
                    : 0;
                const proFormaEbitaPerDiff = proFormaEbitaPerActuals - proFormaEbitaPerAOP;
                const preProFormaEbitaActuals = grossMarginPreActuals - preTotalOperatingExpenses;
                const preProFormaVariance = proFormaEbitaActuals - preProFormaEbitaActuals;
                const preProFormaEbitaPrePerActuals = totalOperatingRevenuePreActuals !== 0
                    ? ((preProFormaEbitaActuals / totalOperatingRevenuePreActuals) * 100)
                    : 0;
                var preProFormaPer = (preProFormaEbitaActuals !== 0) && (preProFormaVariance && preProFormaEbitaActuals)
                    ? ((preProFormaVariance / preProFormaEbitaActuals) * 100).toFixed(1)
                    : 0;
                if (preProFormaVariance < 0 && preProFormaEbitaActuals < 0) {
                    preProFormaPer = preProFormaPer * (-1);
                }
                const preProFormaEbitaPerActuals = (totalOperatingRevenuePreActuals !== 0) && (preProFormaEbitaActuals && totalOperatingRevenuePreActuals)
                    ? ((preProFormaEbitaActuals / totalOperatingRevenuePreActuals) * 100).toFixed(1)
                    : 0;
                var preProFormaEbitaVariancePer = proFormaEbitaPerActuals - preProFormaEbitaPrePerActuals;
                if (preProFormaVariance < 0 && totalOperatingRevenuePreActuals < 0) {
                    preProFormaEbitaVariancePer = parseFloat(preProFormaEbitaVariancePer) * (-1);
                }
                monthlyHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification} </td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                <td class="${Number(total_pre_variance_per) < 0 ? 'negative' : 'positive'}">${total_pre_variance_per}%</td>
            </tr>
            <tr class="summary-rows">
                <td>Total Operating Expenses</td>
                <td class="${Number(totalOperatingActualExpenses) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingActualExpenses).toLocaleString()}</td>
                <td class="${Number(totalOperatingAOPExpenses) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingAOPExpenses).toLocaleString()}</td>
                <td class="${Number(totalOperatingDiff) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingDiff).toLocaleString()}</td>
                <td class="${Number(totalOperatingPer) < 0 ? 'negative' : 'positive'}">${totalOperatingPer}%</td>
                <td class="${Number(preTotalOperatingExpenses) < 0 ? 'negative' : 'positive'}">${Math.round(preTotalOperatingExpenses).toLocaleString()}</td>
                <td class="${Number(preOperatingExpensesVariance) < 0 ? 'negative' : 'positive'}">${Math.round(preOperatingExpensesVariance).toLocaleString()}</td>
                <td class="${Number(preOperatingExpensesPer) < 0 ? 'negative' : 'positive'}">${preOperatingExpensesPer}%</td>
            </tr>
            <tr class="summary-rows">
                <td>Pro Forma Ebidta</td>
                <td class="${Number(proFormaEbitaActuals) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaActuals).toLocaleString()}</td>
                <td class="${Number(proFormaEbitaAOP) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaAOP).toLocaleString()}</td>
                <td class="${Number(proFormaEbitaDiff) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaDiff).toLocaleString()}</td>
                <td class="${Number(proformaEbitaPer) < 0 ? 'negative' : 'positive'}">${proformaEbitaPer}%</td>
                <td class="${Number(preProFormaEbitaActuals) < 0 ? 'negative' : 'positive'}">${Math.round(preProFormaEbitaActuals).toLocaleString()}</td>
                <td class="${Number(preProFormaVariance) < 0 ? 'negative' : 'positive'}">${Math.round(preProFormaVariance).toLocaleString()}</td>
                <td class="${Number(preProFormaPer) < 0 ? 'negative' : 'positive'}">${preProFormaPer}%</td>
            </tr>
            <tr class="summary-rows">
                <td>Pro Forma Ebidta %</td>
                <td class="${Number(proFormaEbitaPerActuals) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerActuals}%</td>
                <td class="${Number(proFormaEbitaPerAOP) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerAOP}%</td>
                <td></td>
                <td class="${Number(proFormaEbitaPerDiff) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerDiff ? (proFormaEbitaPerDiff.toFixed(1)) : 0}%</td>
                <td class="${Number(preProFormaEbitaPrePerActuals) < 0 ? 'negative' : 'positive'}">${preProFormaEbitaPrePerActuals ? (preProFormaEbitaPrePerActuals.toFixed(1)) : '0'}%</td>
                <td></td>
                <td class="${Number(preProFormaEbitaVariancePer) < 0 ? 'negative' : 'positive'}">${preProFormaEbitaVariancePer ? (preProFormaEbitaVariancePer.toFixed(1)) : 0}%</td>
            </tr>`;
            } else if (classification === "Other expenses") {
                otherExpensesTotalActuals = classificationTotal.actuals;
                otherExpensesTotalAOP = classificationTotal.aop;
                otherExpensesTotalDiff = otherExpensesTotalAOP - otherExpensesTotalActuals;
                otherExpensesTotalPer = (otherExpensesTotalAOP !== 0) && (otherExpensesTotalDiff && otherExpensesTotalAOP)
                    ? `${((otherExpensesTotalDiff / otherExpensesTotalAOP) * 100).toFixed(1)}%`
                    : 0;
                netProfitActuals = grossMarginActuals - totalOperatingActualExpenses - otherExpensesTotalActuals + otherIncomeTotalActuals;
                netProfitAOP = grossMarginAOP - totalOperatingAOPExpenses - otherExpensesTotalAOP + otherIncomeTotalAOP;
                netProfitDiff = netProfitActuals - netProfitAOP;
                netProfitPer = (netProfitAOP !== 0) && (netProfitDiff && netProfitAOP)
                    ? `${((netProfitDiff / netProfitAOP) * 100).toFixed(1)}`
                    : 0;
                if (netProfitDiff < 0 && netProfitAOP < 0) {
                    netProfitPer = netProfitPer * (-1);
                }
                otherExpensesPreActuals = Number(classificationTotal.pre_actuals) || 0;
                const preNetProfit = grossMarginPreActuals - preTotalOperatingExpenses - otherExpensesPreActuals + otherIncomePreActuals;
                const preNetProfitVariance = netProfitActuals - preNetProfit;
                var preNetProfitPer = (preNetProfit !== 0) && (preNetProfitVariance && preNetProfit)
                    ? ((preNetProfitVariance / preNetProfit) * 100).toFixed(1)
                    : 0;
                if (preNetProfitVariance < 0 && preNetProfit < 0) {
                    preNetProfitPer = preNetProfitPer * (-1);
                }

                monthlyHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification} </td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${(classificationTotal.pre_actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${(classificationTotal.pre_variance).toLocaleString()}</td>
                <td class="${Number(total_pre_variance_per) < 0 ? 'negative' : 'positive'}">${total_pre_variance_per}%</td>
            </tr>
            <tr class="summary-rows">
                <td>Net Profit</td>
                <td class="${Number(netProfitActuals) < 0 ? 'negative' : 'positive'}">${Math.round(netProfitActuals).toLocaleString()}</td>
                <td class="${Number(netProfitAOP) < 0 ? 'negative' : 'positive'}">${Math.round(netProfitAOP).toLocaleString()}</td>
                <td class="${Number(netProfitDiff) < 0 ? 'negative' : 'positive'}">${Math.round(netProfitDiff).toLocaleString()}</td>
                <td class="${Number(netProfitPer) < 0 ? 'negative' : 'positive'}">${netProfitPer}%</td>
                <td class="${Number(preNetProfit) < 0 ? 'negative' : 'positive'}">${Math.round(preNetProfit).toLocaleString()}</td>
                <td class="${Number(preNetProfitVariance) < 0 ? 'negative' : 'positive'}">${Math.round(preNetProfitVariance).toLocaleString()}</td>
                <td class="${Number(preNetProfitPer) < 0 ? 'negative' : 'positive'}">${preNetProfitPer}%</td>
            </tr>`;
            } else {
                monthlyHtml += `
              <tr class="total-row">
                <td>TOTAL ${classification} </td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${(classificationTotal.pre_actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${(classificationTotal.pre_variance).toLocaleString()}</td>
                <td class="${Number(total_pre_variance_per) < 0 ? 'negative' : 'positive'}">${total_pre_variance_per}%</td>
            </tr>`;
            }
        }

        // Add ARR, Client Data, and Headcount sections after the classification loop
        var contractedActualsTotal = arrActTotal + totalNetNewActuals;
        var contractedAopTotal = arrAopTotal + totalNetNewAop;
        var contractedVariance = contractedActualsTotal - contractedAopTotal;
        var contractedVariancePer = contractedAopTotal !== 0 ? ((contractedVariance / contractedAopTotal) * 100).toFixed(1) : 0;

        monthlyHtml += `
    <tr class="classification-section"><td colspan="8">Contracted ARR ($)</td></tr>
    ${arrPart}
    <tr class="arrtable">
        <td>ARR Net New Bookings (MRR from SF x 12) </td>
        <td class="${Number(totalNetNewActuals) < 0 ? 'negative' : 'positive'}">${Math.round(totalNetNewActuals).toLocaleString()}</td>
        <td class="${Number(totalNetNewAop) < 0 ? 'negative' : 'positive'}">${Math.round(totalNetNewAop).toLocaleString()}</td>
        <td class="${Number(totalNetNewVariance) < 0 ? 'negative' : 'positive'}">${Math.round(totalNetNewVariance).toLocaleString()}</td>
        <td class="${Number(totalNetNewVariancePer) < 0 ? 'negative' : 'positive'}">${totalNetNewVariancePer}%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr class="total-row">
        <td>Total Contracted ARR</td>
        <td class="${Number(contractedActualsTotal) < 0 ? 'negative' : 'positive'}">${(Math.round(contractedActualsTotal).toLocaleString()) || 0}</td>
        <td class="${Number(contractedAopTotal) < 0 ? 'negative' : 'positive'}">${(Math.round(contractedAopTotal).toLocaleString()) || 0}</td>
        <td class="${Number(contractedVariance) < 0 ? 'negative' : 'positive'}">${(Math.round(contractedVariance).toLocaleString()) || 0}</td>
        <td class="${Number(contractedVariancePer) < 0 ? 'negative' : 'positive'}">${(contractedVariancePer)}%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr class="classification-section"><td colspan="8">Client Data (NO.)</td></tr>
    <tr class="client-data">
        <td>New Clients</td>
        <td class="${Number(newClientsAct) < 0 ? 'negative' : 'positive'}">${newClientsAct || 0}</td>
        <td class="${Number(newClientsAop) < 0 ? 'negative' : 'positive'}">${newClientsAop || 0}</td>
        <td class="${(Number(newClientsAct) - Number(newClientsAop)) < 0 ? 'negative' : 'positive'}">${Number(newClientsAct) - Number(newClientsAop) || 0}</td>
        <td class="${Number((newClientsAop !== 0 && (((newClientsAct - newClientsAop) / newClientsAop * 100 * ((newClientsAct - newClientsAop) < 0 && newClientsAop < 0 ? -1 : 1)).toFixed(1)))) < 0 ? 'negative' : 'positive'}">${(newClientsAop !== 0 && (((newClientsAct - newClientsAop) / newClientsAop * 100 * ((newClientsAct - newClientsAop) < 0 && newClientsAop < 0 ? -1 : 1)).toFixed(1))) || 0
            }%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr class="client-data">
        <td>Attrition</td>
        <td class="${Number(attritionAct) < 0 ? 'negative' : 'positive'}">${attritionAct || 0}</td>
        <td class="${Number(attritionAop) < 0 ? 'negative' : 'positive'}">${attritionAop || 0}</td>
        <td class="${(Number(attritionAct) - Number(attritionAop)) < 0 ? 'negative' : 'positive'}">${Number(attritionAct) - Number(attritionAop) || 0}</td>
        <td class="${Number((attritionAop !== 0 && (((attritionAct - attritionAop) / attritionAop * 100 * ((attritionAct - attritionAop) < 0 && attritionAop < 0 ? -1 : 1)).toFixed(1)))) < 0 ? 'negative' : 'positive'}">${(attritionAop !== 0 && (((attritionAct - attritionAop) / attritionAop * 100 * ((attritionAct - attritionAop) < 0 && attritionAop < 0 ? -1 : 1)).toFixed(1))) || 0
            }%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr class="client-data">
        <td>Existing</td>
        <td class="${Number(existingAct) < 0 ? 'negative' : 'positive'}">${existingAct || 0}</td>
        <td class="${Number(existingAop) < 0 ? 'negative' : 'positive'}">${existingAop || 0}</td>
        <td class="${(Number(existingAct) - Number(existingAop)) < 0 ? 'negative' : 'positive'}">${Number(existingAct) - Number(existingAop) || 0}</td>
        <td class="${Number((existingAop !== 0 && (((existingAct - existingAop) / existingAop * 100 * ((existingAct - existingAop) < 0 && existingAop < 0 ? -1 : 1)).toFixed(1)))) < 0 ? 'negative' : 'positive'}">${(existingAop !== 0 && (((existingAct - existingAop) / existingAop * 100 * ((existingAct - existingAop) < 0 && existingAop < 0 ? -1 : 1)).toFixed(1))) || 0
            }%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr class="total-row">
        <td>Total Clients</td>
        <td class="${Number(totalClientsAct) < 0 ? 'negative' : 'positive'}">${totalClientsAct || 0}</td>
        <td class="${Number(totalClientsAop) < 0 ? 'negative' : 'positive'}">${totalClientsAop || 0}</td>
        <td class="${(Number(totalClientsAct) - Number(totalClientsAop)) < 0 ? 'negative' : 'positive'}">${Number(totalClientsAct) - Number(totalClientsAop) || 0}</td>
        <td class="${Number((totalClientsAop !== 0 && (((totalClientsAct - totalClientsAop) / totalClientsAop * 100 * ((totalClientsAct - totalClientsAop) < 0 && totalClientsAop < 0 ? -1 : 1)).toFixed(1)))) < 0 ? 'negative' : 'positive'}">${(totalClientsAop !== 0 && (((totalClientsAct - totalClientsAop) / totalClientsAop * 100 * ((totalClientsAct - totalClientsAop) < 0 && totalClientsAop < 0 ? -1 : 1)).toFixed(1))) || 0
            }%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr class="classification-section"><td colspan="8">HEADCOUNT (NO.)</td></tr>
     <tr class="parent-row">
        <td>Sales and Marketing</td>
        <td class="${Number(salesAndMarketingActuals) < 0 ? 'negative' : 'positive'}">${(salesAndMarketingActuals) || 0}</td>
        <td class="${Number(salesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${(salesAndMarketingAop) || 0}</td>
        <td class="${(Number(salesAndMarketingActuals) - Number(salesAndMarketingAop)) < 0 ? 'negative' : 'positive'}">${(salesAndMarketingActuals - salesAndMarketingAop) || 0}</td>
        <td class="${Number((salesAndMarketingAop !== 0 && (((salesAndMarketingActuals - salesAndMarketingAop) / salesAndMarketingAop * 100 * ((salesAndMarketingActuals - salesAndMarketingAop) < 0 && salesAndMarketingAop < 0 ? -1 : 1)).toFixed(1)))) < 0 ? 'negative' : 'positive'}">${(salesAndMarketingAop !== 0 && (((salesAndMarketingActuals - salesAndMarketingAop) / salesAndMarketingAop * 100 * ((salesAndMarketingActuals - salesAndMarketingAop) < 0 && salesAndMarketingAop < 0 ? -1 : 1)).toFixed(1))) || 0
            }%</td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
<tr class="parent-row">
    <td>Product</td>
    <td class="${Number(productActuals) < 0 ? 'negative' : 'positive'}">${(productActuals) || 0}</td>
    <td class="${Number(productAop) < 0 ? 'negative' : 'positive'}">${(productAop) || 0}</td>
    <td class="${(Number(productActuals) - Number(productAop)) < 0 ? 'negative' : 'positive'}">${(productActuals - productAop) || 0}</td>
    <td class="${Number(productAop !== 0 && (((productActuals - productAop) / productAop * 100 * ((productActuals - productAop) < 0 && productAop < 0 ? -1 : 1)).toFixed(1))) < 0 ? 'negative' : 'positive'}">${(productAop !== 0 && ((productActuals - productAop) / productAop * 100 * ((productActuals - productAop) < 0 && productAop < 0 ? -1 : 1)).toFixed(1)) || 0
            }%</td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr class="parent-row">
    <td>General & Administrative</td>
    <td class="${Number(generaladminActuals) < 0 ? 'negative' : 'positive'}">${(generaladminActuals) || 0}</td>
    <td class="${Number(generalAdminAop) < 0 ? 'negative' : 'positive'}">${(generalAdminAop) || 0}</td>
    <td class="${(Number(generaladminActuals) - Number(generalAdminAop)) < 0 ? 'negative' : 'positive'}">${(generaladminActuals - generalAdminAop) || 0}</td>
    <td class="${Number(generalAdminAop !== 0 && (((generaladminActuals - generalAdminAop) / generalAdminAop * 100 * ((generaladminActuals - generalAdminAop) < 0 && generalAdminAop < 0 ? -1 : 1)).toFixed(1))) < 0 ? 'negative' : 'positive'}">${(generalAdminAop !== 0 && ((generaladminActuals - generalAdminAop) / generalAdminAop * 100 * ((generaladminActuals - generalAdminAop) < 0 && generalAdminAop < 0 ? -1 : 1)).toFixed(1)) || 0
            }%</td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr class="parent-row">
    <td>Customer Success</td>
    <td class="${Number(customersuccessActuals) < 0 ? 'negative' : 'positive'}">${(customersuccessActuals) || 0}</td>
    <td class="${Number(customersuccessAop) < 0 ? 'negative' : 'positive'}">${(customersuccessAop) || 0}</td>
    <td class="${(Number(customersuccessActuals) - Number(customersuccessAop)) < 0 ? 'negative' : 'positive'}">${(customersuccessActuals - customersuccessAop) || 0}</td>
    <td class="${Number(customersuccessAop !== 0 && (((customersuccessActuals - customersuccessAop) / customersuccessAop * 100 * ((customersuccessActuals - customersuccessAop) < 0 && customersuccessAop < 0 ? -1 : 1)).toFixed(1))) < 0 ? 'negative' : 'positive'}">${(customersuccessAop !== 0 && ((customersuccessActuals - customersuccessAop) / customersuccessAop * 100 * ((customersuccessActuals - customersuccessAop) < 0 && customersuccessAop < 0 ? -1 : 1)).toFixed(1)) || 0
            }%</td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr class="parent-row">
    <td>R & D</td>
    <td class="${Number(randdActuals) < 0 ? 'negative' : 'positive'}">${(randdActuals) || 0}</td>
    <td class="${Number(randdAop) < 0 ? 'negative' : 'positive'}">${(randdAop) || 0}</td>
    <td class="${(Number(randdActuals) - Number(randdAop)) < 0 ? 'negative' : 'positive'}">${(randdActuals - randdAop) || 0}</td>
    <td class="${Number(randdAop !== 0 && (((randdActuals - randdAop) / randdAop * 100 * ((randdActuals - randdAop) < 0 && randdAop < 0 ? -1 : 1)).toFixed(1))) < 0 ? 'negative' : 'positive'}">${(randdAop !== 0 && ((randdActuals - randdAop) / randdAop * 100 * ((randdActuals - randdAop) < 0 && randdAop < 0 ? -1 : 1)).toFixed(1)) || 0
            }%</td>
    <td></td>
    <td></td>
    <td></td>
</tr>
<tr class="total-row">
    <td>HeadCount Total</td>
    <td class="${Number(headcounttotalActuals) < 0 ? 'negative' : 'positive'}">${(headcounttotalActuals) || 0}</td>
    <td class="${Number(headcounttotalAop) < 0 ? 'negative' : 'positive'}">${(headcounttotalAop) || 0}</td>
    <td class="${(Number(headcounttotalActuals) - Number(headcounttotalAop)) < 0 ? 'negative' : 'positive'}">${(headcounttotalActuals - headcounttotalAop) || 0}</td>
    <td class="${Number(headcounttotalAop !== 0 && (((headcounttotalActuals - headcounttotalAop) / headcounttotalAop * 100 * ((headcounttotalActuals - headcounttotalAop) < 0 && headcounttotalAop < 0 ? -1 : 1)).toFixed(1))) < 0 ? 'negative' : 'positive'}">${(headcounttotalAop !== 0 && ((headcounttotalActuals - headcounttotalAop) / headcounttotalAop * 100 * ((headcounttotalActuals - headcounttotalAop) < 0 && headcounttotalAop < 0 ? -1 : 1)).toFixed(1)) || 0
            }%</td>
    <td></td>
    <td></td>
    <td></td>
</tr>`;



        //    monthlyHtml += `</table>


        // <script>
        //     function printPDF() { window.print(); }
        //     let isExpanded = false;
        //     function toggleAllRows() {
        //         const allRows = document.querySelectorAll('[data-group]');
        //         allRows.forEach(row => {
        //             if (isExpanded) {
        //                 row.style.display = 'none';
        //             } else {
        //                 row.style.display = 'table-row';
        //             }
        //         });
        //         const buttons = document.querySelectorAll('.subcategory-toggle');
        //         buttons.forEach(button => {
        //             button.textContent = isExpanded ? '+' : '-';
        //             button.classList.toggle('plus-state', button.textContent === '+');
        //         });
        //         isExpanded = !isExpanded;
        //         document.getElementById('toggleAllBtn').title = isExpanded ? "Collapse All" : "Expand All";
        //         document.getElementById('toggleAllBtn').textContent = isExpanded ? '+' : '-';
        //     }
        //     function toggleRows(group, btn) {
        //         const rows = document.querySelectorAll('[data-group="' + group + '"]');
        //         const isVisible = rows.length > 0 && rows[0].style.display === 'table-row';
        //         rows.forEach(row => {
        //             row.style.display = isVisible ? 'none' : 'table-row';
        //         });
        //         btn.textContent = isVisible ? '+' : '-';
        //         btn.classList.toggle('plus-state', btn.textContent === '+');
        //     }
        // </script>
        // </body></html>`;

        monthlyHtml += `</table>`
        var monthsOnlyHtml = monthlyHtml

        log.debug("months only html immediately after assiging monthlyHtml", monthsOnlyHtml)

        tableHtml += monthlyHtml


        var tagCloser = `<script>
    function printPDF() { window.print(); }
    let isExpanded = false;
    function toggleAllRows() {
        const allRows = document.querySelectorAll('[data-group]');
        allRows.forEach(row => {
            if (isExpanded) {
                row.style.display = 'none';
            } else {
                row.style.display = 'table-row';
            }
        });
        const buttons = document.querySelectorAll('.toggle-button, .subcategory-toggle');
        console.log('Toggle All: Found', buttons.length, 'buttons'); // Debug log
        buttons.forEach(button => {
            button.textContent = isExpanded ? '+' : '-';
            button.classList.toggle('plus-state', button.textContent === '+');
        });
        isExpanded = !isExpanded;
        document.getElementById('toggleAllBtn').title = isExpanded ? "Collapse All" : "Expand All";
        document.getElementById('toggleAllBtn').textContent = isExpanded ? '+' : '-';
    }
    function toggleRows(group, btn) {
        const rows = document.querySelectorAll('[data-group="' + group + '"]');
        console.log('Toggle Rows: Group', group, 'Found', rows.length, 'rows'); // Debug log
        const isVisible = rows.length > 0 && rows[0].style.display === 'table-row';
        rows.forEach(row => {
            row.style.display = isVisible ? 'none' : 'table-row';
        });
        btn.textContent = isVisible ? '+' : '-';
        btn.classList.toggle('plus-state', btn.textContent === '+');
        console.log('Button classes:', btn.className); // Debug log
    }
</script>
</body></html>`;

        tableHtml += tagCloser

        log.debug("monthsOnlyHtml", monthsOnlyHtml)

var monthAndYear=getMonthAndYear(accountingPeriod).toString()

        var htmlFile = file.create({
            name: 'monthlyReport' + subsidiaryName + '_' + monthAndYear + '.html',         // file name
            fileType: file.Type.HTMLDOC, // saves as HTML
            contents: tableHtml,       // your HTML string
            folder: 11897             // Internal ID of target folder in File Cabinet
        });

        log.debug("html file saved",htmlFile)

        var monthOnlyFile = file.create({
            name: 'monthlyTable' + subsidiaryName + '_' + monthAndYear + '.txt',         // file name
            fileType: file.Type.PLAINTEXT, // saves as HTML
            contents: monthsOnlyHtml,       // your HTML string
            folder: 11901             // Internal ID of target folder in File Cabinet
        });



        // Save file in File Cabinet
        if (htmlFile) {
            var fileId = htmlFile.save();
        }
        if (monthOnlyFile) {
            var monthsTableFileId = monthOnlyFile.save();
            log.debug("months only file saved", monthsTableFileId)
        }


        return { fileId: fileId, monthsTableFileId: monthsTableFileId, arrPart: arrPart, arrActTotal: arrActTotal, arrAopTotal, arrDiff, arrPer, monthNumber: monthNumber, monthName: monthName, fyName: fyName, yearName: yearName };
    }
 catch(e){
        log.error("error in monthly function, rescheduling process...",e)
        
    }

    }
   

    function generateQtdReport(quarterQueryResults1, quarterQueryResults2, stagingTableId, subsidiaryChildPlaceHolders, subsidiaryIds, accountingPeriod, subsidiary, aprilId, tableHtml, yearName, arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer) {
      try{
                            log.debug("main quarter function, units left", runtime.getCurrentScript().getRemainingUsage())
                        yearName = getYearName(accountingPeriod)
                        log.debug("year name in qtd",yearName)

        log.debug("staging table id in qtd", stagingTableId)
        var quarterlyHtml = ''
        var quarterMonthsFunction = getQuarterMonthIds(accountingPeriod);
        var quarterMonthIds = quarterMonthsFunction.quarterMonthIds;
        var selectedQuarterName = quarterMonthsFunction.selectedQuarterName;
        var selectedQuarter = quarterMonthsFunction.selectedQuarter;
        var selectedQuarterFullName = quarterMonthsFunction.selectedQuarterFullName;

        log.debug("current table id", stagingTableId)
  
        var stringArray = [];
        for (var i = 0; i < quarterMonthIds.length; i++) {
            stringArray.push(quarterMonthIds[i].toString());
        }

        log.debug("stringArray", stringArray)
        var periodPlaceholders = '';
        if (stringArray.length > 0) {
            periodPlaceholders = stringArray.map(() => '?').join(',');
            log.debug("period placeholders", periodPlaceholders)
        }



        var previousPeriodInternalIds = getPreviousYearAccountingPeriods(stringArray);
        log.debug("previousPeriodInternalIds", previousPeriodInternalIds)
        var previousMonthsPlaceHolders = previousPeriodInternalIds.map(item => "?").join(",");


        var quarterQueryResultSet1;
        var quarterQueryResultSet2;
      
        var quarterGroupedResults = {}
        var quarterChildData = {}
        var subcategoryTotals = {};
        let qtdNetNewBookings = 0;



        let qtdNetNewQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  -- Budget data
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Custom record data
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
 z.period in (${periodPlaceholders}) and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;`;



        var netParams = [...stringArray, ...subsidiaryIds];
        let qtdNetResults=[]
        if((subsidiaryIds.length>0)&&(stringArray.length>0) && (periodPlaceholders.length>0) && (subsidiaryChildPlaceHolders.length>0)){
         qtdNetResults = query.runSuiteQL({ query: qtdNetNewQuery, params: netParams }).asMappedResults();
        }
        else{
            qtdNetResults=[]
        }
        let qnetNewAop = 0;
        let qnetNewActuals = 0;
        let qnetNewVariance = 0;
        let qnetNewVariancePer = 0
        let qnetNewActualsSum = 0;
        let qnetNewAopSum = 0;
        let qnetNewVarianceSum = 0;
        let qnetNewVariancePerSum = 0;


        qtdNetResults.forEach(row => {
            let qnetNewAop = row.arr_netnew_aop1;
            let qnetNewActuals = row.arr_netnew_actuals1;
            let isNegative = qnetNewAop < 0 && qnetNewActuals < 0;
            if (isNegative) {
                qnetNewAop = (qnetNewAop);
                qnetNewActuals = (qnetNewActuals);
            }

            let qnetNewVariance = qnetNewActuals - qnetNewAop;
            let qnetNewVariancePer = qnetNewAop !== 0
                ? (qnetNewVariance / qnetNewAop) * 100
                : 0; // Avoid division by zero
            if (isNegative) {
                qnetNewActualsSum += -qnetNewActuals;
                qnetNewAopSum += -qnetNewAop;
                qnetNewVarianceSum += -qnetNewVariance;
                qnetNewVariancePerSum += -qnetNewVariancePer;
            } else {
                qnetNewActualsSum += qnetNewActuals;
                qnetNewAopSum += qnetNewAop;
                qnetNewVarianceSum += qnetNewVariance;
                qnetNewVariancePerSum += qnetNewVariancePer;
            }
        });

        log.debug("passing april id", aprilId)


        let clientDataPart = ''

        let qtotalClientsAct = 0;
        let qtotalClientsAop = 0;
        let q2ClosingBalanceAct = 0;
        let q2ClosingBalanceAop = 0;
        let q3ClosingBalanceAct = 0;
        let q3ClosingBalanceAop = 0;
        let q4ClosingBalanceAct = 0;
        let q4ClosingBalanceAop = 0;
        let firstQuarterAllMonthsData;
        let q1closingbalanceAct;
        let q1closingbalanceAop;
        let secondQuarterAllMonthsData;
        var q2closingbalanceAct;
        var q2closingbalanceAop;
        let thirdQuarterAllMonthsData;
        var qsalesAndMarketingActuals, qproductActuals, qgeneraladminActuals, qcustomersuccessActuals, qranddActuals, qprofservicesActuals, qheadcounttotalActuals = 0

        firstQuarterAllMonthsData = getFirstQuarterAllMonthsData(selectedQuarterFullName, aprilId, subsidiaryChildPlaceHolders, subsidiaryIds);

        q1closingbalanceAct = firstQuarterAllMonthsData.q1closingbalanceAct;
        q1closingbalanceAop = firstQuarterAllMonthsData.q1closingbalanceAop;
        log.debug("q1 closing balance actuals", q1closingbalanceAct)
        log.debug("q1 closing balance aop", q1closingbalanceAop)




        secondQuarterAllMonthsData = getSecondQuarterAllMonthsData(selectedQuarterFullName, q1closingbalanceAct, q1closingbalanceAop, subsidiaryChildPlaceHolders, subsidiaryIds)
        q2closingbalanceAct = secondQuarterAllMonthsData.q2closingbalanceAct;
        q2closingbalanceAop = secondQuarterAllMonthsData.q2closingbalanceAop;

        log.debug("q2 closing balance actuals", q2closingbalanceAct)
        log.debug("q2 closing balance aop", q2closingbalanceAop)



        thirdQuarterAllMonthsData = getThirdQuarterAllMonthsData(selectedQuarterFullName, q2closingbalanceAct, q2closingbalanceAop, subsidiaryChildPlaceHolders, subsidiaryIds);

        q3closingbalanceAct = thirdQuarterAllMonthsData.q3closingbalanceAct;
        q3closingbalanceAop = thirdQuarterAllMonthsData.q3closingbalanceAop;

        log.debug("q3 closing balance actuals", q3closingbalanceAct)
        log.debug("q3 closing balance aop", q3closingbalanceAop)






        if (selectedQuarterName === 'Q1') {
            let clientQueryResultsFunctionQ1 = getClientQueryResultsQ1(periodPlaceholders, stringArray, aprilId, subsidiaryChildPlaceHolders, subsidiaryIds);

            log.debug("subsidiaryIds", subsidiaryIds);
            log.debug("subsidiaryChildPlaceHolders", subsidiaryChildPlaceHolders);

            let qnewClientsAct = clientQueryResultsFunctionQ1.qnewClientsAct;
            let qattritionAct = clientQueryResultsFunctionQ1.qattritionAct;
            let qnewClientsAop = clientQueryResultsFunctionQ1.qnewClientsAop;
            let qattritionAop = clientQueryResultsFunctionQ1.qattritionAop;
            let qexistingAct = clientQueryResultsFunctionQ1.qexistingAct;
            let qexistingAop = clientQueryResultsFunctionQ1.qexistingAop;
            qtotalClientsAct = clientQueryResultsFunctionQ1.qtotalClientsAct;
            qtotalClientsAop = clientQueryResultsFunctionQ1.qtotalClientsAop;

            clientDataPart += `<tr class="client-data">
            <td>New Clients</td>
            <td class="${Number(qnewClientsAct || 0) < 0 ? 'negative' : 'positive'}">${(qnewClientsAct || 0)}</td>
            <td class="${Number(qnewClientsAop || 0) < 0 ? 'negative' : 'positive'}">${(qnewClientsAop || 0)}</td>
            <td class="${Number((qnewClientsAct - qnewClientsAop) || 0) < 0 ? 'negative' : 'positive'}">${(qnewClientsAct - qnewClientsAop) || 0}</td>
            <td class="${Number(((qnewClientsAop !== 0) && (qnewClientsAct && qnewClientsAop) ? ((qnewClientsAct - qnewClientsAop) / qnewClientsAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(qnewClientsAop !== 0) && (qnewClientsAct && qnewClientsAop) ? ((qnewClientsAct - qnewClientsAop) / qnewClientsAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Attrition</td>
            <td class="${Number(qattritionAct || 0) < 0 ? 'negative' : 'positive'}">${(qattritionAct || 0)}</td>
            <td class="${Number(qattritionAop || 0) < 0 ? 'negative' : 'positive'}">${(qattritionAop || 0)}</td>
            <td class="${Number((qattritionAct - qattritionAop) || 0) < 0 ? 'negative' : 'positive'}">${(qattritionAct - qattritionAop) || 0}</td>
            <td class="${Number(((qattritionAop !== 0) && (qattritionAct && qattritionAop) ? ((qattritionAct - qattritionAop) / qattritionAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(qattritionAop !== 0) && (qattritionAct && qattritionAop) ? ((qattritionAct - qattritionAop) / qattritionAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Existing</td>
            <td class="${Number(qexistingAct || 0) < 0 ? 'negative' : 'positive'}">${(qexistingAct || 0)}</td>
            <td class="${Number(qexistingAop || 0) < 0 ? 'negative' : 'positive'}">${(qexistingAop || 0)}</td>
            <td class="${Number((qexistingAct - qexistingAop) || 0) < 0 ? 'negative' : 'positive'}">${(qexistingAct - qexistingAop) || 0}</td>
            <td class="${Number(((qexistingAop !== 0) && (qexistingAct && qexistingAop) ? ((qexistingAct - qexistingAop) / qexistingAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(qexistingAop !== 0) && (qexistingAct && qexistingAop) ? ((qexistingAct - qexistingAop) / qexistingAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="total-row">
            <td>Total Clients</td>
            <td class="${Number(qtotalClientsAct || 0) < 0 ? 'negative' : 'positive'}">${(qtotalClientsAct || 0)}</td>
            <td class="${Number(qtotalClientsAop || 0) < 0 ? 'negative' : 'positive'}">${(qtotalClientsAop || 0)}</td>
            <td class="${Number((qtotalClientsAct > 0 && qtotalClientsAop > 0) ? (qtotalClientsAct - qtotalClientsAop) : (qtotalClientsAct + qtotalClientsAop)) < 0 ? 'negative' : 'positive'}">${(qtotalClientsAct > 0 && qtotalClientsAop > 0) ? (qtotalClientsAct - qtotalClientsAop) : (qtotalClientsAct + qtotalClientsAop)}</td>
            <td class="${Number(((qtotalClientsAop !== 0) && (qtotalClientsAct && qtotalClientsAop) ? ((qtotalClientsAct - qtotalClientsAop) / qtotalClientsAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(qtotalClientsAop !== 0) && (qtotalClientsAct && qtotalClientsAop) ? ((qtotalClientsAct - qtotalClientsAop) / qtotalClientsAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>`;
        } else if (selectedQuarterName === 'Q2') {
            let QuarterClientsDataFunctionQ2 = getQuarterClientsDataQ2(periodPlaceholders, stringArray, q1closingbalanceAct, q1closingbalanceAop, subsidiaryIds, subsidiaryChildPlaceHolders);

            log.debug("subsidiaryIds", subsidiaryIds);
            log.debug("subsidiaryChildPlaceHolders", subsidiaryChildPlaceHolders);
            let q2AttritionActuals = QuarterClientsDataFunctionQ2.qattritionAct;
            let q2AttritionAop = QuarterClientsDataFunctionQ2.qattritionAop;
            let q2NewClAct = QuarterClientsDataFunctionQ2.qnewClientsAct;
            let q2NewClAop = QuarterClientsDataFunctionQ2.qnewClientsAop;
            let q2ExisitingAct = QuarterClientsDataFunctionQ2.qexistingAct;
            let q2ExistingAop = QuarterClientsDataFunctionQ2.qexistingAop;
            q2ClosingBalanceAct = QuarterClientsDataFunctionQ2.qtotalClientsActq2;
            q2ClosingBalanceAop = QuarterClientsDataFunctionQ2.qtotalClientsAopq2;

            clientDataPart += `<tr class="client-data">
            <td>New Clients</td>
            <td class="${Number(q2NewClAct) < 0 ? 'negative' : 'positive'}">${q2NewClAct}</td>
            <td class="${Number(q2NewClAop) < 0 ? 'negative' : 'positive'}">${q2NewClAop}</td>
            <td class="${Number(q2NewClAct - q2NewClAop) < 0 ? 'negative' : 'positive'}">${q2NewClAct - q2NewClAop}</td>
            <td class="${Number(((q2NewClAop !== 0) && (q2NewClAct && q2NewClAop) ? ((q2NewClAct - q2NewClAop) / q2NewClAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q2NewClAop !== 0) && (q2NewClAct && q2NewClAop) ? ((q2NewClAct - q2NewClAop) / q2NewClAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Attrition</td>
            <td class="${Number(q2AttritionActuals) < 0 ? 'negative' : 'positive'}">${q2AttritionActuals}</td>
            <td class="${Number(q2AttritionAop) < 0 ? 'negative' : 'positive'}">${q2AttritionAop}</td>
            <td class="${Number(q2AttritionActuals - q2AttritionAop) < 0 ? 'negative' : 'positive'}">${q2AttritionActuals - q2AttritionAop}</td>
            <td class="${Number(((q2AttritionAop !== 0) && (q2AttritionActuals && q2AttritionAop) ? ((q2AttritionActuals - q2AttritionAop) / q2AttritionAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q2AttritionAop !== 0) && (q2AttritionActuals && q2AttritionAop) ? ((q2AttritionActuals - q2AttritionAop) / q2AttritionAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Existing</td>
            <td class="${Number(q2ExisitingAct) < 0 ? 'negative' : 'positive'}">${q2ExisitingAct}</td>
            <td class="${Number(q2ExistingAop) < 0 ? 'negative' : 'positive'}">${q2ExistingAop}</td>
            <td class="${Number(q2ExisitingAct - q2ExistingAop) < 0 ? 'negative' : 'positive'}">${q2ExisitingAct - q2ExistingAop}</td>
            <td class="${Number(((q2ExistingAop !== 0) && (q2ExisitingAct && q2ExistingAop) ? ((q2ExisitingAct - q2ExistingAop) / q2ExistingAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q2ExistingAop !== 0) && (q2ExisitingAct && q2ExistingAop) ? ((q2ExisitingAct - q2ExistingAop) / q2ExistingAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="total-row">
            <td>Total Clients</td>
            <td class="${Number(q2ClosingBalanceAct) < 0 ? 'negative' : 'positive'}">${q2ClosingBalanceAct}</td>
            <td class="${Number(q2ClosingBalanceAop) < 0 ? 'negative' : 'positive'}">${q2ClosingBalanceAop}</td>
            <td class="${Number(q2ClosingBalanceAct - q2ClosingBalanceAop) < 0 ? 'negative' : 'positive'}">${q2ClosingBalanceAct - q2ClosingBalanceAop}</td>
            <td class="${Number(((q2ClosingBalanceAop !== 0) && (q2ClosingBalanceAct && q2ClosingBalanceAop) ? ((q2ClosingBalanceAct - q2ClosingBalanceAop) / q2ClosingBalanceAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q2ClosingBalanceAop !== 0) && (q2ClosingBalanceAct && q2ClosingBalanceAop) ? ((q2ClosingBalanceAct - q2ClosingBalanceAop) / q2ClosingBalanceAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>`;
        } else if (selectedQuarterName === 'Q3') {
            var quarterClientsDataq3 = getQuarterClientsDataQ3(periodPlaceholders, stringArray, q2closingbalanceAct, q2closingbalanceAop, subsidiaryIds, subsidiaryChildPlaceHolders);

            log.debug("subsidiaryIds", subsidiaryIds);
            log.debug("subsidiaryChildPlaceHolders", subsidiaryChildPlaceHolders);
            var q3AttritionActuals = quarterClientsDataq3.qattritionAct;
            var q3AttritionAop = quarterClientsDataq3.qattritionAop;
            var q3NewClAct = quarterClientsDataq3.qnewClientsAct;
            var q3NewClAop = quarterClientsDataq3.qnewClientsAop;
            var q3ExisitingAct = quarterClientsDataq3.qexistingAct;
            var q3ExistingAop = quarterClientsDataq3.qexistingAop;
            q3ClosingBalanceAct = quarterClientsDataq3.qtotalClientsActq3;
            q3ClosingBalanceAop = quarterClientsDataq3.qtotalClientsAopq3;

            clientDataPart += `<tr class="client-data">
            <td>New Clients</td>
            <td class="${Number(q3NewClAct) < 0 ? 'negative' : 'positive'}">${q3NewClAct}</td>
            <td class="${Number(q3NewClAop) < 0 ? 'negative' : 'positive'}">${q3NewClAop}</td>
            <td class="${Number(q3NewClAct - q3NewClAop) < 0 ? 'negative' : 'positive'}">${q3NewClAct - q3NewClAop}</td>
            <td class="${Number(((q3NewClAop !== 0) && (q3NewClAct && q3NewClAop) ? ((q3NewClAct - q3NewClAop) / q3NewClAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q3NewClAop !== 0) && (q3NewClAct && q3NewClAop) ? ((q3NewClAct - q3NewClAop) / q3NewClAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Attrition</td>
            <td class="${Number(q3AttritionActuals) < 0 ? 'negative' : 'positive'}">${q3AttritionActuals}</td>
            <td class="${Number(q3AttritionAop) < 0 ? 'negative' : 'positive'}">${q3AttritionAop}</td>
            <td class="${Number(q3AttritionActuals - q3AttritionAop) < 0 ? 'negative' : 'positive'}">${q3AttritionActuals - q3AttritionAop}</td>
            <td class="${Number(((q3AttritionAop !== 0) && (q3AttritionActuals && q3AttritionAop) ? ((q3AttritionActuals - q3AttritionAop) / q3AttritionAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q3AttritionAop !== 0) && (q3AttritionActuals && q3AttritionAop) ? ((q3AttritionActuals - q3AttritionAop) / q3AttritionAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Existing</td>
            <td class="${Number(q3ExisitingAct) < 0 ? 'negative' : 'positive'}">${q3ExisitingAct}</td>
            <td class="${Number(q3ExistingAop) < 0 ? 'negative' : 'positive'}">${q3ExistingAop}</td>
            <td class="${Number(q3ExisitingAct - q3ExistingAop) < 0 ? 'negative' : 'positive'}">${q3ExisitingAct - q3ExistingAop}</td>
            <td class="${Number(((q3ExistingAop !== 0) && (q3ExisitingAct && q3ExistingAop) ? ((q3ExisitingAct - q3ExistingAop) / q3ExistingAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q3ExistingAop !== 0) && (q3ExisitingAct && q3ExistingAop) ? ((q3ExisitingAct - q3ExistingAop) / q3ExistingAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="total-row">
            <td>Total Clients</td>
            <td class="${Number(q3ClosingBalanceAct) < 0 ? 'negative' : 'positive'}">${q3ClosingBalanceAct}</td>
            <td class="${Number(q3ClosingBalanceAop) < 0 ? 'negative' : 'positive'}">${q3ClosingBalanceAop}</td>
            <td class="${Number(q3ClosingBalanceAct - q3ClosingBalanceAop) < 0 ? 'negative' : 'positive'}">${q3ClosingBalanceAct - q3ClosingBalanceAop}</td>
            <td class="${Number(((q3ClosingBalanceAop !== 0) && (q3ClosingBalanceAct && q3ClosingBalanceAop) ? ((q3ClosingBalanceAct - q3ClosingBalanceAop) / q3ClosingBalanceAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q3ClosingBalanceAop !== 0) && (q3ClosingBalanceAct && q3ClosingBalanceAop) ? ((q3ClosingBalanceAct - q3ClosingBalanceAop) / q3ClosingBalanceAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>`;
        } else if (selectedQuarterName === 'Q4') {
            var quarterClientsDataq4 = getQuarterClientsDataQ4(periodPlaceholders, stringArray, q3closingbalanceAct, q3closingbalanceAop, subsidiaryIds, subsidiaryChildPlaceHolders);

            let q4AttritionActuals = quarterClientsDataq4.qattritionAct;
            let q4AttritionAop = quarterClientsDataq4.qattritionAop;
            let q4NewClAct = quarterClientsDataq4.qnewClientsAct;
            let q4NewClAop = quarterClientsDataq4.qnewClientsAop;
            let q4ExisitingAct = quarterClientsDataq4.qexistingAct;
            let q4ExistingAop = quarterClientsDataq4.qexistingAop;
            q4ClosingBalanceAct = quarterClientsDataq4.qtotalClientsActq4;
            q4ClosingBalanceAop = quarterClientsDataq4.qtotalClientsAopq4;

            clientDataPart += `<tr class="client-data">
            <td>New Clients</td>
            <td class="${Number(q4NewClAct) < 0 ? 'negative' : 'positive'}">${q4NewClAct}</td>
            <td class="${Number(q4NewClAop) < 0 ? 'negative' : 'positive'}">${q4NewClAop}</td>
            <td class="${Number(q4NewClAct - q4NewClAop) < 0 ? 'negative' : 'positive'}">${q4NewClAct - q4NewClAop}</td>
            <td class="${Number(((q4NewClAop !== 0) && (q4NewClAct && q4NewClAop) ? ((q4NewClAct - q4NewClAop) / q4NewClAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q4NewClAop !== 0) && (q4NewClAct && q4NewClAop) ? ((q4NewClAct - q4NewClAop) / q4NewClAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Attrition</td>
            <td class="${Number(q4AttritionActuals) < 0 ? 'negative' : 'positive'}">${q4AttritionActuals}</td>
            <td class="${Number(q4AttritionAop) < 0 ? 'negative' : 'positive'}">${q4AttritionAop}</td>
            <td class="${Number(q4AttritionActuals - q4AttritionAop) < 0 ? 'negative' : 'positive'}">${q4AttritionActuals - q4AttritionAop}</td>
            <td class="${Number(((q4AttritionAop !== 0) && (q4AttritionActuals && q4AttritionAop) ? ((q4AttritionActuals - q4AttritionAop) / q4AttritionAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q4AttritionAop !== 0) && (q4AttritionActuals && q4AttritionAop) ? ((q4AttritionActuals - q4AttritionAop) / q4AttritionAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="client-data">
            <td>Existing</td>
            <td class="${Number(q4ExisitingAct) < 0 ? 'negative' : 'positive'}">${q4ExisitingAct}</td>
            <td class="${Number(q4ExistingAop) < 0 ? 'negative' : 'positive'}">${q4ExistingAop}</td>
            <td class="${Number(q4ExisitingAct - q4ExistingAop) < 0 ? 'negative' : 'positive'}">${q4ExisitingAct - q4ExistingAop}</td>
            <td class="${Number(((q4ExistingAop !== 0) && (q4ExisitingAct && q4ExistingAop) ? ((q4ExisitingAct - q4ExistingAop) / q4ExistingAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q4ExistingAop !== 0) && (q4ExisitingAct && q4ExistingAop) ? ((q4ExisitingAct - q4ExistingAop) / q4ExistingAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr class="total-row">
            <td>Total Clients</td>
            <td class="${Number(q4ClosingBalanceAct) < 0 ? 'negative' : 'positive'}">${q4ClosingBalanceAct}</td>
            <td class="${Number(q4ClosingBalanceAop) < 0 ? 'negative' : 'positive'}">${q4ClosingBalanceAop}</td>
            <td class="${Number(q4ClosingBalanceAct - q4ClosingBalanceAop) < 0 ? 'negative' : 'positive'}">${q4ClosingBalanceAct - q4ClosingBalanceAop}</td>
            <td class="${Number(((q4ClosingBalanceAop !== 0) && (q4ClosingBalanceAct && q4ClosingBalanceAop) ? ((q4ClosingBalanceAct - q4ClosingBalanceAop) / q4ClosingBalanceAop * 100) : 0)) < 0 ? 'negative' : 'positive'}">${(q4ClosingBalanceAop !== 0) && (q4ClosingBalanceAct && q4ClosingBalanceAop) ? ((q4ClosingBalanceAct - q4ClosingBalanceAop) / q4ClosingBalanceAop * 100).toFixed(1) + '%' : '0%'}</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>`;
        }

        let qSalesAndMarketing = 0;
        let qProduct = 0;
        let qGeneraladmin = 0;
        let qCustomersuccess = 0;
        let qRandd = 0;
        let qProfservices = 0;

        let qHeadCountQuery = `SELECT 
  period,  
  SUM(z.SM_HC_aop) AS SM_HC_aop1, 
  SUM(z.Product_HC_aop) AS Product_HC_aop1, 
  SUM(z.GA_HC_AOP) AS GA_HC_AOP1,
  SUM(z.Cs_hc_aop) AS Cs_hc_aop1, 
  SUM(z.rd_hc_aop) AS rd_hc_aop1,
  SUM(z.pso_hc_aop) AS pso_hc_aop1,
  SUM(z.salesandmarketting) AS salesandmarketting, 
  SUM(z.product) AS product1,
  SUM(z.generaladmin) AS generaladmin1,
  SUM(z.customersuccess) AS customersuccess1,
  SUM(z.randd) AS randd1,
  SUM(z.profservices) AS profservices1
FROM (

  -- SM_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    SUM(bm.amount) AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2301
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Product_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    SUM(bm.amount) AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2302
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- GA_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    SUM(bm.amount) AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2303
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- CS_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    SUM(bm.amount) AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2304
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- R&D
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    SUM(bm.amount) AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2305
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- PSO
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    SUM(bm.amount) AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2306
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from Custom Record
  SELECT  
    custrecord1 AS period,
    custrecord_tyfone_subsidiary_dashboard2 AS subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    custrecord_ty_headcount_sal_mar AS salesandmarketting, 
    custrecord_ty_headcount_product_report AS product, 
    custrecord_ty_headcount_generaladmin AS generaladmin, 
    custrecord_ty_headcount_cust_success_ AS customersuccess, 
    custrecord_ty_headcount_rd_report AS randd, 
    custrecord_ty_headcount_profser_report AS profservices
  FROM CUSTOMRECORD_TYFONE_HEADCOUNT_REPORT

) z
WHERE 
  z.period = ?
  AND z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period;
`
var qHeadCountResults;
if((accountingPeriod!=null)&&(stringArray.length>0)){
         qHeadCountResults = query.runSuiteQL({ query: qHeadCountQuery, params: [accountingPeriod, ...subsidiaryIds] }).asMappedResults();
        qHeadCountResults.forEach(row => {
            qsalesAndMarketingActuals = Number(row.salesandmarketting) || 0;
            qproductActuals = Number(row.product1) || 0;
            qgeneraladminActuals = Number(row.generaladmin1) || 0;
            qcustomersuccessActuals = Number(row.customersuccess1) || 0;
            qranddActuals = Number(row.randd1) || 0;
            qprofservicesActuals = Number(row.profservices1) || 0;

            qheadcounttotalActuals = qsalesAndMarketingActuals + qproductActuals + qgeneraladminActuals + qcustomersuccessActuals + qranddActuals

            log.debug("qheadcounttotalActuals inside", qheadcounttotalActuals)

            qsalesAndMarketingAop = Number(row.sm_hc_aop1) || 0;
            qproductAop = Number(row.product_hc_aop1) || 0;
            qgeneralAdminAop = Number(row.ga_hc_aop1) || 0;
            qcustomersuccessAop = Number(row.cs_hc_aop1) || 0;
            qranddAop = Number(row.rd_hc_aop1) || 0;
            qprofservicesAop = Number(row.rd_hc_aop1) || 0;

            qheadcounttotalAop = qsalesAndMarketingAop + qproductAop + qgeneralAdminAop + qcustomersuccessAop + qranddAop

        });
    }
    else{
        qHeadCountResults=[]
    }

        var departmentIds = []

        log.debug("qHeadCountResults", qHeadCountResults)
        log.debug("department ids", departmentIds)
        // log.debug("department ids length",departmentIds.length)






        const queryParams = [
            ...stringArray,
            ...stringArray,
            ...previousPeriodInternalIds,
            ...previousPeriodInternalIds,
            ...subsidiaryIds
        ];




        log.debug("query params for qtd query", queryParams)
        var quarterQueryParent = ``
        var quarterQueryChild = ``
        var parameters = []
      


        let quarterClassificationTotal = {}; // INITIALIZE HERE
        let quarterArrActTotal = 0;
        let quarterArrAopTotal = 0;
        let quarterArrDiff = 0;
        let quarterArrPer = 0;
        if (quarterQueryResults1 && quarterQueryResults1.length > 0) {
            quarterQueryResults1.forEach(row => {
                const qClassification = row.classification.trim();
                if (!quarterGroupedResults[qClassification]) {
                    quarterGroupedResults[qClassification] = [];
                }
                quarterGroupedResults[qClassification].push(row);
            });
        }
        quarterQueryResults2.forEach(childRow => {
            const classification = childRow.classification.trim();
            const parentName = childRow.name;
            const subcategory = childRow.subcategory || parentName; // Default if null
            if (!quarterChildData[classification]) {
                quarterChildData[classification] = {};
                subcategoryTotals[classification] = {};
            }
            if (!quarterChildData[classification][parentName]) {
                quarterChildData[classification][parentName] = [];
                subcategoryTotals[classification][parentName] = {};
            }

            if (!quarterChildData[classification][parentName][subcategory]) {
                quarterChildData[classification][parentName][subcategory] = [];
                subcategoryTotals[classification][parentName][subcategory] = {
                    actuals: 0,
                    aop: 0,
                    variance: 0,
                    pre_actuals: 0,
                    pre_variance2: 0
                };
            }

            quarterChildData[classification][parentName][subcategory].push(childRow);
            subcategoryTotals[classification][parentName][subcategory].actuals += Number(childRow.actuals) || 0;
            subcategoryTotals[classification][parentName][subcategory].aop += Number(childRow.aop) || 0;
            subcategoryTotals[classification][parentName][subcategory].variance += Number(childRow.variance) || 0;
            subcategoryTotals[classification][parentName][subcategory].pre_actuals += Number(childRow.pre_actuals) || 0;
            subcategoryTotals[classification][parentName][subcategory].pre_variance2 += Number(childRow.pre_variance2) || 0;
        });
        if (quarterGroupedResults['Recurring Revenue']) {
            quarterArrActTotal = quarterGroupedResults['Recurring Revenue'].reduce((sum, row) => sum + (Number(row.actuals) || 0), 0) * 12;
            quarterArrAopTotal = quarterGroupedResults['Recurring Revenue'].reduce((sum, row) => sum + (Number(row.aop) || 0), 0) * 12;
            quarterArrDiff = quarterArrActTotal - quarterArrAopTotal;
            quarterArrPer = (quarterArrAopTotal !== 0) && (quarterArrDiff && quarterArrAopTotal) ? ((quarterArrDiff / quarterArrAopTotal) * 100).toFixed(1) + '%' : 0;
        }
        const contractedActualsTotal = arrActTotal + qnetNewActualsSum;
        const contractedAopTotal = arrAopTotal + qnetNewAopSum;
        const contractedVariance = (contractedActualsTotal) - (contractedAopTotal);
        const contractedVariancePer = (contractedAopTotal !== 0) && (contractedVariance && contractedAopTotal) ? ((contractedVariance / contractedAopTotal) * 100).toFixed(1) + '%' : 0;

        var subsidiaryRec = record.load({
            type: 'customrecord_tyf_subs_hier_',
            id: subsidiary
        })

        subsidiaryName = subsidiaryRec.getValue({ fieldId: 'name' })
         var monthNumber = null;
var monthName = null;

if (accountingPeriod) {
    monthNumber = getMonthNumber(accountingPeriod);
    log.debug("month number at qtd",monthNumber)
}

if (monthNumber !== null) {
    monthName = getMonthName(accountingPeriod);
     log.debug("month name at qtd",monthName)
}
        quarterlyHtml += `<table width="100%" style="page-break-before: auto;"><thead>
    <tr><th colspan="8" style="text-align: center; font-size: 17pt; color: white; background-color: #454444;"> ${subsidiaryName}  ${selectedQuarterName} - QTD (${monthName} ' ${yearName})</th></tr>

    <tr>
        <td width="30%">Particulars</th>
        <td width="10%">Actuals</th>
        <td width="10%">AOP</th>
        <td width="10%">Variance</th>
        <td width="10%">Variance (%)</th>
        <td width="10%">Previous Year<br/>Actuals </th>
        <td width="10%">Previous Year<br/>Variance </th>
        <td width="10%">Previous Year<br/>Variance (%) </th>
    </tr></thead>
`;
        var qTotalOperatingRevenueActuals = 0;
        var qTotalOperatingRevenueAOP = 0;
        var qTotalOperatingRevenueDiff = 0;
        var qTotalRevenueActuals = 0;
        var qTotalRevenueAOP = 0;
        var qTotalRevenueDiff = 0;
        var qTotalRevenuePer = 0
        var qTotalPreRevenueAct = 0;
        var qTotalPrevVar = 0;
        var qTotalPrevVarPer = 0;
        var qTotalCostOfRevenueActuals = 0;
        var qTotalCostOfRevenueAOP = 0;
        var qTotalCostOfRevenuePreAct = 0;
        var qGrossMarginActuals = 0;
        var qGrossMarginAOP = 0;
        var qGrossMarginDiff = 0;
        var qGrossMarginPerActuals = 0;
        var qGrossMarginPerAOP = 0;
        var qGrossMarginPerDiff = 0;
        var qTotalOperatingRevenuePer;
        var qTotalOperatingRevenuePrevAct = 0;
        var qTotalOperatingRevenuePrevVar = 0;
        var qTotalPreOperatingRevenuePer = 0;
        var qOtherOperatingExpensesActualTotal = 0;
        var qOtherOperatingExpensesAOP = 0;
        var qOtherOperatingExpensesDiff = 0;
        var qOtherOperatingExpensesPer = 0;
        var qOtherOperatingExpensesPreAct, qOtherOperatingExpensesPreVar, totalQpreOperatingActual, totalQpreOperatingActualDiff, totalQpreOperatingActualDiffPer;
        var qOperatingExpensesActualTotal = 0;
        var qOperatingExpensesAOP = 0;
        var qOperatingExpensesDiff = 0;
        var qOperatingExpensesPer = 0;
        var qOtherExpensesTotalActuals, qOtherExpensesTotalAOP, qOtherExpensesTotalDiff, qOtherExpensesTotalPer, qOtherExpensesTotalPreActuals, qOtherExpensesTotalPreDiff;
        var qOtherIncomeTotalActuals, qOtherIncomeTotalAOP, qOtherIncomeTotalDiff, qOtherIncomeTotalPer, qOtherTotalPreIncomeAct, qOtherTotalPreIncomeVar, qOtherPreIncomeVarPer;
        var totalQOperatingActual, totalQOperatingAOP, totalQOperatingDiff, totalQOperatingPer;
        var qTotal;
        var qNetProfitActuals, qNetProfitAOP, qNetProfitDiff, qNetProfitPer, qNetPrevProfitActuals, qNetPrevProfitDiff, qNetProfitPrePer;
        var qGrossMarginPreAct, qGrossMarginPreVar, qGrossMarginVarPer, qGrossMarginPrePerAct;
        var qOperatingExpPreAct, qOperatingExpPreVar;
        var qsalesAndMarketingActuals, qproductActuals, qgeneraladminActuals, qcustomersuccessActuals, qranddActuals, qprofservicesActuals,
            qheadcounttotalActuals, qsalesAndMarketingAop, qproductAop, qgeneralAdminAop, qcustomersuccessAop, qranddAop, qprofservicesAop, qheadcounttotalAop;
        for (var qClassification in quarterGroupedResults) {
            quarterClassificationTotal[qClassification] = {
                actuals: 0,
                aop: 0,
                difference: 0,
                pre_actuals: 0,
                pre_variance: 0
            };
            quarterGroupedResults[qClassification].forEach(parentRow => {
                quarterClassificationTotal[qClassification].actuals += Number(parentRow.actuals) || 0;
                quarterClassificationTotal[qClassification].aop += Number(parentRow.aop) || 0;
                quarterClassificationTotal[qClassification].difference += Number(parentRow.variance) || 0;
                quarterClassificationTotal[qClassification].pre_actuals += Number(parentRow.pre_actuals) || 0;
                quarterClassificationTotal[qClassification].pre_variance += Number(parentRow.pre_variance2) || 0;


            });

            // Initialize parent index for unique IDs
            let parentIndex = 0;

            for (var qClassification in quarterGroupedResults) {
                quarterClassificationTotal[qClassification] = {
                    actuals: 0,
                    aop: 0,
                    difference: 0,
                    pre_actuals: 0,
                    pre_variance: 0
                };
                quarterGroupedResults[qClassification].forEach(parentRow => {
                    quarterClassificationTotal[qClassification].actuals += Number(parentRow.actuals) || 0;
                    quarterClassificationTotal[qClassification].aop += Number(parentRow.aop) || 0;
                    quarterClassificationTotal[qClassification].difference += Number(parentRow.variance) || 0;
                    quarterClassificationTotal[qClassification].pre_actuals += Number(parentRow.pre_actuals) || 0;
                    quarterClassificationTotal[qClassification].pre_variance += Number(parentRow.pre_variance2) || 0;
                });
                quarterlyHtml += `
    <tr>
        <td class="classification-section" colspan="8">${qClassification}</td>
    </tr>`;

                quarterGroupedResults[qClassification].forEach(parentRow => {
                    parentIndex++;
                    const parentGroup = `parent_quarter_${parentIndex}_subcats`;
                    const actuals = Number(parentRow.actuals) || 0;
                    const aop = Number(parentRow.aop) || 0;
                    const difference = Number(parentRow.variance) || 0;
                    const parentName = parentRow.name;
                    const variancePercent = (aop !== 0) ? ((difference / aop) * 100).toFixed(1) : 0;
                    const pre_actuals = Number(parentRow.pre_actuals) || 0;
                    const pre_variance = Number(parentRow.pre_variance2) || 0;
                    const pre_variance_per = (pre_actuals !== 0) ? ((pre_variance / pre_actuals) * 100).toFixed(1) : 0;
                    const varianceClass = difference < 0 ? 'negative' : 'positive';
                    const hasChildren = quarterChildData[qClassification] && quarterChildData[qClassification][parentName] && Object.keys(quarterChildData[qClassification][parentName]).length > 0;

                    quarterlyHtml += `
        <tr class="parent-row">
            <td width="30%">
                ${hasChildren ? `<button class="toggle-button plus-state" onclick="toggleRows('${parentGroup}', this)">+</button>` : ''}
                ${parentName}
            </td>
            <td width="10%" class="${Number(actuals) < 0 ? 'negative' : 'positive'}">${Math.round(actuals).toLocaleString()}</td>
            <td width="10%" class="${Number(aop) < 0 ? 'negative' : 'positive'}">${Math.round(aop).toLocaleString()}</td>
            <td width="10%" class="${Number(difference) < 0 ? 'negative' : 'positive'}">${Math.round(difference).toLocaleString()}</td>
            <td width="10%" class="${Number(variancePercent) < 0 ? 'negative' : 'positive'}">${variancePercent}%</td>
            <td width="10%" class="${Number(pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(pre_actuals).toLocaleString()}</td>
            <td width="10%" class="${Number(pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(pre_variance).toLocaleString()}</td>
            <td width="10%" class="${Number(pre_variance_per) < 0 ? 'negative' : 'positive'}">${pre_variance_per}%</td>
        </tr>`;

                    if (hasChildren) {
                        let subcatIndex = 0;
                        for (let subcategory in quarterChildData[qClassification][parentName]) {
                            subcatIndex++;
                            const subcatGroup = `qtd_subcat_${parentIndex}_${subcatIndex}_children`;
                            const subcatTotal = subcategoryTotals[qClassification][parentName][subcategory];
                            const subcatActuals = subcatTotal.actuals;
                            const subcatAop = subcatTotal.aop;
                            const subcatDifference = subcatTotal.variance;
                            const subcatPreActuals = subcatTotal.pre_actuals;
                            const subcatPreVariance = subcatTotal.pre_variance2;
                            const subcatVariancePercent = (subcatAop !== 0) ? ((subcatDifference / subcatAop) * 100).toFixed(1) : 0;
                            const subcatPreVariancePer = (subcatPreActuals !== 0) ? ((subcatPreVariance / subcatPreActuals) * 100).toFixed(1) : 0;
                            const subcatVarianceClass = subcatDifference < 0 ? 'negative' : 'positive';

                            quarterlyHtml += `
                <tr class="subcategory-row" data-group="${parentGroup}" style="display:none;">
                    <td width="30%">
                        <button class="subcategory-toggle plus-state" onclick="toggleRows('${subcatGroup}', this)">+</button>
                        ${subcategory}
                    </td>
                    <td width="10%" class="${Number(subcatActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatAop) < 0 ? 'negative' : 'positive'}">${Math.round(subcatAop).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatDifference) < 0 ? 'negative' : 'positive'}">${Math.round(subcatDifference).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatVariancePercent) < 0 ? 'negative' : 'positive'}">${subcatVariancePercent}%</td>
                    <td width="10%" class="${Number(subcatPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreVariance).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariancePer) < 0 ? 'negative' : 'positive'}">${subcatPreVariancePer}%</td>
                </tr>`;

                            quarterChildData[qClassification][parentName][subcategory].forEach(childRow => {
                                const childActuals = Number(childRow.actuals) || 0;
                                const childAop = Number(childRow.aop) || 0;
                                const childDifference = Number(childRow.variance) || 0;
                                const childVariancePercent = (childAop !== 0) ? ((childDifference / childAop) * 100).toFixed(1) : 0;
                                const childVarianceClass = childDifference < 0 ? 'negative' : 'positive';
                                const childPreActuals = Number(childRow.pre_actuals) || 0;
                                const childPreVariance = Number(childRow.pre_variance2) || 0;
                                const childPreVariancePer = (childPreActuals !== 0) ? ((childPreVariance / childPreActuals) * 100).toFixed(1) : 0;

                                quarterlyHtml += `
                    <tr class="child-row" data-group="${subcatGroup}" style="display:none;">
                        <td width="30%">${childRow.acctnumber}&nbsp;${childRow.accountsearchdisplaynamecopy}</td>
                        <td width="10%" class="${Number(childActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(childAop) < 0 ? 'negative' : 'positive'}">${Math.round(childAop).toLocaleString()}</td>
                        <td width="10%" class="${Number(childDifference) < 0 ? 'negative' : 'positive'}">${Math.round(childDifference).toLocaleString()}</td>
                        <td width="10%" class="${Number(childVariancePercent) < 0 ? 'negative' : 'positive'}">${childVariancePercent}%</td>
                        <td width="10%" class="${Number(childPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childPreActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(childPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(childPreVariance).toLocaleString()}</td>
                        <td width="10%" class="${Number(childPreVariancePer) < 0 ? 'negative' : 'positive'}">${childPreVariancePer}%</td>
                    </tr>`;
                            });
                        }
                    }
                });

                // Total row calculations
                qTotal = quarterClassificationTotal[qClassification];
                const totalVariancePercent = (qTotal.aop !== 0) ? ((qTotal.difference / qTotal.aop) * 100).toFixed(1) : 0;
                const totalVarianceClass = qTotal.difference < 0 ? 'negative' : 'positive';
                const totalPrevVarPercent = (qTotal.pre_actuals !== 0) ? ((qTotal.pre_variance / qTotal.pre_actuals) * 100).toFixed(1) : 0;

                if (qClassification === 'Recurring Revenue' || qClassification === 'Non Recurring Revenue') {
                    qTotalOperatingRevenueActuals += qTotal.actuals;
                    qTotalOperatingRevenueAOP += qTotal.aop;
                    qTotalOperatingRevenueDiff += qTotal.difference;
                    qTotalOperatingRevenuePer = (qTotalOperatingRevenueAOP !== 0) ? ((qTotalOperatingRevenueDiff / qTotalOperatingRevenueAOP) * 100).toFixed(1) : 0;
                    qTotalOperatingRevenuePrevAct += qTotal.pre_actuals;
                    qTotalOperatingRevenuePrevVar += qTotal.pre_variance;
                    qTotalPreOperatingRevenuePer = (qTotalOperatingRevenuePrevAct !== 0) ? ((qTotalOperatingRevenuePrevVar / qTotalOperatingRevenuePrevAct) * 100).toFixed(1) : 0;
                }

                if (qClassification === 'Non Recurring Revenue') {
                    quarterlyHtml += `<tr class="total-row">
            <td>TOTAL ${qClassification}</td>
            <td class="${Number(qTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.aop).toLocaleString()}</td>
            <td class="${Number(qTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
            <td class="${Number(qTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}%</td>
        </tr><tr class="summary-rows">
            <td>TOTAL OPERATING REVENUE</td>
            <td class="${Number(qTotalOperatingRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalOperatingRevenueActuals).toLocaleString()}</td>
            <td class="${Number(qTotalOperatingRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalOperatingRevenueAOP).toLocaleString()}</td>
            <td class="${Number(qTotalOperatingRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalOperatingRevenueDiff).toLocaleString()}</td>
            <td class="${Number(qTotalOperatingRevenuePer) < 0 ? 'negative' : 'positive'}">${qTotalOperatingRevenuePer}%</td>
            <td class="${Number(qTotalOperatingRevenuePrevAct) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalOperatingRevenuePrevAct).toLocaleString()}</td>
            <td class="${Number(qTotalOperatingRevenuePrevVar) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalOperatingRevenuePrevVar).toLocaleString()}</td>
            <td class="${Number(qTotalPreOperatingRevenuePer) < 0 ? 'negative' : 'positive'}">${qTotalPreOperatingRevenuePer}%</td>
        </tr>`;
                } else if (qClassification === 'OTHER INCOME') {
                    qOtherIncomeTotalActuals = qTotal.actuals;
                    qOtherIncomeTotalAOP = qTotal.aop;
                    qOtherIncomeTotalDiff = qTotal.difference;
                    qOtherIncomeTotalPer = (qTotal.aop !== 0) ? ((qOtherIncomeTotalDiff / qTotal.aop) * 100).toFixed(1) + '%' : '0%';
                    qOtherTotalPreIncomeAct = qTotal.pre_actuals;
                    qOtherTotalPreIncomeVar = qTotal.pre_variance;
                    qOtherPreIncomeVarPer = (qOtherTotalPreIncomeAct !== 0) ? ((qOtherTotalPreIncomeVar / qOtherTotalPreIncomeAct) * 100).toFixed(1) + '%' : '0%';

                    qTotalRevenueActuals = qTotalOperatingRevenueActuals + qTotal.actuals;
                    qTotalRevenueAOP = qTotalOperatingRevenueAOP + qTotal.aop;
                    qTotalRevenueDiff = qTotalRevenueActuals - qTotalRevenueAOP;
                    qTotalRevenuePer = (qTotalRevenueAOP !== 0) ? ((qTotalRevenueDiff / qTotalRevenueAOP) * 100).toFixed(1) : 0;
                    qTotalPreRevenueAct = qTotalOperatingRevenuePrevAct + qTotal.pre_actuals;
                    qTotalPrevVar = qTotalOperatingRevenuePrevVar + qTotal.pre_variance;
                    qTotalPrevVarPer = (qTotalPreRevenueAct !== 0) ? ((qTotalPrevVar / qTotalPreRevenueAct) * 100).toFixed(1) : 0;

                    quarterlyHtml += `<tr class="total-row">
            <td>TOTAL ${qClassification}</td>
            <td class="${Number(qTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.aop).toLocaleString()}</td>
            <td class="${Number(qTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
            <td class="${Number(qTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}%</td>
        </tr><tr class="summary-rows">
            <td>Total Revenue</td>
            <td class="${Number(qTotalRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalRevenueActuals).toLocaleString()}</td>
            <td class="${Number(qTotalRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalRevenueAOP).toLocaleString()}</td>
            <td class="${Number(qTotalRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalRevenueDiff).toLocaleString()}</td>
            <td class="${Number(qTotalRevenuePer) < 0 ? 'negative' : 'positive'}">${qTotalRevenuePer}%</td>
            <td class="${Number(qTotalPreRevenueAct) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalPreRevenueAct).toLocaleString()}</td>
            <td class="${Number(qTotalPrevVar) < 0 ? 'negative' : 'positive'}">${Math.round(qTotalPrevVar).toLocaleString()}</td>
            <td class="${Number(qTotalPrevVarPer) < 0 ? 'negative' : 'positive'}">${qTotalPrevVarPer}%</td>
        </tr>`;
                } else if (qClassification === 'Cost of Revenue') {
                    qTotalCostOfRevenueActuals = qTotal.actuals;
                    qTotalCostOfRevenueAOP = qTotal.aop;
                    qTotalCostOfRevenuePreAct = qTotal.pre_actuals;

                    qGrossMarginActuals = qTotalOperatingRevenueActuals - qTotalCostOfRevenueActuals;
                    qGrossMarginAOP = qTotalOperatingRevenueAOP - qTotalCostOfRevenueAOP;
                    qGrossMarginDiff = qGrossMarginAOP - qGrossMarginActuals;
                    qGrossMarginPer = (qGrossMarginAOP !== 0) ? ((qGrossMarginDiff / qGrossMarginAOP) * 100).toFixed(1) : 0;
                    qGrossMarginPerActuals = (qTotalOperatingRevenueActuals !== 0) ? ((qGrossMarginActuals / qTotalOperatingRevenueActuals) * 100).toFixed(1) : 0;
                    qGrossMarginPerAOP = (qTotalOperatingRevenueAOP !== 0) ? ((qGrossMarginAOP / qTotalOperatingRevenueAOP) * 100).toFixed(1) : 0;
                    qGrossMarginPerDiff = qGrossMarginPerActuals - qGrossMarginPerAOP;
                    qGrossMarginPreAct = qTotalOperatingRevenuePrevAct - qTotalCostOfRevenuePreAct;
                    qGrossMarginPreVar = qGrossMarginPreAct - qGrossMarginActuals;
                    qGrossMarginVarPer = (qGrossMarginPreAct !== 0) ? ((qGrossMarginPreVar / qGrossMarginPreAct) * 100).toFixed(1) : 0;
                    qGrossMarginPrePerAct = (qTotalOperatingRevenuePrevAct !== 0) ? ((qGrossMarginPreAct / qTotalOperatingRevenuePrevAct) * 100).toFixed(1) : 0;

                    quarterlyHtml += `<tr class="total-row">
            <td>TOTAL ${qClassification}</td>
            <td class="${Number(qTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.aop).toLocaleString()}</td>
            <td class="${Number(qTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
            <td class="${Number(qTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr><tr class="summary-rows">
            <td>Gross Margin (excl. other income)</td>
            <td class="${Number(qGrossMarginActuals) < 0 ? 'negative' : 'positive'}">${Math.round(qGrossMarginActuals).toLocaleString()}</td>
            <td class="${Number(qGrossMarginAOP) < 0 ? 'negative' : 'positive'}">${Math.round(qGrossMarginAOP).toLocaleString()}</td>
            <td class="${Number(qGrossMarginDiff) < 0 ? 'negative' : 'positive'}">${Math.round(qGrossMarginDiff).toLocaleString()}</td>
<td class="${Number(qGrossMarginPer) < 0 ? 'negative' : 'positive'}">
  ${Number(qGrossMarginPer).toFixed(1)}%
</td>            <td class="${Number(qGrossMarginPreAct) < 0 ? 'negative' : 'positive'}">${Math.round(qGrossMarginPreAct).toLocaleString()}</td>
            <td class="${Number(qGrossMarginPreVar) < 0 ? 'negative' : 'positive'}">${Math.round(qGrossMarginPreVar).toLocaleString()}</td>
            <td class="${Number(qGrossMarginVarPer) < 0 ? 'negative' : 'positive'}">${qGrossMarginVarPer}%</td>
        </tr><tr class="summary-rows">
    <td>Gross Margin %</td>

    <!-- Actuals -->
    <td class="${Number(qGrossMarginPerActuals) < 0 ? 'negative' : 'positive'}">
        ${Number(qGrossMarginPerActuals || 0).toFixed(1)}%
    </td>

    <!-- AOP -->
    <td class="${Number(qGrossMarginPerAOP) < 0 ? 'negative' : 'positive'}">
        ${Number(qGrossMarginPerAOP || 0).toFixed(1)}%
    </td>

    <td></td>

    <!-- Diff -->
    <td class="${Number(qGrossMarginPerDiff) < 0 ? 'negative' : 'positive'}">
        ${Number(qGrossMarginPerDiff || 0).toFixed(1)}%
    </td>

    <!-- Previous Period Actuals -->
    <td class="${Number(qGrossMarginPrePerAct) < 0 ? 'negative' : 'positive'}">
        ${Number(qGrossMarginPrePerAct || 0).toFixed(1)}%
    </td>

    <td></td>

    <!-- YoY / QoQ change -->
    <td class="${(Number(qGrossMarginPerActuals || 0) - Number(qGrossMarginPrePerAct || 0)) < 0 ? 'negative' : 'positive'}">
        ${(Number(qGrossMarginPerActuals || 0) - Number(qGrossMarginPrePerAct || 0)).toFixed(1)}%
    </td>
</tr>
`;
                } else if (qClassification === 'OPERATING EXPENSES') {
                    qOperatingExpensesActualTotal = qTotal.actuals;
                    qOperatingExpensesAOP = qTotal.aop;
                    qOperatingExpensesDiff = qTotal.difference;
                    qOperatingExpensesPer = (qTotal.aop !== 0) ? ((qOperatingExpensesDiff / qTotal.aop) * 100).toFixed(1) + '%' : '0%';
                    qOperatingExpPreAct = qTotal.pre_actuals;
                    qOperatingExpPreVar = qTotal.pre_variance;

                    quarterlyHtml += `<tr class="total-row">
            <td>HEADCOUNT COST</td>
            <td class="${Number(qTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.aop).toLocaleString()}</td>
            <td class="${Number(qTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
            <td class="${Number(qTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}%</td>
        </tr>`;
                } else if (qClassification === 'Other Operating Expenses' || qClassification === 'Other Operating Expenses ') {
                    qOtherOperatingExpensesActualTotal = qTotal.actuals;
                    qOtherOperatingExpensesAOP = qTotal.aop;
                    qOtherOperatingExpensesDiff = qTotal.difference;
                    qOtherOperatingExpensesPer = (qTotal.aop !== 0) ? ((qOtherOperatingExpensesDiff / qTotal.aop) * 100).toFixed(1) + '%' : '0%';
                    qOtherOperatingExpensesPreAct = qTotal.pre_actuals;
                    qOtherOperatingExpensesPreVar = qTotal.pre_variance;

                    totalQOperatingActual = qOperatingExpensesActualTotal + qOtherOperatingExpensesActualTotal;
                    totalQOperatingAOP = qOperatingExpensesAOP + qOtherOperatingExpensesAOP;
                    totalQOperatingDiff = totalQOperatingAOP - totalQOperatingActual;
                    totalQOperatingPer = (totalQOperatingAOP !== 0) ? ((totalQOperatingDiff / totalQOperatingAOP) * 100).toFixed(1) : 0;
                    totalQpreOperatingActual = qOperatingExpPreAct + qOtherOperatingExpensesPreAct;
                    totalQpreOperatingActualDiff = totalQpreOperatingActual - totalQOperatingActual;
                    totalQpreOperatingActualDiffPer = (totalQpreOperatingActual !== 0) ? ((totalQpreOperatingActualDiff / totalQpreOperatingActual) * 100).toFixed(1) : 0;

                    const qProFormaEbitaActuals = qGrossMarginActuals - totalQOperatingActual;
                    const qProFormaEbitaAOP = qGrossMarginAOP - totalQOperatingAOP;
                    const qProFormaEbitaDiff = qProFormaEbitaAOP - qProFormaEbitaActuals;
                    const qProFormaEbitaPer = (qProFormaEbitaAOP !== 0) ? ((qProFormaEbitaDiff / qProFormaEbitaAOP) * 100).toFixed(1) : 0;

                    const qProFormaEbitaPreActuals = qGrossMarginPreAct - totalQpreOperatingActual;
                    const qProFormaEbitaPreDiff = qProFormaEbitaActuals - qProFormaEbitaPreActuals;
                    const qProFormaEbitaPreDiffPer = (qProFormaEbitaPreActuals !== 0) ? ((qProFormaEbitaPreDiff / qProFormaEbitaPreActuals) * 100).toFixed(1) : 0;

                    const qProFormaEbitaPerActuals = (qTotalOperatingRevenueActuals !== 0) ? ((qProFormaEbitaActuals / qTotalOperatingRevenueActuals) * 100).toFixed(1) : '0';
                    const qProFormaEbitaPerAOP = (qTotalOperatingRevenueAOP !== 0) ? ((qProFormaEbitaAOP / qTotalOperatingRevenueAOP) * 100).toFixed(1) : '0';
                    const qProFormaEbitaPerDiff = qProFormaEbitaPerActuals - qProFormaEbitaPerAOP;

                    const qProFormaEbitaPrePerActuals = (qTotalOperatingRevenuePrevAct !== 0) ? ((qProFormaEbitaPreActuals / qTotalOperatingRevenuePrevAct) * 100).toFixed(1) : '0';

                    const qProFormaEbitaPrePerDiff = qProFormaEbitaPerActuals - qProFormaEbitaPrePerActuals;

                    quarterlyHtml += `<tr class="total-row">
            <td>TOTAL ${qClassification}</td>
            <td class="${Number(qTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.aop).toLocaleString()}</td>
            <td class="${Number(qTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
            <td class="${Number(qTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr><tr class="summary-rows">
            <td>Total Operating Expenses</td>
            <td class="${Number(totalQOperatingActual) < 0 ? 'negative' : 'positive'}">${Math.round(totalQOperatingActual).toLocaleString()}</td>
            <td class="${Number(totalQOperatingAOP) < 0 ? 'negative' : 'positive'}">${Math.round(totalQOperatingAOP).toLocaleString()}</td>
            <td class="${Number(totalQOperatingDiff) < 0 ? 'negative' : 'positive'}">${Math.round(totalQOperatingDiff).toLocaleString()}</td>
            <td class="${Number(totalQOperatingPer) < 0 ? 'negative' : 'positive'}">${totalQOperatingPer}%</td>
            <td class="${Number(totalQpreOperatingActual) < 0 ? 'negative' : 'positive'}">${Math.round(totalQpreOperatingActual).toLocaleString()}</td>
            <td class="${Number(totalQpreOperatingActualDiff) < 0 ? 'negative' : 'positive'}">${Math.round(totalQpreOperatingActualDiff).toLocaleString()}</td>
            <td class="${Number(totalQpreOperatingActualDiffPer) < 0 ? 'negative' : 'positive'}">${totalQpreOperatingActualDiffPer}%</td>
        </tr><tr class="summary-rows">
            <td>Pro Forma EBITDA</td>
            <td class="${Number(qProFormaEbitaActuals) < 0 ? 'negative' : 'positive'}">${Math.round(qProFormaEbitaActuals).toLocaleString()}</td>
            <td class="${Number(qProFormaEbitaAOP) < 0 ? 'negative' : 'positive'}">${Math.round(qProFormaEbitaAOP).toLocaleString()}</td>
            <td class="${Number(qProFormaEbitaDiff) < 0 ? 'negative' : 'positive'}">${Math.round(qProFormaEbitaDiff).toLocaleString()}</td>
            <td class="${Number(qProFormaEbitaPer) < 0 ? 'negative' : 'positive'}">${qProFormaEbitaPer}%</td>
            <td class="${Number(qProFormaEbitaPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(qProFormaEbitaPreActuals).toLocaleString()}</td>
            <td class="${Number(qProFormaEbitaPreDiff) < 0 ? 'negative' : 'positive'}">${Math.round(qProFormaEbitaPreDiff).toLocaleString()}</td>
            <td class="${Number(qProFormaEbitaPreDiffPer) < 0 ? 'negative' : 'positive'}">${qProFormaEbitaPreDiffPer}</td>
        </tr><tr class="summary-rows">
            <td>Pro Forma EBITDA %</td>
            <td class="${Number(qProFormaEbitaPerActuals) < 0 ? 'negative' : 'positive'}">${qProFormaEbitaPerActuals}%</td>
            <td class="${Number(qProFormaEbitaPerAOP) < 0 ? 'negative' : 'positive'}">${qProFormaEbitaPerAOP}%</td>
            <td></td>
            <td class="${Number(qProFormaEbitaPerDiff) < 0 ? 'negative' : 'positive'}">${qProFormaEbitaPerDiff.toFixed(1)}%</td>
            <td class="${Number(qProFormaEbitaPrePerActuals) < 0 ? 'negative' : 'positive'}">${qProFormaEbitaPrePerActuals}%</td>
            <td></td>
            <td class="${Number(qProFormaEbitaPrePerDiff) < 0 ? 'negative' : 'positive'}">${qProFormaEbitaPrePerDiff.toFixed(1)}%</td>
        </tr>`;
                } else if (qClassification === 'Other expenses') {
                    qOtherExpensesTotalActuals = qTotal.actuals;
                    qOtherExpensesTotalAOP = qTotal.aop;
                    qOtherExpensesTotalDiff = qOtherExpensesTotalAOP - qOtherExpensesTotalActuals;
                    qOtherExpensesTotalPer = (qOtherExpensesTotalAOP !== 0) ? ((qOtherExpensesTotalDiff / qOtherExpensesTotalAOP) * 100).toFixed(1) + '%' : '0%';
                    qOtherExpensesTotalPreActuals = qTotal.pre_actuals;
                    qOtherExpensesTotalPreDiff = qTotal.pre_variance;

                    qNetProfitActuals = qGrossMarginActuals - totalQOperatingActual - qOtherExpensesTotalActuals + qOtherIncomeTotalActuals;
                    qNetProfitAOP = qGrossMarginAOP - totalQOperatingAOP - qOtherExpensesTotalAOP + qOtherIncomeTotalAOP;
                    qNetProfitDiff = qNetProfitActuals - qNetProfitAOP;
                    qNetProfitPer = (qNetProfitAOP !== 0) ? ((qNetProfitDiff / qNetProfitAOP) * 100).toFixed(1) : 0;

                    qNetPrevProfitActuals = qGrossMarginPreAct - totalQpreOperatingActual - qOtherExpensesTotalPreActuals + qOtherTotalPreIncomeAct;
                    qNetPrevProfitDiff = qNetProfitActuals - qNetPrevProfitActuals;
                    qNetProfitPrePer = (qNetPrevProfitActuals !== 0) ? ((qNetPrevProfitDiff / qNetPrevProfitActuals) * 100).toFixed(1) : 0;

                    quarterlyHtml += `<tr class="total-row">
            <td>TOTAL ${qClassification}</td>
            <td class="${Number(qTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.aop).toLocaleString()}</td>
            <td class="${qTotal.difference}">${Math.round(qTotal.difference).toLocaleString()}</td>
            <td class="${totalVariancePercent}">${totalVariancePercent}%</td>
            <td class="${Number(qTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}%</td>
        </tr><tr class="summary-rows">
            <td>Net Profit</td>
            <td class="${Number(qNetProfitActuals) < 0 ? 'negative' : 'positive'}">${Math.round(qNetProfitActuals).toLocaleString()}</td>
            <td class="${Number(qNetProfitAOP) < 0 ? 'negative' : 'positive'}">${Math.round(qNetProfitAOP).toLocaleString()}</td>
            <td class="${Number(qNetProfitDiff) < 0 ? 'negative' : 'positive'}">${Math.round(qNetProfitDiff).toLocaleString()}</td>
            <td class="${Number(qNetProfitPer) < 0 ? 'negative' : 'positive'}">${qNetProfitPer}</td>
            <td class="${Number(qNetPrevProfitActuals) < 0 ? 'negative' : 'positive'}">${Math.round(qNetPrevProfitActuals).toLocaleString()}</td>
            <td class="${Number(qNetPrevProfitDiff) < 0 ? 'negative' : 'positive'}">${Math.round(qNetPrevProfitDiff).toLocaleString()}</td>
            <td class="${Number(qNetProfitPrePer) < 0 ? 'negative' : 'positive'}">${qNetProfitPrePer}</td>
        </tr>`;
                } else {
                    quarterlyHtml += `<tr class="total-row">
            <td>TOTAL ${qClassification}</td>
            <td class="${Number(qTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.aop).toLocaleString()}</td>
            <td class="${Number(qTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}%</td>
            <td class="${Number(qTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(qTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(qTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}%</td>
        </tr>`;
                }
            }

            // Add Contracted ARR, Client Data, and Headcount sections
            quarterlyHtml += `<tr class="classification-section"><td colspan="8">CONTRACTED ARR ($)</td></tr>${arrPart}
<tr class="arrtable">
    <td border="1">ARR Net New Bookings (MRR from SF x 12)</td>
    <td border="1" class="${Number(qnetNewActualsSum) < 0 ? 'negative' : 'positive'}">${Math.round(qnetNewActualsSum).toLocaleString()}</td>
    <td border="1" class="${Number(qnetNewAopSum) < 0 ? 'negative' : 'positive'}">${Math.round(qnetNewAopSum).toLocaleString()}</td>
    <td border="1" class="${(Number(qnetNewActualsSum) - Number(qnetNewAopSum)) < 0 ? 'negative' : 'positive'}">${Math.round(qnetNewActualsSum - qnetNewAopSum).toLocaleString()}</td>
    <td border="1"  class="${(qnetNewAopSum !== 0 && ((qnetNewActualsSum - qnetNewAopSum) / qnetNewAopSum * 100) < 0) ? 'negative' : 'positive'}">  
       ${(qnetNewAopSum !== 0) ? ((qnetNewActualsSum - qnetNewAopSum) / qnetNewAopSum * 100).toFixed(1) + '%' : '0%'}</td>
    <td border="1" ></td>
    <td border="1"></td>
    <td border="1"></td>
</tr>
<tr class="total-row">
    <td border="1">Total Contracted ARR</td>
    <td border="1" class="${(Number(arrActTotal) + Number(qnetNewActualsSum)) < 0 ? 'negative' : 'positive'}">${Math.round(arrActTotal + qnetNewActualsSum).toLocaleString()}</td>
    <td border="1" class="${(Number(arrAopTotal) + Number(qnetNewAopSum)) < 0 ? 'negative' : 'positive'}">${Math.round(arrAopTotal + qnetNewAopSum).toLocaleString()}</td>
    <td border="1" class="${Math.round(arrDiff + (qnetNewActualsSum - qnetNewAopSum)) < 0 ? 'negative' : 'positive'}">${Math.round(arrDiff + (qnetNewActualsSum - qnetNewAopSum)).toLocaleString()}</td>
    <td border="1" class="${(arrAopTotal + qnetNewAopSum !== 0 && ((arrDiff + (qnetNewActualsSum - qnetNewAopSum)) / (arrAopTotal + qnetNewAopSum) * 100) < 0) ? 'negative' : 'positive'}">${(arrAopTotal + qnetNewAopSum) !== 0 ? (((arrDiff + (qnetNewActualsSum - qnetNewAopSum)) / (arrAopTotal + qnetNewAopSum)) * 100).toFixed(1) + '%' : '0%'}</td>
    <td border="1"></td>
    <td border="1"></td>
    <td border="1"></td>
</tr>
<tr class="classification-section"><td colspan="8">CLIENT DATA (NO.)</td></tr>${clientDataPart}
<tr class="classification-section"><td colspan="8">HEADCOUNT (NO.)</td></tr>
<tr class="parent-row">
    <td>Sales and Marketing</td>
    <td class="${Number(qsalesAndMarketingActuals) < 0 ? 'negative' : 'positive'}">${qsalesAndMarketingActuals}</td>
    <td class="${Number(qsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${qsalesAndMarketingAop}</td>
    <td class="${(Number(qsalesAndMarketingActuals) - Number(qsalesAndMarketingAop)) < 0 ? 'negative' : 'positive'}">${qsalesAndMarketingActuals - qsalesAndMarketingAop}</td>
<td class="${((qsalesAndMarketingAop !== 0) &&
                    ((qsalesAndMarketingActuals - qsalesAndMarketingAop) / qsalesAndMarketingAop * 100) < 0)
                    ? 'negative'
                    : 'positive'
                }">
    ${(qsalesAndMarketingAop !== 0)
                    ? ((qsalesAndMarketingActuals - qsalesAndMarketingAop) / qsalesAndMarketingAop * 100).toFixed(1) + '%'
                    : '0%'
                }
</td>

    <td></td>
    <td></td>
    <td></td>
</tr>
<tr class="parent-row">
    <td>Product</td>
    <td class="${Number(qproductActuals) < 0 ? 'negative' : 'positive'}">${qproductActuals}</td>
    <td class="${Number(qproductAop) < 0 ? 'negative' : 'positive'}">${qproductAop}</td>
    <td class="${Number(qproductActuals - qproductAop) < 0 ? 'negative' : 'positive'}">${qproductActuals - qproductAop}</td>
<td class="${(qproductAop !== 0 && ((qproductActuals - qproductAop) / qproductAop * 100) < 0)
                    ? 'negative'
                    : 'positive'
                }">
    ${(qproductAop !== 0)
                    ? ((qproductActuals - qproductAop) / qproductAop * 100).toFixed(1) + '%'
                    : '0%'
                }
</td>

    <td></td>
    <td></td>
    <td></td>
</tr>
<!-- General & Administrative -->
<tr class="parent-row">
    <td>General & Administrative</td>
    <td class="${Number(qgeneraladminActuals) < 0 ? 'negative' : 'positive'}">
        ${qgeneraladminActuals}
    </td>
    <td class="${Number(qgeneralAdminAop) < 0 ? 'negative' : 'positive'}">
        ${qgeneralAdminAop}
    </td>
    <td class="${Number(qgeneraladminActuals - qgeneralAdminAop) < 0 ? 'negative' : 'positive'}">
        ${qgeneraladminActuals - qgeneralAdminAop}
    </td>
    <td class="${(qgeneralAdminAop !== 0 &&
                    ((qgeneraladminActuals - qgeneralAdminAop) / qgeneralAdminAop * 100) < 0)
                    ? 'negative'
                    : 'positive'
                }">
        ${(qgeneralAdminAop !== 0)
                    ? ((qgeneraladminActuals - qgeneralAdminAop) / qgeneralAdminAop * 100).toFixed(1) + '%'
                    : '0%'
                }
    </td>
    <td></td><td></td><td></td>
</tr>

<!-- Customer Success -->
<tr class="parent-row">
    <td>Customer Success</td>
    <td class="${Number(qcustomersuccessActuals) < 0 ? 'negative' : 'positive'}">
        ${qcustomersuccessActuals}
    </td>
    <td class="${Number(qcustomersuccessAop) < 0 ? 'negative' : 'positive'}">
        ${qcustomersuccessAop}
    </td>
    <td class="${Number(qcustomersuccessActuals - qcustomersuccessAop) < 0 ? 'negative' : 'positive'}">
        ${qcustomersuccessActuals - qcustomersuccessAop}
    </td>
    <td class="${(qcustomersuccessAop !== 0 &&
                    ((qcustomersuccessActuals - qcustomersuccessAop) / qcustomersuccessAop * 100) < 0)
                    ? 'negative'
                    : 'positive'
                }">
        ${(qcustomersuccessAop !== 0)
                    ? ((qcustomersuccessActuals - qcustomersuccessAop) / qcustomersuccessAop * 100).toFixed(1) + '%'
                    : '0%'
                }
    </td>
    <td></td><td></td><td></td>
</tr>

<!-- R & D -->
<tr class="parent-row">
    <td>R &amp; D</td>
    <td class="${Number(qranddActuals) < 0 ? 'negative' : 'positive'}">
        ${qranddActuals}
    </td>
    <td class="${Number(qranddAop) < 0 ? 'negative' : 'positive'}">
        ${qranddAop}
    </td>
    <td class="${Number(qranddActuals - qranddAop) < 0 ? 'negative' : 'positive'}">
        ${qranddActuals - qranddAop}
    </td>
    <td class="${(qranddAop !== 0 &&
                    ((qranddActuals - qranddAop) / qranddAop * 100) < 0)
                    ? 'negative'
                    : 'positive'
                }">
        ${(qranddAop !== 0)
                    ? ((qranddActuals - qranddAop) / qranddAop * 100).toFixed(1) + '%'
                    : '0%'
                }
    </td>
    <td></td><td></td><td></td>
</tr>

<!-- HeadCount Total -->
<tr class="total-row">
    <td>HeadCount Total </td>
    <td class="${Number(qheadcounttotalActuals) < 0 ? 'negative' : 'positive'}">
        ${qheadcounttotalActuals}
    </td>
    <td class="${Number(qheadcounttotalAop) < 0 ? 'negative' : 'positive'}">
        ${qheadcounttotalAop}
    </td>
    <td class="${Number(qheadcounttotalActuals - qheadcounttotalAop) < 0 ? 'negative' : 'positive'}">
        ${qheadcounttotalActuals - qheadcounttotalAop}
    </td>
    <td class="${(qheadcounttotalAop !== 0 &&
                    ((qheadcounttotalActuals - qheadcounttotalAop) / qheadcounttotalAop * 100) < 0)
                    ? 'negative'
                    : 'positive'
                }">
        ${(qheadcounttotalAop !== 0)
                    ? ((qheadcounttotalActuals - qheadcounttotalAop) / qheadcounttotalAop * 100).toFixed(1) + '%'
                    : '0%'
                }
    </td>
    <td></td><td></td><td></td>
</tr>
</table>`

            var qtdOnlyTablesHtml = quarterlyHtml

            tableHtml += quarterlyHtml



            var qtdCloserPart = `<script>
function printPDF() {
    window.print();
}
var isExpanded = false;
function toggleAllRows() {
    var allRows = document.querySelectorAll('[data-group]');
    allRows.forEach(row => {
        row.style.display = isExpanded ? 'none' : 'table-row';
    });
    var buttons = document.querySelectorAll('.toggle-button, .subcategory-toggle');
    buttons.forEach(button => {
        button.textContent = isExpanded ? '+' : '-';
        button.classList.toggle('plus-state', button.textContent === '+');
    });
    isExpanded = !isExpanded;
    document.getElementById('toggleAllBtn').textContent = isExpanded ? "Collapse All" : "Expand All";
}
function toggleRows(group, btn) {
    var rows = document.querySelectorAll('[data-group="' + group + '"]');
    var isVisible = rows.length > 0 && rows[0].style.display === 'table-row';
    rows.forEach(row => {
        row.style.display = isVisible ? 'none' : 'table-row';
    });
    btn.textContent = isVisible ? '+' : '-';
    btn.classList.toggle('plus-state', btn.textContent === '+');
}
</script></body></html>`;

var monthAndYear=getMonthAndYear(accountingPeriod).toString()
            tableHtml += qtdCloserPart
            var htmlFile = file.create({
                name: 'quarterlyReport' + subsidiaryName + '_' + monthAndYear + '.html',         // file name
                fileType: file.Type.HTMLDOC, // saves as HTML
                contents: tableHtml,       // your HTML string
                folder: 11898             // Internal ID of target folder in File Cabinet
            });

            var qtdOnlyTablesFile = file.create({
                name: 'quarterlyTable' + subsidiaryName + '_' + monthAndYear + '.txt',         // file name
                fileType: file.Type.PLAINTEXT, // saves as HTML
                contents: qtdOnlyTablesHtml,       // your HTML string
                folder: 11902             // Internal ID of target folder in File Cabinet
            });


            // Save file in File Cabinet
            var fileId = htmlFile.save();
            var qtdOnlyTablesFileId = qtdOnlyTablesFile.save()

            return { fileId: fileId, qtdOnlyTablesFileId: qtdOnlyTablesFileId };
        }
    }
    catch(e){
        log.error("error in quarter report function, rescheduling process...",e)
        
    }
}

function generateYtdReport(parentResults, childResults, stagingTableId, subsidiaryChildPlaceHolders, subsidiaryIds, accountingPeriod, subsidiary, aprilId, tableHtml, yearName, arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer) {
        try{
                                log.debug("main ytd function, units left", runtime.getCurrentScript().getRemainingUsage())
                                yearName = getYearName(accountingPeriod)
                            log.debug("main ytd year name",yearName)

        var ytdMappedResults
      
        var financialYearMonthsYTDFunction = getFinancialYearMonthsYTD(accountingPeriod);
        // log.debug("departmentPlaceHolders",departmentPlaceHolders)
   
        var monthNumber = null;
var monthName = null;

if (accountingPeriod) {
    monthNumber = getMonthNumber(accountingPeriod);
    log.debug("month number at ytd",monthNumber)
}

if (monthNumber !== null) {
    monthName = getMonthName(accountingPeriod);
     log.debug("month name at ytd",monthName)
}


        var financialYearMonthsYTD = financialYearMonthsYTDFunction.monthIds;
        var financialYearName = financialYearMonthsYTDFunction.financialYearName;
        var firstMonth = financialYearMonthsYTDFunction.firstMonth;
        var lastMonth = financialYearMonthsYTDFunction.lastMonth;

        log.debug("financialYearMonthsYTDFunction", financialYearMonthsYTDFunction)
        var stringArray = [];
        var replicatingArray = []
        for (var i = 0; i < financialYearMonthsYTD.length; i++) {
            log.debug("i loop", i);
            stringArray.push(parseInt(financialYearMonthsYTD[i]));
        }
        var periodPlaceholders = stringArray.map(() => '?').join(',');
        log.debug("string array length", stringArray.length)






        var ytdClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;`;



        let ytdaprilExistingClientsQuery = `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    -- AOP data from budgets
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary

    UNION ALL

    -- Actuals data from custom record
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;`

        var ytdClientParams = [...stringArray, ...subsidiaryIds]
        log.debug("ytdClientParams", ytdClientParams)
let ytdClientResults;

 if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         ytdClientResults = query.runSuiteQL({
            query: ytdClientQuery,
            params: ytdClientParams
        }).asMappedResults();


    }
    else{
       ytdClientResults=[] 
    }

        log.error("client results ytd", JSON.stringify(ytdClientResults))
        log.debug("ytd sub pl", subsidiaryChildPlaceHolders)
        log.debug("ytd period pl", periodPlaceholders)

let ytdaprilExistingClientsQueryResults;


if(aprilId!=null &&(subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0)){
         ytdaprilExistingClientsQueryResults = query.runSuiteQL({
            query: ytdaprilExistingClientsQuery,
            params: [aprilId, ...subsidiaryIds]
        }).asMappedResults();
        log.error("april results ytd", JSON.stringify(ytdaprilExistingClientsQueryResults))


    }
    else{
        ytdaprilExistingClientsQueryResults=[]
    }
        let ytdnewClientsAop = 0
        let ytdattritionAop = 0
        let ytdexistingAop = 0
        let ytdexistingAct = 0;
        let ytdattritionAct = 0;
        let ytdnewClientsAct = 0;

        let ytdtotalClientsAct = 0
        let ytdtotalClientsAop = 0



        let newClientsAct = 0, attritionAct = 0, newClientsAop = 0, attritionAop = 0, existingAct = 0, existingAop = 0;
        let totalClientsAct = 0, totalClientsAop = 0;
        ytdClientResults.forEach(row => {
            ytdnewClientsAct += Number(row.newclient_actuals1) || 0;
            ytdattritionAct += Number(row.attrition_actuals1) || 0;
            ytdnewClientsAop += Number(row.newclients_aop1) || 0;
            ytdattritionAop += Number(row.attrition_aop1) || 0;


        });

        ytdaprilExistingClientsQueryResults.forEach(row => {
            ytdexistingAct += Number(row.existing_actuals1) || 0;
            ytdexistingAop += Number(row.existing_aop1) || 0;

            // let isExistingNegative = existingAct < 0 && existingAop < 0;

            // if (isExistingNegative) {
            //     existingAct = (existingAct);
            //     existingAop = (existingAop);
            // }

        });


        ytdtotalClientsAct = ytdnewClientsAct + ytdattritionAct + ytdexistingAct
        ytdtotalClientsAop = ytdnewClientsAop + ytdattritionAop + ytdexistingAop


        var ytdsalesAndMarketing = 0;
        var ytdproduct = 0;
        var ytdgeneraladmin = 0;
        var ytdcustomersuccess = 0;
        var ytdrandd = 0;
        var ytdprofservices = 0;

        var ytdheadCountQuery = `SELECT 
  period,  
  SUM(z.SM_HC_aop) AS SM_HC_aop1, 
  SUM(z.Product_HC_aop) AS Product_HC_aop1, 
  SUM(z.GA_HC_AOP) AS GA_HC_AOP1,
  SUM(z.Cs_hc_aop) AS Cs_hc_aop1, 
  SUM(z.rd_hc_aop) AS rd_hc_aop1,
  SUM(z.pso_hc_aop) AS pso_hc_aop1,
  SUM(z.salesandmarketting) AS salesandmarketting, 
  SUM(z.product) AS product1,
  SUM(z.generaladmin) AS generaladmin1,
  SUM(z.customersuccess) AS customersuccess1,
  SUM(z.randd) AS randd1,
  SUM(z.profservices) AS profservices1
FROM (

  -- SM_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    SUM(bm.amount) AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2301
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Product_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    SUM(bm.amount) AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2302
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- GA_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    SUM(bm.amount) AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2303
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- CS_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    SUM(bm.amount) AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2304
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- R&D
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    SUM(bm.amount) AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2305
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- PSO
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    SUM(bm.amount) AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2306
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from Custom Record
  SELECT  
    custrecord1 AS period,
    custrecord_tyfone_subsidiary_dashboard2 AS subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    custrecord_ty_headcount_sal_mar AS salesandmarketting, 
    custrecord_ty_headcount_product_report AS product, 
    custrecord_ty_headcount_generaladmin AS generaladmin, 
    custrecord_ty_headcount_cust_success_ AS customersuccess, 
    custrecord_ty_headcount_rd_report AS randd, 
    custrecord_ty_headcount_profser_report AS profservices
  FROM CUSTOMRECORD_TYFONE_HEADCOUNT_REPORT

) z
WHERE 
  z.period = ?
  AND z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period;`

        let ytdsalesAndMarketingActuals, ytdproductActuals, ytdgeneraladminActuals, ytdcustomersuccessActuals, ytdranddActuals, ytdprofservicesActuals,
            ytdheadcounttotalActuals, ytdsalesAndMarketingAop, ytdproductAop, ytdgeneralAdminAop, ytdcustomersuccessAop, ytdranddAop, ytdprofservicesAop, ytdheadcounttotalAop, ytdheadCountResults;
 if((accountingPeriod!=null) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0)){

        ytdheadCountResults = query.runSuiteQL({ query: ytdheadCountQuery, params: [accountingPeriod, ...subsidiaryIds] }).asMappedResults();
        log.error("ytdheadCountResults",ytdheadCountResults)
 }
 else{
    ytdheadCountResults=[]
 }
        ytdheadCountResults.forEach(row => {
            ytdsalesAndMarketingActuals = Number(row.salesandmarketting) || 0;
            ytdproductActuals = Number(row.product1) || 0;
            ytdgeneraladminActuals = Number(row.generaladmin1) || 0;
            ytdcustomersuccessActuals = Number(row.customersuccess1) || 0;
            ytdranddActuals = Number(row.randd1) || 0;
            ytdprofservicesActuals = Number(row.profservices1) || 0;

            ytdheadcounttotalActuals = ytdsalesAndMarketingActuals + ytdproductActuals + ytdgeneraladminActuals + ytdcustomersuccessActuals + ytdranddActuals


            ytdsalesAndMarketingAop = Number(row.sm_hc_aop1) || 0;
            ytdproductAop = Number(row.product_hc_aop1) || 0;
            ytdgeneralAdminAop = Number(row.ga_hc_aop1) || 0;
            ytdcustomersuccessAop = Number(row.cs_hc_aop1) || 0;
            ytdranddAop = Number(row.rd_hc_aop1) || 0;
            ytdprofservicesAop = Number(row.rd_hc_aop1) || 0;

            ytdheadcounttotalAop = ytdsalesAndMarketingAop + ytdproductAop + ytdgeneralAdminAop + ytdcustomersuccessAop + ytdranddAop

        });
        var previousMonthsPlaceHolders;

        var previousYearsMonths = getPreviousYearAccountingPeriods(stringArray);
        log.debug("ytd prev months", previousYearsMonths)
        if (previousYearsMonths) {
            previousMonthsPlaceHolders = previousYearsMonths.map(() => '?').join(',');

        }










        var ytdNetNewQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  -- Budget data
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Custom record data
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders}) and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;`;
var ytdNetResults;
 if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         ytdNetResults = query.runSuiteQL({ query: ytdNetNewQuery, params: [...stringArray, ...subsidiaryIds] }).asMappedResults();
         log.error("ytdNetResults",ytdNetResults)
 }
 else{
    ytdNetResults=[]
 }
        let ytdnetNewAop = 0;
        let ytdnetNewActuals = 0;
        let ytdnetNewVariance = 0;
        let ytdnetNewVariancePer = 0
        let ytdnetNewActualsSum = 0;
        let ytdnetNewAopSum = 0;
        let ytdnetNewVarianceSum = 0;
        let ytdnetNewVariancePerSum = 0;


        ytdNetResults.forEach(row => {
            ytdnetNewAop = row.arr_netnew_aop1;
            ytdnetNewActuals = row.arr_netnew_actuals1;
            ytdnetNewVariance = ytdnetNewActuals - ytdnetNewAop;
            ytdnetNewVariancePer = (ytdnetNewVariance / ytdnetNewAop) * 100

            ytdnetNewActualsSum += ytdnetNewActuals;
            ytdnetNewAopSum += ytdnetNewAop;
            ytdnetNewVarianceSum += ytdnetNewVariance;
            ytdnetNewVariancePerSum = (ytdnetNewVarianceSum / ytdnetNewAopSum) * 100



        })

 
        var departmentIds = []
     






        //       }


        let thisParms = []



        let thisParams = [...stringArray, ...stringArray, ...previousYearsMonths, ...previousYearsMonths, ...subsidiaryIds];

        log.debug("thisParams", thisParams)
        thisParams = thisParams.map(Number);
        stringArray = stringArray.map(Number);
        stringArray = stringArray.toString() + "," + stringArray.toString();
        previousYearsMonths = previousYearsMonths.map(Number);
        previousYearsMonths = previousYearsMonths.toString() + "," + previousYearsMonths.toString();
        subsidiaryIds = subsidiaryIds.map(Number);



        // run parent query for this subsidiary


     





        let ytdTotalOperatingRevenueActuals = 0;
        let ytdTotalOperatingRevenueAOP = 0;
        let ytdTotalOperatingRevenueDiff = 0;
        let ytdTotalOperatingRevenuePreActuals = 0;
        let ytdTotalOperatingRevenuePreVarPer;
        let ytdTotalOperatingRevenuePreVar = 0;



        let ytdTotalRevenueActuals = 0;
        let ytdTotalRevenueAOP = 0;
        let ytdTotalRevenueDiff = 0;
        let ytdTotalRevenuePreActuals = 0;
        let ytdTotalRevenuePreVariance = 0;
        let ytdOtherIncomeTotalPreActuals = 0;
        let ytdOtherIncomeTotalPreVarPer;
        let ytdOtherIncomeTotalPreVar = 0;
        let ytdTotalCostOfRevenueActuals = 0;
        let grossMarginPer;
        let ytdGrossMarginActPer;
        let ytdGrossMarginAopPer;
        let ytdGrossMarginPerVar;
        let ytdGrossMarginPrePer;
        let ytdGrossMarginPrePerAct;





        let ytdTotalCostOfRevenueAOP = 0;
        let ytdTotalCostOfRevenuePreActuals = 0;
        let ytdGrossMarginActuals = 0;
        let ytdGrossMarginAOP = 0;
        let ytdGrossMarginDiff = 0;
        let ytdGrossMarginPreActuals = 0;
        let ytdGrossMarginPreVarPer;
        let ytdGrossMarginPreVar = 0;
        let ytdOperatingExpensesActualTotal = 0;
        let ytdOperatingExpensesAOPTotal = 0;
        let ytdOperatingExpensesPreActuals = 0;
        let ytdOtherOperatingExpensesActualTotal = 0;
        let ytdOtherOperatingExpensesPreActuals = 0;
        let ytdOtherOperatingExpensesAOPTotal = 0;
        let ytdOtherIncomeTotalActuals = 0;
        let ytdOtherIncomeTotalAOP = 0;
        let ytdNetProfitActuals = 0;
        let ytdNetProfitAOP = 0;
        let ytdNetProfitDiff = 0;
        let ytdOtherExpensesTotalActuals = 0;
        let ytdOtherExpensesTotalPreActuals = 0;
        let ytdNetProfitPreActuals = 0;
        let ytdNetProfitVar = 0;

        let ytdOtherExpensesTotalAOP = 0;
        // Initialize subcategory totals object
        var ytdSubcategoryTotals = {};

        // Process childResults with subcategory structure
        let ytdChildData = {};
        childResults.forEach(childRow => {
            const classification = childRow.classification;
            const parentName = childRow.name;
            const subcategory = childRow.subcategory || parentName; // Default if null

            // Ensure classification level exists
            if (!ytdChildData[classification]) {
                ytdChildData[classification] = {};
                ytdSubcategoryTotals[classification] = {};
            }

            // Ensure parentName level exists within classification
            if (!ytdChildData[classification][parentName]) {
                ytdChildData[classification][parentName] = {};
                ytdSubcategoryTotals[classification][parentName] = {};
            }

            // Ensure subcategory level exists within parentName
            if (!ytdChildData[classification][parentName][subcategory]) {
                ytdChildData[classification][parentName][subcategory] = [];
                ytdSubcategoryTotals[classification][parentName][subcategory] = {
                    actuals: 0,
                    aop: 0,
                    variance: 0,
                    pre_actuals: 0,
                    pre_variance2: 0
                };
            }

            // Add child row to the appropriate subcategory
            ytdChildData[classification][parentName][subcategory].push(childRow);

            // Accumulate totals for the subcategory
            ytdSubcategoryTotals[classification][parentName][subcategory].actuals += Number(childRow.actuals) || 0;
            ytdSubcategoryTotals[classification][parentName][subcategory].aop += Number(childRow.aop) || 0;
            ytdSubcategoryTotals[classification][parentName][subcategory].variance += Number(childRow.variance) || 0;
            ytdSubcategoryTotals[classification][parentName][subcategory].pre_actuals += Number(childRow.pre_actuals) || 0;
            ytdSubcategoryTotals[classification][parentName][subcategory].pre_variance2 += Number(childRow.pre_variance2) || 0;
        });

        // Group parent results by classification
        let ytdGrouped = {};
        log.error("parentResults in ytd",parentResults)
        parentResults.forEach(row => {
            const classification = row.classification;
            if (!ytdGrouped[classification]) {
                ytdGrouped[classification] = [];
            }
            ytdGrouped[classification].push(row);
        });


        var contractedActualsTotal = arrActTotal + ytdnetNewActualsSum;
        var contractedAopTotal = arrAopTotal + ytdnetNewAopSum;
        var contractedVariance = arrDiff + ytdnetNewVarianceSum;
        var contractedVariancePer = (contractedAopTotal !== 0) && (contractedVariance && contractedAopTotal)
            ? ((contractedVariance / contractedAopTotal) * 100).toFixed(1) + '%'
            : 0;
        var firstMonthUpper = firstMonth.toUpperCase();
        var lastMonthUpper = lastMonth.toUpperCase();
       
        var baseYear = parseInt(yearName, 10);
        var monthOrder = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];

        var firstMonthIndex = monthOrder.indexOf(firstMonthUpper);
        var lastMonthIndex = monthOrder.indexOf(lastMonthUpper);
        var startYear = (firstMonthIndex > lastMonthIndex) ? baseYear - 1 : baseYear;
        var endYear = baseYear;
        function twoDigit(year) {
            return year < 10 ? '0' + year : '' + year;
        }

        var startYearStr = twoDigit(startYear);
        var endYearStr = twoDigit(endYear);

        var subsidiaryRec = record.load({
            type: 'customrecord_tyf_subs_hier_',
            id: subsidiary
        })

        let ytdHtml = '';

        var subsidiaryName = subsidiaryRec.getValue({ fieldId: 'name' })
        ytdHtml += `
        <table width="100%" style="page-break-before: auto;"><thead>
    <tr><th colspan="8" style="text-align: center; font-size: 17pt; color: white; background-color: #454444;">${subsidiaryName} - YTD  (${firstMonth} '${startYear} TO ${lastMonth} '${endYearStr})</th></tr>

    <tr>
        <td width="30%">Particulars</td>
        <td width="10%">Actuals</td>
        <td width="10%">AOP</td>
        <td width="10%">Variance</td>
        <td width="10%">Variance (%)</td>
        <td width="10%">Previous Year<br/>Actuals </td>
        <td width="10%">Previous Year<br/>Variance </td>
        <td width="10%">Previous Year<br/>Variance (%) </td>
    </tr></thead>`;
        let parentIndex = 0;
        for (let classification in ytdGrouped) {
            ytdHtml += `
        <tr>
            <td class="classification-section" colspan="8">${classification}</td>
        </tr>`;

            let classificationTotal = {
                actuals: 0,
                aop: 0,
                difference: 0,
                pre_actuals: 0,
                pre_variance: 0
            };

            ytdGrouped[classification].forEach(parentRow => {
                parentIndex++;
                const parentGroup = `ytd_parent_${parentIndex}_subcats`;
                const actuals = Number(parentRow.actuals) || 0;
                const aop = Number(parentRow.aop) || 0;
                const variance = Number(parentRow.variance) || 0;
                const variancePercent = (aop !== 0) ? ((variance / aop) * 100).toFixed(1) : 0;
                const preActuals = Number(parentRow.pre_actuals) || 0;
                const preVariance = Number(parentRow.pre_variance2) || 0;
                const preVariancePer = (preActuals !== 0) ? ((preVariance / preActuals) * 100).toFixed(1) : 0;
                const varianceClass = variance < 0 ? 'negative' : 'positive';
                const subcategories = ytdChildData[classification]?.[parentRow.name];
                const hasSubcategories = subcategories && Object.keys(subcategories).length > 0;

                classificationTotal.actuals += actuals;
                classificationTotal.aop += aop;
                classificationTotal.difference += variance;
                classificationTotal.pre_actuals += preActuals;
                classificationTotal.pre_variance += preVariance;

                ytdHtml += `
            <tr class="parent-row">
                <td width="30%">
                    ${hasSubcategories ? `<button class="toggle-button plus-state" onclick="toggleRows('${parentGroup}', this)">+</button>` : ''}
                    ${parentRow.name}
                </td>
                <td width="10%" class="${Number(actuals) < 0 ? 'negative' : 'positive'}">${Math.round(actuals).toLocaleString()}</td>
                <td width="10%" class="${Number(aop) < 0 ? 'negative' : 'positive'}">${Math.round(aop).toLocaleString()}</td>
                <td width="10%" class="${Number(variance) < 0 ? 'negative' : 'positive'}">${Math.round(variance).toLocaleString()}</td>
                <td width="10%" class="${Number(variancePercent) < 0 ? 'negative' : 'positive'}">${variancePercent} %</td>
                <td width="10%" class="${Number(preActuals) < 0 ? 'negative' : 'positive'}">${Math.round(preActuals).toLocaleString()}</td>
                <td width="10%" class="${Number(preVariance) < 0 ? 'negative' : 'positive'}">${Math.round(preVariance).toLocaleString()}</td>
                <td width="10%" class="${Number(preVariancePer) < 0 ? 'negative' : 'positive'}">${preVariancePer} %</td>
            </tr>`;

                if (hasSubcategories) {
                    let subcatIndex = 0;
                    for (let subcategory in subcategories) {
                        subcatIndex++;
                        const subcatGroup = `ytd_subcat_${parentIndex}_${subcatIndex}_children`;
                        const subcatTotal = ytdSubcategoryTotals[classification][parentRow.name][subcategory];
                        const subcatActuals = subcatTotal.actuals;
                        const subcatAop = subcatTotal.aop;
                        const subcatVariance = subcatTotal.variance;
                        const subcatVariancePercent = (subcatAop !== 0) ? ((subcatVariance / subcatAop) * 100).toFixed(1) : 0;
                        const subcatPreActuals = subcatTotal.pre_actuals;
                        const subcatPreVariance = subcatTotal.pre_variance2;
                        const subcatPreVariancePer = (subcatPreActuals !== 0) ? ((subcatPreVariance / subcatPreActuals) * 100).toFixed(1) : 0;
                        const subcatVarianceClass = subcatVariance < 0 ? 'negative' : 'positive';

                        ytdHtml += `
                    <tr class="subcategory-row" data-group="${parentGroup}" style="display:none;">
                        <td width="30%">
                            <button class="subcategory-toggle plus-state" onclick="toggleRows('${subcatGroup}', this)">+</button>
                            ${subcategory}
                        </td>
                        <td width="10%" class="${Number(subcatActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(subcatAop) < 0 ? 'negative' : 'positive'}">${Math.round(subcatAop).toLocaleString()}</td>
                        <td width="10%" class="${Number(subcatVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatVariance).toLocaleString()}</td>
                        <td width="10%" class="${Number(subcatVariancePercent) < 0 ? 'negative' : 'positive'}">${subcatVariancePercent} %</td>
                        <td width="10%" class="${Number(subcatPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(subcatPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreVariance).toLocaleString()}</td>
                        <td width="10%" class="${Number(subcatPreVariancePer) < 0 ? 'negative' : 'positive'}">${subcatPreVariancePer} %</td>
                    </tr>`;

                        subcategories[subcategory].forEach(child => {
                            const childActuals = Number(child.actuals) || 0;
                            const childAop = Number(child.aop) || 0;
                            const childVariance = Number(child.variance) || 0;
                            const childVariancePercent = (childAop !== 0) ? ((childVariance / childAop) * 100).toFixed(1) : 0;
                            const childVarianceClass = childVariance < 0 ? 'negative' : 'positive';
                            const childPreActuals = Number(child.pre_actuals) || 0;
                            const childPreVariance = Number(child.pre_variance2) || 0;
                            const childPreVariancePer = (childPreActuals !== 0) ? ((childPreVariance / childPreActuals) * 100).toFixed(1) : 0;

                            ytdHtml += `
                        <tr class="child-row" data-group="${subcatGroup}" style="display:none;">
                            <td width="30%">${child.acctnumber}&nbsp;${child.accountsearchdisplaynamecopy}</td>
                            <td width="10%" class="${Number(childActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childActuals).toLocaleString()}</td>
                            <td width="10%" class="${Number(childAop) < 0 ? 'negative' : 'positive'}">${Math.round(childAop).toLocaleString()}</td>
                            <td width="10%" class="${Number(childVariance) < 0 ? 'negative' : 'positive'}">${Math.round(childVariance).toLocaleString()}</td>
                            <td width="10%" class="${Number(childVariancePercent) < 0 ? 'negative' : 'positive'}">${childVariancePercent} %</td>
                            <td width="10%" class="${Number(childPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childPreActuals).toLocaleString()}</td>
                            <td width="10%" class="${Number(childPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(childPreVariance).toLocaleString()}</td>
                            <td width="10%" class="${Number(childPreVariancePer) < 0 ? 'negative' : 'positive'}">${childPreVariancePer} %</td>
                        </tr>`;
                        });
                    }
                }
            });
            if (classification === 'Recurring Revenue' || classification === 'Non Recurring Revenue') {
                ytdTotalOperatingRevenueActuals += classificationTotal.actuals;
                ytdTotalOperatingRevenueAOP += classificationTotal.aop;
                ytdTotalOperatingRevenueDiff += classificationTotal.difference;
                log.debug("adding pre actuals", classificationTotal.pre_actuals);
                log.debug("type of actuals value", typeof classificationTotal.pre_actuals);
                log.debug("individual pre actuals", classificationTotal.pre_actuals);
                ytdTotalOperatingRevenuePreActuals += classificationTotal.pre_actuals // Handle undefined
                ytdTotalOperatingRevenuePreVar += classificationTotal.pre_variance
                ytdTotalOperatingRevenuePreVarPer = (ytdTotalOperatingRevenuePreActuals !== 0) && (ytdTotalOperatingRevenuePreVar && ytdTotalOperatingRevenuePreActuals)
                    ? ((ytdTotalOperatingRevenuePreVar / ytdTotalOperatingRevenuePreActuals) * 100).toFixed(1) + '%'
                    : 0;

                log.debug("accumulated ytdTotalOperatingRevenuePreActuals", ytdTotalOperatingRevenuePreActuals)


            }
            else if (classification === 'Cost of Revenue') {
                log.debug("classification total set before cor", classificationTotal);
                ytdTotalCostOfRevenueActuals = classificationTotal.actuals;
                ytdTotalCostOfRevenueAOP = classificationTotal.aop;
                ytdTotalCostOfRevenuePreActuals = classificationTotal.pre_actuals;
                log.debug("classification total set after cor", classificationTotal);
                ytdGrossMarginActuals = ytdTotalOperatingRevenueActuals - ytdTotalCostOfRevenueActuals;
                ytdGrossMarginAOP = ytdTotalOperatingRevenueAOP - ytdTotalCostOfRevenueAOP;
                ytdGrossMarginDiff = (ytdGrossMarginAOP) - (ytdGrossMarginActuals);
                log.debug("total operating pre actuals", ytdTotalOperatingRevenuePreActuals);
                log.debug("total cost of revenue pre actuals", ytdTotalCostOfRevenuePreActuals);
                ytdGrossMarginPreActuals = ytdTotalOperatingRevenuePreActuals - ytdTotalCostOfRevenuePreActuals;
                ytdGrossMarginPreVar = (ytdGrossMarginPreActuals) - (ytdGrossMarginActuals)

                grossMarginPer = (ytdGrossMarginAOP !== 0) && (ytdGrossMarginDiff && ytdGrossMarginAOP)
                    ? ((ytdGrossMarginDiff / ytdGrossMarginAOP) * 100).toFixed(1)
                    : 0;
                ytdGrossMarginActPer = (ytdTotalOperatingRevenueActuals !== 0) && (ytdGrossMarginActuals && ytdTotalOperatingRevenueActuals)
                    ? ((ytdGrossMarginActuals / ytdTotalOperatingRevenueActuals * 100).toFixed(1))
                    : 0;



                ytdGrossMarginAopPer = (ytdTotalOperatingRevenueAOP !== 0) && (ytdGrossMarginAOP && ytdTotalOperatingRevenueAOP)
                    ? ((ytdGrossMarginAOP / ytdTotalOperatingRevenueAOP * 100).toFixed(1))
                    : 0;

                ytdGrossMarginPerVar = (ytdGrossMarginActPer && ytdGrossMarginAopPer) ? ((ytdGrossMarginActPer) - (ytdGrossMarginAopPer)).toFixed(1) : 0;

                ytdGrossMarginPrePer = (ytdGrossMarginPreActuals !== 0) && (ytdGrossMarginPreVar && ytdGrossMarginPreActuals)
                    ? ((ytdGrossMarginPreVar / ytdGrossMarginPreActuals) * 100).toFixed(1)
                    : 0;

                ytdGrossMarginPrePerAct = (ytdTotalOperatingRevenuePreActuals !== 0) && (ytdGrossMarginPreActuals && ytdTotalOperatingRevenuePreActuals) ? ((ytdGrossMarginPreActuals / ytdTotalOperatingRevenuePreActuals) * 100).toFixed(1) : 0;


                log.debug("ytd gross margin act", ytdGrossMarginActuals)
                log.debug("ytdTotalOperatingRevenueActuals", ytdTotalOperatingRevenueActuals)





            }
            else if (classification === 'OPERATING EXPENSES') {
                log.debug("entered operating expenses", classification)
                ytdOperatingExpensesActualTotal = classificationTotal.actuals;
                ytdOperatingExpensesAOPTotal = classificationTotal.aop;
                ytdOperatingExpensesPreActuals = classificationTotal.pre_actuals;



            }
            else if (classification === 'Other Operating Expenses' || classification === 'Other Operating Expenses ') {
                log.debug("entered other operating expenses", classification)
                ytdOtherOperatingExpensesActualTotal = classificationTotal.actuals;
                ytdOtherOperatingExpensesAOPTotal = classificationTotal.aop;
                ytdOtherOperatingExpensesPreActuals = classificationTotal.pre_actuals;
            }
            else if (classification === 'OTHER INCOME') {
                log.debug("entered other income", classification)
                ytdOtherIncomeTotalActuals = classificationTotal.actuals;
                ytdOtherIncomeTotalAOP = classificationTotal.aop;
                ytdOtherIncomeTotalPreActuals = classificationTotal.pre_actuals; // Update preActuals
                ytdOtherIncomeTotalPreVar = classificationTotal.pre_variance;
                ytdOtherIncomeTotalPreVarPer = (ytdOtherIncomeTotalPreActuals !== 0) && (ytdOtherIncomeTotalPreVar && ytdOtherIncomeTotalPreActuals)
                    ? ((ytdOtherIncomeTotalPreVar / ytdOtherIncomeTotalPreActuals) * 100).toFixed(1) + '%'
                    : 0;

                ytdTotalRevenueActuals = ytdTotalOperatingRevenueActuals + ytdOtherIncomeTotalActuals;
                ytdTotalRevenueAOP = ytdTotalOperatingRevenueAOP + ytdOtherIncomeTotalAOP;
                ytdTotalRevenueDiff = ytdTotalRevenueActuals - ytdTotalRevenueAOP;

                ytdTotalRevenuePreActuals = ytdTotalOperatingRevenuePreActuals + ytdOtherIncomeTotalPreActuals;
                ytdTotalRevenuePreVariance = ytdTotalRevenueActuals - ytdTotalRevenuePreActuals;

                ytdTotalRevenuePreVarPer = (ytdTotalRevenuePreActuals !== 0) && (ytdTotalRevenuePreVariance && ytdTotalRevenuePreActuals) ? ((ytdTotalRevenuePreVariance / ytdTotalRevenuePreActuals) * 100).toFixed(1)
                    : 0;



            }
            const totalVariancePercent = (classificationTotal.aop !== 0) && (classificationTotal.difference && classificationTotal.aop)
                ? ((classificationTotal.difference / classificationTotal.aop) * 100).toFixed(1)
                : 0;
            const varianceClass = classificationTotal.difference < 0 ? 'negative' : 'positive';

            const totalPrevVarPercent = (classificationTotal.pre_actuals !== 0) && (classificationTotal.pre_variance && classificationTotal.pre_actuals)
                ? ((classificationTotal.pre_variance / classificationTotal.pre_actuals) * 100).toFixed(1)
                : 0;
            if (classification === 'Non Recurring Revenue') {

                log.debug("non rec", classification)
                ytdHtml += `<tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
                                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                                <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
            </tr>
                    <tr class="summary-rows">
                        <td>TOTAL OPERATING REVENUE</td>
                        <td class="${Number(ytdTotalOperatingRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalOperatingRevenueActuals).toLocaleString()}</td>
                        <td class="${Number(ytdTotalOperatingRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalOperatingRevenueAOP).toLocaleString()}</td>
                        <td class="${Number(ytdTotalOperatingRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalOperatingRevenueDiff).toLocaleString()}</td>
                        <td class="${Number((ytdTotalOperatingRevenueAOP !== 0) && (ytdTotalOperatingRevenueDiff && ytdTotalOperatingRevenueAOP)
                    ? ((ytdTotalOperatingRevenueDiff / ytdTotalOperatingRevenueAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(ytdTotalOperatingRevenueAOP !== 0) && (ytdTotalOperatingRevenueDiff && ytdTotalOperatingRevenueAOP)
                        ? ((ytdTotalOperatingRevenueDiff / ytdTotalOperatingRevenueAOP * 100).toFixed(1) + '%')
                        : 0}</td>
                                <td class="${Number(ytdTotalOperatingRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalOperatingRevenuePreActuals).toLocaleString()}</td>
                                <td class="${Number(ytdTotalOperatingRevenuePreVar) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalOperatingRevenuePreVar).toLocaleString()}</td>
                                <td class="${Number(ytdTotalOperatingRevenuePreVarPer) < 0 ? 'negative' : 'positive'}">${ytdTotalOperatingRevenuePreVarPer}</td>
                    </tr>`;


            }
            else if (classification === 'OTHER INCOME') {
                ytdHtml += `
                <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
                                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                                <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
            </tr>
                    <tr class="summary-rows">
                        <td>Total Revenue</td>
                        <td class="${Number(ytdTotalRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalRevenueActuals).toLocaleString()}</td>
                        <td class="${Number(ytdTotalRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalRevenueAOP).toLocaleString()}</td>
                        <td class="${Number(ytdTotalRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalRevenueDiff).toLocaleString()}</td>
                        <td class="${Number((ytdTotalRevenueAOP !== 0) && (ytdTotalRevenueDiff && ytdTotalRevenueAOP)
                    ? ((ytdTotalRevenueDiff / ytdTotalRevenueAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(ytdTotalRevenueAOP !== 0) && (ytdTotalRevenueDiff && ytdTotalRevenueAOP)
                        ? ((ytdTotalRevenueDiff / ytdTotalRevenueAOP * 100).toFixed(1) + '%')
                        : 0}</td>
                                <td class="${Number(ytdTotalRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalRevenuePreActuals).toLocaleString()}</td>
                                <td class="${Number(ytdTotalRevenuePreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(ytdTotalRevenuePreVariance).toLocaleString()}</td>
                                <td class="${Number(ytdTotalRevenuePreVarPer) < 0 ? 'negative' : 'positive'}">${ytdTotalRevenuePreVarPer} %</td>
                    </tr>`;
            }
            else if (classification === 'Cost of Revenue') {

                ytdHtml += `
                <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
                                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                                <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
            </tr>
                    <tr class="summary-rows">
                        <td>Gross Margin (excl. other income)</td>
                        <td class="${Number(ytdGrossMarginActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdGrossMarginActuals).toLocaleString()}</td>
                        <td class="${Number(ytdGrossMarginAOP) < 0 ? 'negative' : 'positive'}">${Math.round(ytdGrossMarginAOP).toLocaleString()}</td>
                        <td class="${Number(ytdGrossMarginDiff) < 0 ? 'negative' : 'positive'}">${Math.round(ytdGrossMarginDiff).toLocaleString()}</td>
                        <td class="${Number(grossMarginPer) < 0 ? 'negative' : 'positive'}">${grossMarginPer} %</td>
                        <td class="${Number(ytdGrossMarginPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdGrossMarginPreActuals).toLocaleString()}</td>
                        <td class="${Number(ytdGrossMarginPreVar) < 0 ? 'negative' : 'positive'}">${Math.round(ytdGrossMarginPreVar).toLocaleString()}</td>
                        <td class="${Number(ytdGrossMarginPrePer) < 0 ? 'negative' : 'positive'}">${ytdGrossMarginPrePer} %</td>
                    </tr>
                    <tr class="summary-rows">
                        <td>Gross Margin %</td>
                        <td class="${Number(ytdGrossMarginActPer) < 0 ? 'negative' : 'positive'}">${(ytdGrossMarginActPer)}%</td>
                        <td class="${Number(ytdGrossMarginAopPer) < 0 ? 'negative' : 'positive'}">${(ytdGrossMarginAopPer)}%</td>
                        <td></td>
                        <td class="${Number(ytdGrossMarginPerVar) < 0 ? 'negative' : 'positive'}">${(ytdGrossMarginPerVar)}%</td>
                        <td class="${Number(ytdGrossMarginPrePerAct) < 0 ? 'negative' : 'positive'}">${(ytdGrossMarginPrePerAct)}%</td>
                        <td></td>
                        <td class="${Number((ytdGrossMarginActPer && ytdGrossMarginPrePerAct) ? (Math.round(ytdGrossMarginActPer - ytdGrossMarginPrePerAct).toFixed(1)) : 0) < 0 ? 'negative' : 'positive'}">${(ytdGrossMarginActPer && ytdGrossMarginPrePerAct) ? (Math.round(ytdGrossMarginActPer - ytdGrossMarginPrePerAct).toFixed(1)) : 0}%</td>
                    </tr>`;
            }
            else if (classification === 'Other Operating Expenses' || classification === 'Other Operating Expenses ') {
                const totalOperatingActual = ytdOperatingExpensesActualTotal + ytdOtherOperatingExpensesActualTotal;
                const totalOperatingAOP = ytdOperatingExpensesAOPTotal + ytdOtherOperatingExpensesAOPTotal;
                const totalOperatingDiff = (totalOperatingAOP) - (totalOperatingActual);

                const totalOperatingPreAct = ytdOperatingExpensesPreActuals + ytdOtherOperatingExpensesPreActuals;
                const totalOperatingExpVar = totalOperatingPreAct - totalOperatingActual;
                const totalOperatingExpVarPer = (totalOperatingPreAct !== 0) && (totalOperatingExpVar && totalOperatingPreAct)
                    ? ((totalOperatingExpVar / totalOperatingPreAct * 100).toFixed(1))
                    : 0

                log.debug("totalOperatingExpVarPer", totalOperatingExpVarPer)

                const proFormaEbitaActuals = ytdGrossMarginActuals - totalOperatingActual;
                const proFormaEbitaAOP = ytdGrossMarginAOP - totalOperatingAOP;
                const proFormaEbitaDiff = proFormaEbitaAOP - proFormaEbitaActuals;
                const totalOperatingVarPer = (totalOperatingAOP !== 0) && (totalOperatingDiff && totalOperatingAOP)
                    ? ((totalOperatingDiff / totalOperatingAOP * 100).toFixed(1))
                    : 0





                log.debug("ytdGrossMarginPreActuals", ytdGrossMarginPreActuals)
                log.debug("ytdOperatingExpensesPreActuals", ytdOperatingExpensesPreActuals)

                const proFromaEbitaPreAct = ytdGrossMarginPreActuals - totalOperatingPreAct;
                const proFormaEbitaPreVar = proFormaEbitaActuals - proFromaEbitaPreAct;
                const proFormaEbitaPreVarPer = (proFromaEbitaPreAct !== 0) && (proFormaEbitaPreVar && proFromaEbitaPreAct)
                    ? ((proFormaEbitaPreVar / proFromaEbitaPreAct * 100).toFixed(1))
                    : 0





                const proFormaEbitaPerActuals = (ytdTotalOperatingRevenueActuals !== 0) && (proFormaEbitaActuals && ytdTotalOperatingRevenueActuals)
                    ? ((proFormaEbitaActuals / ytdTotalOperatingRevenueActuals) * 100).toFixed(1)
                    : 0;
                const proFormaEbitaPerAOP = (ytdTotalOperatingRevenueAOP !== 0) && (proFormaEbitaAOP && ytdTotalOperatingRevenueAOP)
                    ? ((proFormaEbitaAOP / ytdTotalOperatingRevenueAOP) * 100).toFixed(1)
                    : 0;

                const proFormaEbitaPerDiff = proFormaEbitaPerAOP - proFormaEbitaPerActuals;

                const proFormaEbitaPrePerAct = (ytdTotalOperatingRevenuePreActuals !== 0) && (proFromaEbitaPreAct && ytdTotalOperatingRevenuePreActuals)
                    ? ((proFromaEbitaPreAct / ytdTotalOperatingRevenuePreActuals) * 100).toFixed(1)
                    : 0;

                const proFormaEbitaVarPer = proFormaEbitaPerActuals - proFormaEbitaPrePerAct;
                ytdHtml += ` <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
                                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                                <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
            </tr>
                    <tr class="summary-rows">
                        <td>TOTAL OPERATING EXPENSES</td>
                        <td class="${Number(totalOperatingActual) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingActual).toLocaleString()}</td>
                        <td class="${Number(totalOperatingAOP) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingAOP).toLocaleString()}</td>
                        <td class="${Number(totalOperatingDiff) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingDiff).toLocaleString()}</td>
                        <td class="${Number(totalOperatingVarPer) < 0 ? 'negative' : 'positive'}">${totalOperatingVarPer}</td>
                        <td class="${Number(totalOperatingPreAct) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingPreAct).toLocaleString()}</td>
                        <td class="${Number(totalOperatingExpVar) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingExpVar).toLocaleString()}</td>
                        <td class="${Number(totalOperatingExpVarPer) < 0 ? 'negative' : 'positive'}">${totalOperatingExpVarPer} % </td>
                    </tr>
                    <tr class="summary-rows">
                        <td>Pro Forma EBITDA</td>
                        <td class="${Number(proFormaEbitaActuals) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaActuals).toLocaleString()}</td>
                        <td class="${Number(proFormaEbitaAOP) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaAOP).toLocaleString()}</td>
                        <td class="${Number(proFormaEbitaDiff) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaDiff).toLocaleString()}</td>
                        <td class="${Number((proFormaEbitaAOP !== 0) && (proFormaEbitaDiff && proFormaEbitaAOP)
                    ? ((proFormaEbitaDiff / proFormaEbitaAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(proFormaEbitaAOP !== 0) && (proFormaEbitaDiff && proFormaEbitaAOP)
                        ? ((proFormaEbitaDiff / proFormaEbitaAOP * 100).toFixed(1) + '%')
                        : 0}</td>
                     <td class="${Number(proFromaEbitaPreAct) < 0 ? 'negative' : 'positive'}">${Math.round(proFromaEbitaPreAct).toLocaleString()}</td>
                        <td class="${Number(proFormaEbitaPreVar) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaPreVar).toLocaleString()}</td>
                        <td class="${Number(proFormaEbitaPreVarPer) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPreVarPer} %</td>
                    </tr>
                    <tr class="summary-rows">
                        <td>Pro Forma EBITDA % </td>
                        <td class="${Number(proFormaEbitaPerActuals) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerActuals} %</td>
                        <td class="${Number(proFormaEbitaPerAOP) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerAOP} %</td>
                        <td></td>
                        <td class="${Number(proFormaEbitaPerDiff ? (proFormaEbitaPerDiff.toFixed(1)) : 0) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerDiff ? (proFormaEbitaPerDiff.toFixed(1)) : 0}%</td>
                        <td class="${Number(proFormaEbitaPrePerAct) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPrePerAct} %</td>
                        <td></td>
                        <td class="${Number(proFormaEbitaVarPer ? (proFormaEbitaVarPer.toFixed(1)) : 0) < 0 ? 'negative' : 'positive'}">${proFormaEbitaVarPer ? (proFormaEbitaVarPer.toFixed(1)) : 0} %</td>
                    </tr>`;


            }
            else if (classification === 'Other expenses') {
                ytdOtherExpensesTotalActuals = classificationTotal.actuals;
                ytdOtherExpensesTotalAOP = classificationTotal.aop;
                ytdOtherExpensesTotalPreActuals = classificationTotal.pre_actuals;

                ytdNetProfitActuals = (ytdGrossMarginActuals + ytdOtherIncomeTotalActuals) -
                    (ytdOperatingExpensesActualTotal + ytdOtherOperatingExpensesActualTotal + ytdOtherExpensesTotalActuals);
                ytdNetProfitAOP = (ytdGrossMarginAOP + ytdOtherIncomeTotalAOP) -
                    (ytdOperatingExpensesAOPTotal + ytdOtherOperatingExpensesAOPTotal + ytdOtherExpensesTotalAOP);
                ytdNetProfitDiff = ytdNetProfitActuals - ytdNetProfitAOP;

                ytdNetProfitPreActuals = (ytdGrossMarginPreActuals + ytdOtherIncomeTotalPreActuals) -
                    (ytdOperatingExpensesPreActuals + ytdOtherOperatingExpensesPreActuals + ytdOtherExpensesTotalPreActuals);

                ytdNetProfitVar = ytdNetProfitActuals - ytdNetProfitPreActuals;
                ytdHtml += `
                <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
                                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                                <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
            </tr>
                    <tr class="summary-rows">
                        <td>NET PROFIT</td>
                        <td class="${Number(ytdNetProfitActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdNetProfitActuals).toLocaleString()}</td>
                        <td class="${Number(ytdNetProfitAOP) < 0 ? 'negative' : 'positive'}">${Math.round(ytdNetProfitAOP).toLocaleString()}</td>
                        <td class="${Number(ytdNetProfitDiff) < 0 ? 'negative' : 'positive'}">${Math.round(ytdNetProfitDiff).toLocaleString()}</td>
                        <td class="${Number((ytdNetProfitAOP !== 0) && (ytdNetProfitDiff && ytdNetProfitAOP)
                    ? ((ytdNetProfitDiff / ytdNetProfitAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(ytdNetProfitAOP !== 0) && (ytdNetProfitDiff && ytdNetProfitAOP)
                        ? ((ytdNetProfitDiff / ytdNetProfitAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(ytdNetProfitPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdNetProfitPreActuals).toLocaleString()}</td>
                        <td class="${Number(ytdNetProfitVar) < 0 ? 'negative' : 'positive'}">${Math.round(ytdNetProfitVar).toLocaleString()}</td>
                        <td class="${Number((ytdNetProfitPreActuals !== 0) && (ytdNetProfitVar && ytdNetProfitPreActuals)
                            ? ((ytdNetProfitVar / ytdNetProfitPreActuals * 100).toFixed(1))
                            : 0) < 0 ? 'negative' : 'positive'}">${(ytdNetProfitPreActuals !== 0) && (ytdNetProfitVar && ytdNetProfitPreActuals)
                                ? ((ytdNetProfitVar / ytdNetProfitPreActuals * 100).toFixed(1) + '%')
                                : '0%'}</td>
                    </tr>
`;
            }
            else if (classification === 'OPERATING EXPENSES') {
                ytdHtml += `
                <tr class="total-row">
                    <td>HEADCOUNT COST</td>
                    <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                    <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                    <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                    <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
                    <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                    <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                    <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
                </tr>`;
            }
            else {
                ytdHtml += `
                <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
                                <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
                                <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
                                <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
            </tr>`;
            }

        }




        ytdHtml += `<tr class="classification-section"><td colspan="8">CONTRACTED ARR ($)</td></tr>
        ${arrPart}
        <tr class="arrtable">
          <td>ARR Net New Bookings (MRR from SF x 12)</td>
          <td class="${Number(ytdnetNewActualsSum) < 0 ? 'negative' : 'positive'}">${Math.round(ytdnetNewActualsSum).toLocaleString()}</td>
          <td class="${Number(ytdnetNewAopSum) < 0 ? 'negative' : 'positive'}">${Math.round(ytdnetNewAopSum).toLocaleString()}</td>
          <td class="${Number(ytdnetNewVarianceSum) < 0 ? 'negative' : 'positive'}">${Math.round(ytdnetNewVarianceSum).toLocaleString()}</td>
          <td class="${Number(ytdnetNewVariancePerSum) < 0 ? 'negative' : 'positive'}">${ytdnetNewVariancePerSum ? (ytdnetNewVariancePerSum.toFixed(1)) + "%" : 0}</td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="total-row">
          <td>Total Contracted ARR</td>
          <td class="${Number(contractedActualsTotal) < 0 ? 'negative' : 'positive'}">${Math.round(contractedActualsTotal).toLocaleString()}</td>
          <td class="${Number(contractedAopTotal) < 0 ? 'negative' : 'positive'}">${Math.round(contractedAopTotal).toLocaleString()}</td>
          <td class="${Number(contractedVariance) < 0 ? 'negative' : 'positive'}">${Math.round(contractedVariance).toLocaleString()}</td>
          <td class="${((contractedActualsTotal - contractedAopTotal) / contractedAopTotal) < 0 ? 'negative' : 'positive'}">
            ${(contractedAopTotal !== 0) && (contractedVariance && contractedAopTotal)
                ? ((contractedActualsTotal - contractedAopTotal) / contractedAopTotal * 100).toFixed(1) + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="classification-section"><td colspan="8">CLIENT DATA (NO.)</td></tr>
        <tr class="client-data">
          <td>New Clients</td>
          <td class="${Number(ytdnewClientsAct) < 0 ? 'negative' : 'positive'}">${ytdnewClientsAct || 0}</td>
          <td class="${Number(ytdnewClientsAop) < 0 ? 'negative' : 'positive'}">${ytdnewClientsAop || 0}</td>
          <td class="${Number(ytdnewClientsAct - ytdnewClientsAop) < 0 ? 'negative' : 'positive'}">${Number(ytdnewClientsAct) - Number(ytdnewClientsAop) || 0}</td>
          <td class="${((ytdnewClientsAct - ytdnewClientsAop) / ytdnewClientsAop) < 0 ? 'negative' : 'positive'}">
            ${(ytdnewClientsAop !== 0) && (ytdnewClientsAct && ytdnewClientsAop)
                ? ((ytdnewClientsAct - ytdnewClientsAop) / ytdnewClientsAop * 100).toFixed(1) + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="client-data">
          <td>Attrition</td>
          <td class="${Number(ytdattritionAct) < 0 ? 'negative' : 'positive'}">${ytdattritionAct || 0}</td>
          <td class="${Number(ytdattritionAop) < 0 ? 'negative' : 'positive'}">${ytdattritionAop || 0}</td>
          <td class="${Number(ytdattritionAct - ytdattritionAop) < 0 ? 'negative' : 'positive'}">${Number(ytdattritionAct) - Number(ytdattritionAop) || 0}</td>
          <td class="${((ytdattritionAct - ytdattritionAop) / ytdattritionAop) < 0 ? 'negative' : 'positive'}">
            ${(ytdattritionAop !== 0) && (ytdattritionAct && ytdattritionAop)
                ? ((ytdattritionAct - ytdattritionAop) / ytdattritionAop * 100).toFixed(1) + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="client-data">
          <td>Existing</td>
          <td class="${Number(ytdexistingAct) < 0 ? 'negative' : 'positive'}">${ytdexistingAct || 0}</td>
          <td class="${Number(ytdexistingAop) < 0 ? 'negative' : 'positive'}">${ytdexistingAop || 0}</td>
          <td class="${Number(ytdexistingAct - ytdexistingAop) < 0 ? 'negative' : 'positive'}">${Number(ytdexistingAct) - Number(ytdexistingAop) || 0}</td>
          <td class="${((ytdexistingAct - ytdexistingAop) / ytdexistingAop) < 0 ? 'negative' : 'positive'}">
            ${(ytdexistingAop !== 0) && (ytdexistingAct && ytdexistingAop)
                ? ((ytdexistingAct - ytdexistingAop) / ytdexistingAop * 100).toFixed(1) + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="total-row">
          <td>Total Clients</td>
          <td class="${Number(ytdtotalClientsAct) < 0 ? 'negative' : 'positive'}">${ytdtotalClientsAct || 0}</td>
          <td class="${Number(ytdtotalClientsAop) < 0 ? 'negative' : 'positive'}">${ytdtotalClientsAop || 0}</td>
          <td class="${Number(ytdtotalClientsAct - ytdtotalClientsAop) < 0 ? 'negative' : 'positive'}">${Number(ytdtotalClientsAct) - Number(ytdtotalClientsAop) || 0}</td>
          <td class="${((ytdtotalClientsAct - ytdtotalClientsAop) / ytdtotalClientsAop) < 0 ? 'negative' : 'positive'}">
            ${(ytdtotalClientsAop !== 0) && (ytdtotalClientsAct && ytdtotalClientsAop)
                ? ((ytdtotalClientsAct - ytdtotalClientsAop) / ytdtotalClientsAop * 100).toFixed(1) + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="classification-section"><td colspan="8">HEADCOUNT (NO.)</td></tr>
        <tr class="parent-row">
          <td>Sales and Marketing</td>
          <td class="${Number(ytdsalesAndMarketingActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdsalesAndMarketingActuals).toLocaleString()}</td>
          <td class="${Number(ytdsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdsalesAndMarketingAop).toLocaleString()}</td>
          <td class="${Number(ytdsalesAndMarketingActuals - ytdsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdsalesAndMarketingActuals - ytdsalesAndMarketingAop).toLocaleString()}</td>
          <td class="${((ytdsalesAndMarketingActuals - ytdsalesAndMarketingAop) / ytdsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">
            ${ytdsalesAndMarketingAop !== 0
                ? (Math.round(((ytdsalesAndMarketingActuals - ytdsalesAndMarketingAop) / ytdsalesAndMarketingAop * 100) * 10) / 10).toLocaleString() + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="parent-row">
          <td>Product</td>
          <td class="${Number(ytdproductActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdproductActuals).toLocaleString()}</td>
          <td class="${Number(ytdproductAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdproductAop).toLocaleString()}</td>
          <td class="${Number(ytdproductActuals - ytdproductAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdproductActuals - ytdproductAop).toLocaleString()}</td>
          <td class="${((ytdproductActuals - ytdproductAop) / ytdproductAop) < 0 ? 'negative' : 'positive'}">
            ${ytdproductAop !== 0
                ? (Math.round(((ytdproductActuals - ytdproductAop) / ytdproductAop * 100) * 10) / 10).toLocaleString() + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="parent-row">
          <td>General &amp; Administrative</td>
          <td class="${Number(ytdgeneraladminActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdgeneraladminActuals).toLocaleString()}</td>
          <td class="${Number(ytdgeneralAdminAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdgeneralAdminAop).toLocaleString()}</td>
          <td class="${Number(ytdgeneraladminActuals - ytdgeneralAdminAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdgeneraladminActuals - ytdgeneralAdminAop).toLocaleString()}</td>
          <td class="${((ytdgeneraladminActuals - ytdgeneralAdminAop) / ytdgeneralAdminAop) < 0 ? 'negative' : 'positive'}">
            ${ytdgeneralAdminAop !== 0
                ? (Math.round(((ytdgeneraladminActuals - ytdgeneralAdminAop) / ytdgeneralAdminAop * 100) * 10) / 10).toLocaleString() + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="parent-row">
          <td>Customer Success</td>
          <td class="${Number(ytdcustomersuccessActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdcustomersuccessActuals).toLocaleString()}</td>
          <td class="${Number(ytdcustomersuccessAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdcustomersuccessAop).toLocaleString()}</td>
          <td class="${Number(ytdcustomersuccessActuals - ytdcustomersuccessAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdcustomersuccessActuals - ytdcustomersuccessAop).toLocaleString()}</td>
          <td class="${((ytdcustomersuccessActuals - ytdcustomersuccessAop) / ytdcustomersuccessAop) < 0 ? 'negative' : 'positive'}">
            ${ytdcustomersuccessAop !== 0
                ? (Math.round(((ytdcustomersuccessActuals - ytdcustomersuccessAop) / ytdcustomersuccessAop * 100) * 10) / 10).toLocaleString() + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="parent-row">
          <td>R &amp; D</td>
          <td class="${Number(ytdranddActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdranddActuals).toLocaleString()}</td>
          <td class="${Number(ytdranddAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdranddAop).toLocaleString()}</td>
          <td class="${Number(ytdranddActuals - ytdranddAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdranddActuals - ytdranddAop).toLocaleString()}</td>
          <td class="${((ytdranddActuals - ytdranddAop) / ytdranddAop) < 0 ? 'negative' : 'positive'}">
            ${ytdranddAop !== 0
                ? (Math.round(((ytdranddActuals - ytdranddAop) / ytdranddAop * 100) * 10) / 10).toLocaleString() + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        <tr class="total-row">
          <td>HeadCount Total </td>
          <td class="${Number(ytdheadcounttotalActuals) < 0 ? 'negative' : 'positive'}">${Math.round(ytdheadcounttotalActuals).toLocaleString()}</td>
          <td class="${Number(ytdheadcounttotalAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdheadcounttotalAop).toLocaleString()}</td>
          <td class="${Number(ytdheadcounttotalActuals - ytdheadcounttotalAop) < 0 ? 'negative' : 'positive'}">${Math.round(ytdheadcounttotalActuals - ytdheadcounttotalAop).toLocaleString()}</td>
          <td class="${((ytdheadcounttotalActuals - ytdheadcounttotalAop) / ytdheadcounttotalAop) < 0 ? 'negative' : 'positive'}">
            ${ytdheadcounttotalAop !== 0
                ? (Math.round(((ytdheadcounttotalActuals - ytdheadcounttotalAop) / ytdheadcounttotalAop * 100) * 10) / 10).toLocaleString() + '%'
                : 0}
          </td>
          <td></td><td></td><td></td>
        </tr>
        </table>`

        var ytdTablesOnlyHtml = ytdHtml

        tableHtml += ytdHtml


        log.error("ytd html before saving",ytdHtml)

        var ytdClosurePart = `<script>
                    function printPDF() { window.print(); }
    let isExpanded = false;
    function toggleAllRows() {
        const allRows = document.querySelectorAll('[data-group]');
        allRows.forEach(row => {
            if (isExpanded) {
                row.style.display = 'none';
            } else {
                row.style.display = 'table-row';
            }
        });
        const buttons = document.querySelectorAll('.toggle-button, .subcategory-toggle');
        console.log('Toggle All: Found', buttons.length, 'buttons'); // Debug log
        buttons.forEach(button => {
            button.textContent = isExpanded ? '+' : '-';
            button.classList.toggle('plus-state', button.textContent === '+');
        });
        isExpanded = !isExpanded;
        document.getElementById('toggleAllBtn').title = isExpanded ? "Collapse All" : "Expand All";
        document.getElementById('toggleAllBtn').textContent = isExpanded ? '+' : '-';
    }
    function toggleRows(group, btn) {
        const rows = document.querySelectorAll('[data-group="' + group + '"]');
        console.log('Toggle Rows: Group', group, 'Found', rows.length, 'rows'); // Debug log
        const isVisible = rows.length > 0 && rows[0].style.display === 'table-row';
        rows.forEach(row => {
            row.style.display = isVisible ? 'none' : 'table-row';
        });
        btn.textContent = isVisible ? '+' : '-';
        btn.classList.toggle('plus-state', btn.textContent === '+');
        console.log('Button classes:', btn.className); // Debug log
    }
</script></body></html>`;
var monthAndYear=getMonthAndYear(accountingPeriod).toString()

        tableHtml += ytdClosurePart
        var htmlFile = file.create({
            name: 'ytdReport' + subsidiaryName + '_' + monthAndYear+ '.html',         // file name
            fileType: file.Type.HTMLDOC, // saves as HTML
            contents: tableHtml,       // your HTML string
            folder: 11899             // Internal ID of target folder in File Cabinet
        });

        var ytdTablesOnlyFile = file.create({
            name: 'ytdTable' + subsidiaryName + '_' + monthAndYear + '.txt',         // file name
            fileType: file.Type.PLAINTEXT, // saves as HTML
            contents: ytdTablesOnlyHtml,       // your HTML string
            folder: 8539             // Internal ID of target folder in File Cabinet
        });

        // Save file in File Cabinet
        var fileId = htmlFile.save();
        var ytdTablesOnlyFileId = ytdTablesOnlyFile.save();
        return { fileId: fileId, ytdTablesOnlyFileId: ytdTablesOnlyFileId };


     }
     catch(e){
        log.error("error in ytd function, rescheduling process...",e)
        
     }
} 


function getMonthAndYear(accountingPeriod){
    var accountingperiodSearchObj = search.create({
   type: "accountingperiod",
   filters:
   [
      ["internalid","anyof", accountingPeriod]
   ],
   columns:
   [
      search.createColumn({name: "periodname", label: "Name"}),
      search.createColumn({name: "parent", label: "Parent"})
   ]
});
var searchResultCount = accountingperiodSearchObj.runPaged().count;
log.debug("accountingperiodSearchObj result count",searchResultCount);
var monthYear;
accountingperiodSearchObj.run().each(function(result){
   monthYear=result.getValue({name: "periodname"})
   return false
});
return monthYear;
}

    function generateFullYearReport(parentResultsFull, childResultsFull, stagingTableId, subsidiaryChildPlaceHolders, subsidiaryIds, accountingPeriod, subsidiary, aprilId, tableHtml, yearName, arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer, monthNumber) {

        try{
            yearName = getYearName(accountingPeriod)
 log.debug("main full year function, units left", runtime.getCurrentScript().getRemainingUsage())
                             log.debug("full year report year name",yearName)


            
        var fullYMappedResults;
        var financialYearMonthsFullYFunction = getFinancialYearMonthsFullYear(accountingPeriod);

        var parentResults = parentResultsFull
        var childResults = childResultsFull



    

        var financialYearMonthsFullY = financialYearMonthsFullYFunction.monthIds;
        var financialYearName = financialYearMonthsFullYFunction.financialYearName;

        // var fullYMonthNumbers = getMonthNumbersFromPeriods(financialYearMonthsFullY);
        // log.debug("fullY month numbers", fullYMonthNumbers)
        // var fullYPlaceHolders = fullYMonthNumbers.map(() => '?').join(',');


        // Convert to string array
        var stringArray = [];


        for (var i = 0; i < financialYearMonthsFullY.length; i++) {
            stringArray.push(financialYearMonthsFullY[i].toString());
        }

        var periodPlaceholders = stringArray.map(() => '?').join(',');



        var previousMonthsPlaceHolders;

        var previousYearsMonths = getPreviousYearAccountingPeriods(stringArray);
        if (previousYearsMonths) {
            previousMonthsPlaceHolders = previousYearsMonths.map(() => '?').join(',');

        }




        var monthIdArray = [];
        monthIdArray.push(monthNumber);

        log.debug("month number", monthNumber)
        log.debug("month name", monthName)


        var clientParams = [
            ...stringArray,
            ...subsidiaryIds
        ]

        // var fullYNetNewBookings = (fullYNetResults[0].total || 0)
        var fullYClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;`
let fullYClientResults;
 if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         fullYClientResults = query.runSuiteQL({
            query: fullYClientQuery,
            params: clientParams
        }).asMappedResults();

    }
    else{
        fullYClientResults=[]
    }







        let fullYnewClientsAop = 0
        let fullYattritionAop = 0
        let fullYexistingAop = 0
        let fullYexistingAct = 0;
        let fullYattritionAct = 0;
        let fullYnewClientsAct = 0;

        let fullYtotalClientsAct = 0
        let fullYtotalClientsAop = 0


        let fullYaprilExistingClientsQuery = `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    -- AOP data from budgets
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary

    UNION ALL

    -- Actuals data from custom record
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;
`
        let arrNetQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  -- Budget data
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Custom record data
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
 z.period in (${periodPlaceholders}) and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;`

let fullYaprilExistingClientsQueryResults;
if(aprilId!=null && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0)){

         fullYaprilExistingClientsQueryResults = query.runSuiteQL({
            query: fullYaprilExistingClientsQuery,
            params: [aprilId, ...subsidiaryIds]
        }).asMappedResults();

    }
    else{
        fullYaprilExistingClientsQueryResults=[]
    }
if(fullYClientResults.length>0){

        fullYClientResults.forEach(row => {
            fullYnewClientsAct += Number(row.newclient_actuals1) || 0;

            fullYattritionAct += Number(row.attrition_actuals1) || 0;



            fullYnewClientsAop += Number(row.newclients_aop1) || 0;


            fullYattritionAop += Number(row.attrition_aop1) || 0;


        });

    }


if(fullYaprilExistingClientsQueryResults.length>0){
        fullYaprilExistingClientsQueryResults.forEach(row => {
            fullYexistingAct += Number(row.existing_actuals1)
            fullYexistingAop += Number(row.existing_aop1)

        })

        fullYtotalClientsAct = fullYnewClientsAct + fullYattritionAct + fullYexistingAct
        fullYtotalClientsAop = fullYnewClientsAop + fullYattritionAop + fullYexistingAop

    }
        var fullYsalesAndMarketing = 0;
        var fullYproduct = 0;
        var fullYgeneraladmin = 0;
        var fullYcustomersuccess = 0;
        var fullYrandd = 0;
        var fullYprofservices = 0;

        var fullYheadCountQuery = `SELECT 
  period,  
  SUM(z.SM_HC_aop) AS SM_HC_aop1, 
  SUM(z.Product_HC_aop) AS Product_HC_aop1, 
  SUM(z.GA_HC_AOP) AS GA_HC_AOP1,
  SUM(z.Cs_hc_aop) AS Cs_hc_aop1, 
  SUM(z.rd_hc_aop) AS rd_hc_aop1,
  SUM(z.pso_hc_aop) AS pso_hc_aop1,
  SUM(z.salesandmarketting) AS salesandmarketting, 
  SUM(z.product) AS product1,
  SUM(z.generaladmin) AS generaladmin1,
  SUM(z.customersuccess) AS customersuccess1,
  SUM(z.randd) AS randd1,
  SUM(z.profservices) AS profservices1
FROM (

  -- SM_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    SUM(bm.amount) AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2301
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Product_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    SUM(bm.amount) AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2302
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- GA_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    SUM(bm.amount) AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2303
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- CS_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    SUM(bm.amount) AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2304
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- R&D
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    SUM(bm.amount) AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2305
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- PSO
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    SUM(bm.amount) AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2306
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from Custom Record
  SELECT  
    custrecord1 AS period,
    custrecord_tyfone_subsidiary_dashboard2 AS subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    custrecord_ty_headcount_sal_mar AS salesandmarketting, 
    custrecord_ty_headcount_product_report AS product, 
    custrecord_ty_headcount_generaladmin AS generaladmin, 
    custrecord_ty_headcount_cust_success_ AS customersuccess, 
    custrecord_ty_headcount_rd_report AS randd, 
    custrecord_ty_headcount_profser_report AS profservices
  FROM CUSTOMRECORD_TYFONE_HEADCOUNT_REPORT

) z
WHERE 
  z.period = ?
  AND z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period;`
        let fullYsalesAndMarketingActuals, fullYproductActuals, fullYgeneraladminActuals, fullYcustomersuccessActuals, fullYranddActuals, fullYprofservicesActuals,
            fullYheadcounttotalActuals, fullYsalesAndMarketingAop, fullYproductAop, fullYgeneralAdminAop, fullYcustomersuccessAop, fullYranddAop, fullYprofservicesAop, fullYheadcounttotalAop;

        var fullYheadCountResults;
        if(accountingPeriod!=null && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0)){
        fullYheadCountResults = query.runSuiteQL({ query: fullYheadCountQuery, params: [accountingPeriod, ...subsidiaryIds] }).asMappedResults();
        }
        else{
            fullYheadCountResults=[]
        }

        fullYheadCountResults.forEach(row => {
            fullYsalesAndMarketingActuals = Number(row.salesandmarketting) || 0;
            fullYproductActuals = Number(row.product1) || 0;
            fullYgeneraladminActuals = Number(row.generaladmin1) || 0;
            fullYcustomersuccessActuals = Number(row.customersuccess1) || 0;
            fullYranddActuals = Number(row.randd1) || 0;
            fullYprofservicesActuals = Number(row.profservices1) || 0;

            fullYheadcounttotalActuals = fullYsalesAndMarketingActuals + fullYproductActuals + fullYgeneraladminActuals + fullYcustomersuccessActuals + fullYranddActuals


            fullYsalesAndMarketingAop = Number(row.sm_hc_aop1) || 0;
            fullYproductAop = Number(row.product_hc_aop1) || 0;
            fullYgeneralAdminAop = Number(row.ga_hc_aop1) || 0;
            fullYcustomersuccessAop = Number(row.cs_hc_aop1) || 0;
            fullYranddAop = Number(row.rd_hc_aop1) || 0;
            fullYprofservicesAop = Number(row.rd_hc_aop1) || 0;

            fullYheadcounttotalAop = fullYsalesAndMarketingAop + fullYproductAop + fullYgeneralAdminAop + fullYcustomersuccessAop + fullYranddAop

        });

        var stringArray = [];
        var replicatingArray = []
        for (var i = 0; i < financialYearMonthsFullY.length; i++) {
            stringArray.push(financialYearMonthsFullY[i].toString());
        }
        periodPlaceholders = stringArray.map(() => '?').join(',');
        log.debug("period placeholders", periodPlaceholders)
        for (var k = 0; k < stringArray.length; k++) {
            replicatingArray.push(stringArray[k]);
        }
        replicatingArray = replicatingArray.concat(replicatingArray)  //since we have to use same parameter twice in single query , creating duplication of values inside same array using self concatenation.




        var queryParams = [];



        var fullYNetNewQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  -- Budget data
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Custom record data
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
 z.period in (${periodPlaceholders}) and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;`

        var fullYNetResults;
         if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         fullYNetResults = query.runSuiteQL({ query: fullYNetNewQuery, params: clientParams }).asMappedResults();

        }
        else
        {
           fullYNetResults=[] 
        }
        let fullYnetNewAop = 0;
        let fullYnetNewActuals = 0;
        let fullYnetNewVariance = 0;
        let fullYnetNewVariancePer = 0
        let fullYnetNewActualsSum = 0;
        let fullYnetNewAopSum = 0;
        let fullYnetNewVarianceSum = 0;
        let fullYnetNewVariancePerSum = 0;


        fullYNetResults.forEach(row => {
            fullYnetNewAop = row.arr_netnew_aop1;
            fullYnetNewActuals = row.arr_netnew_actuals1;
            fullYnetNewVariance = fullYnetNewActuals - fullYnetNewAop;
            fullYnetNewVariancePer = (fullYnetNewVariance / fullYnetNewAop) * 100

            fullYnetNewActualsSum += fullYnetNewActuals;
            fullYnetNewAopSum += fullYnetNewAop;
            fullYnetNewVarianceSum += fullYnetNewVariance;
            fullYnetNewVariancePerSum += fullYnetNewVariancePer;


        })



        var fullYearQueryParent = ``
        var fullYearQueryChild = ``
        var monthPlaceHolders = monthIdArray.map(() => '?').join(',');


        log.debug({
            title: 'Remaining Usage',
            details: 'Remaining governance units before running final query: ' + runtime.getCurrentScript().getRemainingUsage()
        });


        let queryParameters = []
        var budgetId = getBudgetId(monthNumber)
        log.debug("budget id", budgetId)
        // stringArray = stringArray.map(Number);
        // stringArray = stringArray.toString();
        log.debug("stringArray Full Year", stringArray)
        // previousYearsMonths = previousYearsMonths.map(Number);
        // previousYearsMonths = previousYearsMonths.toString();
        log.debug("previousYearsMonths Full Year", previousYearsMonths)
        subsidiaryIds = subsidiaryIds.map(Number);
        log.debug("subsidiaryIds", subsidiaryIds)
      





        // // === Parent Aggregation ===
        // let aggregatedParent = {};

        // parentResults.forEach(row => {
        //     try {
        //         const classification = (row.classification || '').trim().toUpperCase(); // normalize
        //         const key = (row.id || '') + '|' + classification + '|' + (row.name || ''); // include name

        //         if (!aggregatedParent[key]) {
        //             aggregatedParent[key] = {
        //                 id: row.id || '',
        //                 classification: classification,
        //                 name: row.name || '',
        //                 subcategory: row.subcategory || '',
        //                 actuals: Number(row.actuals) || 0,
        //                 aop: Number(row.aop) || 0,
        //                 variance: Number(row.variance) || 0,
        //                 pre_actuals: Number(row.pre_actuals || row.pre_actuals) || 0,
        //                 pre_actuals: Number(row.pre_actuals || row.pre_actuals) || 0,
        //                 pre_variance2: Number(row.pre_variance2) || 0,
        //                 custrecord_dashboard_classification: row.custrecord_dashboard_classification || ''
        //             };
        //         } else {
        //             aggregatedParent[key].actuals += Number(row.actuals) || 0;
        //             aggregatedParent[key].aop += Number(row.aop) || 0;
        //             aggregatedParent[key].variance += Number(row.variance) || 0;
        //             aggregatedParent[key].pre_actuals += Number(row.pre_actuals || row.pre_actuals) || 0;
        //             aggregatedParent[key].pre_actuals += Number(row.pre_actuals || row.pre_actuals) || 0;
        //             aggregatedParent[key].pre_variance2 += Number(row.pre_variance2) || 0;
        //         }
        //     } catch (err) {
        //         log.error('Parent Aggregation error', JSON.stringify({ row, err }));
        //     }
        // });

        // parentResults = Object.values(aggregatedParent);
        // log.debug("after aggregation parent results",parentResults)


        // // === Child Aggregation ===
        // let aggregatedChild = {};

        // childResults.forEach(row => {
        //     try {
        //         const classification = (row.classification || '').trim().toUpperCase(); // normalize
        //         const key = (row.id || '') + '|' + classification + '|' +
        //                     (row.acctnumber || '') + '|' +
        //                     (row.accountsearchdisplaynamecopy || '') + '|' +
        //                     (row.subcategory || '');

        //         if (!aggregatedChild[key]) {
        //             aggregatedChild[key] = {
        //                 id: row.id || '',
        //                 classification: classification,
        //                 name: row.name || '',
        //                 accountsearchdisplaynamecopy: row.accountsearchdisplaynamecopy || '',
        //                 subcategory: row.subcategory || '',
        //                 acctnumber: row.acctnumber || '',
        //                 actuals: Number(row.actuals) || 0,
        //                 aop: Number(row.aop) || 0,
        //                 variance: Number(row.variance) || 0,
        //                 pre_actuals: Number(row.pre_actuals || row.pre_actuals) || 0,
        //                 pre_actuals: Number(row.pre_actuals || row.pre_actuals) || 0,
        //                 pre_variance2: Number(row.pre_variance2) || 0,
        //                 custrecord_dashboard_classification: row.custrecord_dashboard_classification || ''
        //             };
        //         } else {
        //             aggregatedChild[key].actuals += Number(row.actuals) || 0;
        //             aggregatedChild[key].aop += Number(row.aop) || 0;
        //             aggregatedChild[key].variance += Number(row.variance) || 0;
        //             aggregatedChild[key].pre_actuals += Number(row.pre_actuals || row.pre_actuals) || 0;
        //             aggregatedChild[key].pre_actuals += Number(row.pre_actuals || row.pre_actuals) || 0;
        //             aggregatedChild[key].pre_variance2 += Number(row.pre_variance2) || 0;
        //         }
        //     } catch (err) {
        //         log.error('Child Aggregation error', JSON.stringify({ row, err }));
        //     }
        // });




        // childResults = Object.values(aggregatedChild);

        // log.debug("after aggregation child results",childResults)





        // Initialize Full Year totals
        let fullYTotalOperatingRevenueActuals = 0;
        let fullYTotalOperatingRevenueAOP = 0;
        let fullYTotalOperatingRevenueDiff = 0;
        let fullYTotalOperatingRevenuePreActuals = 0;
        let fullYTotalOperatingRevenuePreVariance = 0;
        let fullYTotalOperatingRevenuePreVariancePercent;
        let fullYGrossMarginPreActuals = 0;
        let fullYGrossMarginPreVariance = 0;
        let fullYGrossMarginPreVariancePercent;
        let fullYTotalRevenueActuals = 0;
        let fullYTotalRevenueAOP = 0;
        let fullYTotalRevenueDiff = 0;
        let fullYTotalCostOfRevenueActuals = 0;
        let fullYTotalCostOfRevenueAOP = 0;
        let fullYTotalCostOfRevenuePreActuals = 0;
        let fullYGrossMarginActuals = 0;
        let fullYGrossMarginAOP = 0;
        let grossPerAct = 0;
        let grossPerAOP = 0;
        let grossPerVar = 0;
        let grossPrePerAct = 0;



        let fullYGrossMarginDiff = 0;
        let fullYOperatingExpensesActualTotal = 0;
        let fullYOperatingExpensesAOPTotal = 0;
        let fullYOperatingExpensesPreActuals = 0;
        let fullYOperatingExpensesPreVariance = 0;
        let fullYOtherOperatingExpensesActualTotal = 0;
        let fullYOtherOperatingExpensesAOPTotal = 0;
        let fullYOtherIncomeTotalActuals = 0;
        let fullYOtherIncomeTotalPreActuals = 0;
        let fullYTotalRevenuePreActuals = 0;
        let fullYTotalRevenueVariance = 0;
        let fullYOtherIncomeTotalVariance = 0;
        let fullYOtherIncomeTotalAOP = 0;
        let fullYNetProfitActuals = 0;
        let fullYNetProfitAOP = 0;
        let fullYNetProfitDiff = 0;
        let fullYOtherExpensesTotalActuals = 0;
        let fullYOtherExpensesTotalAOP = 0;

        let fullYChildData = {};
        let fullYSubcategoryTotals = {};

        childResults.forEach(childRow => {
            const classification = childRow.classification.trim();
            const parentName = childRow.name;
            const subcategory = childRow.subcategory || parentName; // Handle null subcategories

            // Ensure nested structure exists
            if (!fullYChildData[classification]) {
                fullYChildData[classification] = {};
                fullYSubcategoryTotals[classification] = {};
            }
            if (!fullYChildData[classification][parentName]) {
                fullYChildData[classification][parentName] = {};
                fullYSubcategoryTotals[classification][parentName] = {};
            }
            if (!fullYChildData[classification][parentName][subcategory]) {
                fullYChildData[classification][parentName][subcategory] = [];
                fullYSubcategoryTotals[classification][parentName][subcategory] = {
                    actuals: 0,
                    aop: 0,
                    variance: 0,
                    pre_actuals: 0,
                    pre_variance2: 0
                };
            }

            // Add child row to the appropriate subcategory
            fullYChildData[classification][parentName][subcategory].push(childRow);

            // Accumulate subcategory totals
            fullYSubcategoryTotals[classification][parentName][subcategory].actuals += Number(childRow.actuals) || 0;
            fullYSubcategoryTotals[classification][parentName][subcategory].aop += Number(childRow.aop) || 0;
            fullYSubcategoryTotals[classification][parentName][subcategory].variance += Number(childRow.variance) || 0;
            fullYSubcategoryTotals[classification][parentName][subcategory].pre_actuals += Number(childRow.pre_actuals) || 0;
            fullYSubcategoryTotals[classification][parentName][subcategory].pre_variance2 += Number(childRow.pre_variance2) || 0;
        });

        // Group parent data
        let fullYGrouped = {};

        let nfinia = {}
        let nfiniaThree = {}


        parentResults.forEach(row => {
            const classification = row.classification.trim(); // Add trim()
            if (!fullYGrouped[classification]) fullYGrouped[classification] = [];
            if (row.classification.trim() == 'Non Recurring Revenue') {
                if (!nfinia[classification]) nfinia[classification] = [];
                nfinia[classification].push(row);

            }
            else if ((row.name.trim() == '3rd Party (nfinia)')) {
                if (!nfiniaThree[classification]) nfiniaThree[classification] = [];
                nfiniaThree[classification].push(row);

            }

            fullYGrouped[classification].push(row);
        });


        // var arrActualsSum=fullYNetNewBookings+arrActTotal

        var contractedActualsTotal = parseInt(arrActTotal) + parseInt(fullYnetNewActualsSum);
        var contractedAopTotal = parseInt(arrAopTotal) + parseInt(fullYnetNewAopSum);
        var contractedVariance = parseInt(contractedActualsTotal) - parseInt(contractedAopTotal);
        var contractedVariancePer = (arrPer && fullYnetNewVariancePerSum) ? (Number(arrPer) + Number(fullYnetNewVariancePerSum)).toFixed(1) + '%' : "0%";

        var monthNumber = null;
var monthName = null;

if (accountingPeriod) {
    monthNumber = getMonthNumber(accountingPeriod);
    log.debug("month number at full year",monthNumber)
}

if (monthNumber !== null) {
    monthName = getMonthName(accountingPeriod);
     log.debug("month name at full year",monthName)
}
        var subsidiaryRec = record.load({
            type: 'customrecord_tyf_subs_hier_',
            id: subsidiary
        })

        var subsidiaryName = subsidiaryRec.getValue({ fieldId: 'name' })

        let fullYHtml = ''

        // Build HTML
        fullYHtml += `
        <table width="100%" style="page-break-before: auto;"><thead>
    <tr><th colspan="8" style="text-align: center; font-size: 17pt; color: white; background-color: #454444;">${subsidiaryName} - Full Year (${monthName} ' ${yearName}) </th></tr>

    <tr>
        <td width="30%">Particulars</th>
        <td width="10%">Actuals</th>
        <td width="10%">AOP</th>
        <td width="10%">Variance</th>
        <td width="10%">Variance (%)</th>
        <td width="10%">Previous Year<br/>Actuals </th>
        <td width="10%">Previous Year<br/>Variance </th>
        <td width="10%">Previous Year<br/>Variance (%) </th>
    </tr></thead>`;

        // Process each classification
        for (let classification in fullYGrouped) {
            // Classification header
            fullYHtml += `
                <tr>
                    <td class="classification-section" colspan="8">${classification}</td>
                </tr>`;

            let classificationTotal = {
                actuals: 0,
                aop: 0,
                difference: 0,
                pre_actuals: 0,
                pre_variance: 0
            };
            try {
                classification = classification.trim()
                // Process parent rows
                fullYGrouped[classification].forEach((parentRow, parentIdx) => {
                    log.debug("fullYGrouped", fullYGrouped)
                    log.debug("fullYGrouped content", JSON.stringify(fullYGrouped[classification]));
                    log.debug("classification parent row", classification);
                    const parentIndex = parentIdx + 1; // Unique index for each parent row
                    const parentGroup = `fullY_parent_${parentIndex}_subcats`; // Unique group ID for subcategories
                    const actuals = Number(parentRow.actuals) || 0;
                    const aop = Number(parentRow.aop) || 0;
                    const variance = Number(parentRow.variance) || 0;
                    const variancePercent = (aop !== 0) ? ((variance / aop) * 100).toFixed(1) : 0;
                    const preActuals = Number(parentRow.pre_actuals) || 0;
                    const preVariance = Number(parentRow.pre_variance2) || 0;
                    const preVariancePercent = (preActuals !== 0) ? ((preVariance / preActuals) * 100).toFixed(1) : 0;
                    const varianceClass = variance < 0 ? 'negative' : 'positive';
                    const subcategories = fullYChildData[classification]?.[parentRow.name];
                    const hasSubcategories = subcategories && Object.keys(subcategories).length > 0;

                    // Update classification totals
                    classificationTotal.actuals += actuals;

                    classificationTotal.aop += aop;
                    classificationTotal.difference += variance;
                    classificationTotal.pre_actuals += preActuals;
                    classificationTotal.pre_variance += preVariance;
                    log.debug("classification total actuals", classificationTotal.actuals)

                    // Parent row with toggle button if subcategories exist
                    fullYHtml += `
        <tr class="parent-row">
            <td width="30%">
                ${hasSubcategories ? `<button class="toggle-button" onclick="toggleRows('${parentGroup}', this)">+</button>` : ''}
                ${parentRow.name}
            </td>
            <td width="10%" class="${Number(actuals) < 0 ? 'negative' : 'positive'}">${Math.round(actuals).toLocaleString()}</td>
            <td width="10%" class="${Number(aop) < 0 ? 'negative' : 'positive'}">${Math.round(aop).toLocaleString()}</td>
            <td width="10%" class="${Number(variance) < 0 ? 'negative' : 'positive'}">${Math.round(variance).toLocaleString()}</td>
            <td width="10%" class="${Number(variancePercent) < 0 ? 'negative' : 'positive'}">${variancePercent} %</td>
            <td width="10%" class="${Number(preActuals) < 0 ? 'negative' : 'positive'}">${Math.round(preActuals).toLocaleString()}</td>
            <td width="10%" class="${Number(preVariance) < 0 ? 'negative' : 'positive'}">${Math.round(preVariance).toLocaleString()}</td>
            <td width="10%" class="${Number(preVariancePercent) < 0 ? 'negative' : 'positive'}">${preVariancePercent} %</td>
        </tr>`;

                    // Add subcategory rows if they exist
                    if (hasSubcategories) {
                        let subcatIndex = 0;
                        for (let subcategory in subcategories) {
                            log.debug(subcategory)
                            subcatIndex++;
                            const subcatGroup = `fullY_subcat_${parentIndex}_${subcatIndex}_children`; // Unique group ID for child rows
                            const subcatTotal = fullYSubcategoryTotals[classification][parentRow.name][subcategory];
                            const subcatActuals = subcatTotal.actuals || 0;
                            const subcatAop = subcatTotal.aop || 0;
                            const subcatVariance = subcatTotal.variance || 0;
                            const subcatVariancePercent = (subcatAop !== 0) ? ((subcatVariance / subcatAop) * 100).toFixed(1) : 0;
                            const subcatPreActuals = subcatTotal.pre_actuals || 0;
                            const subcatPreVariance = subcatTotal.pre_variance2 || 0;
                            const subcatPreVariancePercent = (subcatPreActuals !== 0) ? ((subcatPreVariance / subcatPreActuals) * 100).toFixed(1) : 0;
                            const subcatVarianceClass = subcatVariance < 0 ? 'negative' : 'positive';

                            // Subcategory row
                            fullYHtml += `
                <tr class="subcategory-row" data-group="${parentGroup}" style="display:none;">
                    <td width="30%">
                        <button class="subcategory-toggle" onclick="toggleRows('${subcatGroup}', this)">+</button>
                        ${subcategory}
                    </td>
                    <td width="10%" class="${Number(subcatActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatAop) < 0 ? 'negative' : 'positive'}">${Math.round(subcatAop).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatVariance).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatVariancePercent) < 0 ? 'negative' : 'positive'}">${subcatVariancePercent} %</td>
                    <td width="10%" class="${Number(subcatPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreVariance).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariancePercent) < 0 ? 'negative' : 'positive'}">${subcatPreVariancePercent} %</td>
                </tr>`;

                            // Child rows under each subcategory
                            subcategories[subcategory].forEach(child => {
                                const childActuals = Number(child.actuals) || 0;
                                const childAop = Number(child.aop) || 0;
                                const childVariance = Number(child.variance) || 0;
                                const childVariancePercent = (childAop !== 0) ? ((childVariance / childAop) * 100).toFixed(1) : 0;
                                const childPreActuals = Number(child.pre_actuals) || 0;
                                const childPreVariance = Number(child.pre_variance2) || 0;
                                const childPreVariancePercent = (childPreActuals !== 0) ? ((childPreVariance / childPreActuals) * 100).toFixed(1) : 0;
                                const childVarianceClass = childVariance < 0 ? 'negative' : 'positive';

                                fullYHtml += `
                    <tr class="child-row" data-group="${subcatGroup}" style="display:none;">
                        <td width="30%">${child.acctnumber} ${child.accountsearchdisplaynamecopy}</td>
                        <td width="10%" class="${Number(childActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(childAop) < 0 ? 'negative' : 'positive'}">${Math.round(childAop).toLocaleString()}</td>
                        <td width="10%" class="${Number(childVariance) < 0 ? 'negative' : 'positive'}">${Math.round(childVariance).toLocaleString()}</td>
                        <td width="10%" class="${Number(childVariancePercent) < 0 ? 'negative' : 'positive'}">${childVariancePercent} %</td>
                        <td width="10%" class="${Number(childPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childPreActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(childPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(childPreVariance).toLocaleString()}</td>
                        <td width="10%" class="${Number(childPreVariancePercent) < 0 ? 'negative' : 'positive'}">${childPreVariancePercent} %</td>
                    </tr>`;
                            });
                        }
                    }
                });
            }
            catch (e) {
                log.error("error in fullYGrouped", e)
            }

            // Classification total row
            const totalVariancePercent = (classificationTotal.aop !== 0) && (classificationTotal.difference && classificationTotal.aop)
                ? ((classificationTotal.difference / classificationTotal.aop) * 100).toFixed(1)
                : 0
            const varianceClass = classificationTotal.difference < 0 ? 'negative' : 'positive';
            const totalPrevVarPercent = (classificationTotal.pre_actuals !== 0) && (classificationTotal.pre_variance && classificationTotal.pre_actuals)
                ? ((classificationTotal.pre_variance / classificationTotal.pre_actuals) * 100).toFixed(1)
                : 0



            // Update Full Year totals and add summary rows
            // First Condition Set: Update totals
            if (classification === 'Recurring Revenue' || classification === 'Non Recurring Revenue') {
                fullYTotalOperatingRevenueActuals += classificationTotal.actuals;
                fullYTotalOperatingRevenueAOP += classificationTotal.aop;
                fullYTotalOperatingRevenueDiff += classificationTotal.difference;
                fullYTotalOperatingRevenuePreActuals += classificationTotal.pre_actuals;
                fullYTotalOperatingRevenuePreVariance += classificationTotal.pre_variance;
                fullYTotalOperatingRevenuePreVariancePercent = (fullYTotalOperatingRevenuePreVariance !== 0) && (fullYTotalOperatingRevenuePreActuals && fullYTotalOperatingRevenuePreVariance)
                    ? ((fullYTotalOperatingRevenuePreVariance / fullYTotalOperatingRevenuePreActuals) * 100).toFixed(1)
                    : 0;
            }
            else if (classification === 'Cost of Revenue') {
                fullYTotalCostOfRevenueActuals = classificationTotal.actuals;
                fullYTotalCostOfRevenueAOP = classificationTotal.aop;
                fullYTotalCostOfRevenuePreActuals = classificationTotal.pre_actuals;
                fullYGrossMarginActuals = fullYTotalOperatingRevenueActuals - fullYTotalCostOfRevenueActuals;
                fullYGrossMarginAOP = fullYTotalOperatingRevenueAOP - fullYTotalCostOfRevenueAOP;
                fullYGrossMarginDiff = Math.abs(fullYGrossMarginAOP) - Math.abs(fullYGrossMarginActuals);
                fullYGrossMarginPreActuals = fullYTotalOperatingRevenuePreActuals - fullYTotalCostOfRevenuePreActuals;
                fullYGrossMarginPreVariance = fullYGrossMarginPreActuals - fullYGrossMarginActuals;
                fullYGrossMarginPreVariancePercent = (fullYGrossMarginPreVariance !== 0) && (fullYGrossMarginPreActuals && fullYGrossMarginPreVariance)
                    ? ((fullYGrossMarginPreVariance / fullYGrossMarginPreActuals) * 100).toFixed(1)
                    : 0
                log.debug("fullYTotalCostOfRevenueActuals", fullYTotalCostOfRevenueActuals)

                grossPerAct = (fullYTotalOperatingRevenueActuals !== 0) && (fullYGrossMarginActuals && fullYTotalOperatingRevenueActuals)
                    ? ((fullYGrossMarginActuals / fullYTotalOperatingRevenueActuals * 100).toFixed(1))
                    : 0;
                grossPerAOP = (fullYTotalOperatingRevenueAOP !== 0) && (fullYGrossMarginAOP && fullYTotalOperatingRevenueAOP)
                    ? ((fullYGrossMarginAOP / fullYTotalOperatingRevenueAOP * 100).toFixed(1))
                    : 0;
                grossPerVar = (grossPerAct && grossPerAOP) ? (Math.abs(grossPerAct) - Math.abs(grossPerAOP)).toFixed(1) + '%' : '0%';

                grossPrePerAct = (fullYTotalOperatingRevenuePreActuals !== 0) && (fullYGrossMarginPreActuals && fullYTotalOperatingRevenuePreActuals)
                    ? (((fullYGrossMarginPreActuals) / fullYTotalOperatingRevenuePreActuals * 100).toFixed(1))
                    : 0




            }
            else if (classification === 'OPERATING EXPENSES') {
                fullYOperatingExpensesActualTotal = classificationTotal.actuals;
                fullYOperatingExpensesAOPTotal = classificationTotal.aop;
                fullYOperatingExpensesPreActuals = classificationTotal.pre_actuals;
                fullYOperatingExpensesPreVariance = classificationTotal.pre_variance;
            }
            else if (classification === 'Other Operating Expenses' || classification === 'Other Operating Expenses ') {
                fullYOtherOperatingExpensesActualTotal = classificationTotal.actuals;
                fullYOtherOperatingExpensesAOPTotal = classificationTotal.aop;
                fullYOtherOperatingExpensesPreActuals = classificationTotal.pre_actuals;
                fullYOtherOperatingExpensesPreVariance = classificationTotal.pre_variance;
            }
            else if (classification === 'OTHER INCOME') {
                log.debug("other income calculation")
                fullYOtherIncomeTotalActuals = classificationTotal.actuals;
                fullYOtherIncomeTotalAOP = classificationTotal.aop;
                fullYTotalRevenueActuals = fullYTotalOperatingRevenueActuals + fullYOtherIncomeTotalActuals;
                fullYTotalRevenueAOP = fullYTotalOperatingRevenueAOP + fullYOtherIncomeTotalAOP;
                fullYTotalRevenueDiff = fullYTotalRevenueActuals - fullYTotalRevenueAOP;
                fullYOtherIncomeTotalPreActuals = classificationTotal.pre_actuals;
                fullYTotalRevenuePreActuals = fullYTotalOperatingRevenuePreActuals + fullYOtherIncomeTotalPreActuals
                fullYTotalRevenueVariance = fullYTotalRevenueActuals - fullYTotalRevenuePreActuals;





                fullYOtherIncomeTotalVariance = fullYOtherIncomeTotalActuals - fullYOtherIncomeTotalPreActuals;


            }
            else if (classification === 'Other expenses') {
                log.debug("other expenses calculation")
                fullYOtherExpensesTotalActuals = classificationTotal.actuals;
                fullYOtherExpensesTotalAOP = classificationTotal.aop;
                fullYOtherExpensesPreActuals = classificationTotal.pre_actuals;
                fullYOtherExpensesVariance = classificationTotal.pre_variance;
            }



            if (classification === 'Non Recurring Revenue') {
                log.debug("non rec calc")
                fullYHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
                  <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
            </tr>
                <tr class="summary-rows">
                    <td>TOTAL OPERATING REVENUE</td>
                    <td class="${Number(fullYTotalOperatingRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalOperatingRevenueActuals).toLocaleString()}</td>
                    <td class="${Number(fullYTotalOperatingRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalOperatingRevenueAOP).toLocaleString()}</td>
                    <td class="${Number(fullYTotalOperatingRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalOperatingRevenueDiff).toLocaleString()}</td>
                    <td class="${Number((fullYTotalOperatingRevenueAOP !== 0) && (fullYTotalOperatingRevenueDiff && fullYTotalOperatingRevenueAOP)
                    ? ((fullYTotalOperatingRevenueDiff / fullYTotalOperatingRevenueAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(fullYTotalOperatingRevenueAOP !== 0) && (fullYTotalOperatingRevenueDiff && fullYTotalOperatingRevenueAOP)
                        ? ((fullYTotalOperatingRevenueDiff / fullYTotalOperatingRevenueAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                          <td class="${Number(fullYTotalOperatingRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${fullYTotalOperatingRevenuePreActuals ? (Math.round(fullYTotalOperatingRevenuePreActuals).toLocaleString()) : 0}</td>
            <td class="${Number(fullYTotalOperatingRevenuePreVariance) < 0 ? 'negative' : 'positive'}">${fullYTotalOperatingRevenuePreVariance ? (Math.round(fullYTotalOperatingRevenuePreVariance).toLocaleString()) : 0}</td>
            <td class="${Number(fullYTotalOperatingRevenuePreVariancePercent) < 0 ? 'negative' : 'positive'}">${fullYTotalOperatingRevenuePreVariancePercent}</td>
                </tr>`;
            }
            else if (classification === 'Cost of Revenue') {
                const grossMarginPer = (fullYGrossMarginAOP !== 0) && (fullYGrossMarginDiff && fullYGrossMarginAOP)
                    ? ((fullYGrossMarginDiff / fullYGrossMarginAOP) * 100).toFixed(1)
                    : 0

                fullYHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
                  <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
            </tr>
                <tr class="summary-rows">
                    <td>Gross Margin (excl. other income)</td>
                    <td class="${Number(fullYGrossMarginActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginActuals).toLocaleString()}</td>
                    <td class="${Number(fullYGrossMarginAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginAOP).toLocaleString()}</td>
                    <td class="${Number(fullYGrossMarginDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginDiff).toLocaleString()}</td>
                    <td class="${Number(grossMarginPer) < 0 ? 'negative' : 'positive'}">${grossMarginPer}</td>
                      <td class="${Number(fullYGrossMarginPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginPreActuals).toLocaleString()}</td>
            <td class="${Number(fullYGrossMarginPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginPreVariance).toLocaleString()}</td>
            <td class="${Number((fullYGrossMarginPreActuals !== 0) && (fullYGrossMarginPreVariance && fullYGrossMarginPreActuals)
                    ? ((fullYGrossMarginPreVariance / fullYGrossMarginPreActuals) * 100).toFixed(1)
                    : 0) < 0 ? 'negative' : 'positive'}">${(fullYGrossMarginPreActuals !== 0) && (fullYGrossMarginPreVariance && fullYGrossMarginPreActuals)
                        ? ((fullYGrossMarginPreVariance / fullYGrossMarginPreActuals) * 100).toFixed(1) + '%'
                        : '0%'}</td>
                </tr>
                <tr class="summary-rows">
                    <td>Gross Margin %</td>
                    <td class="${Number(grossPerAct) < 0 ? 'negative' : 'positive'}">${(grossPerAct)}%</td>
                    <td class="${Number(grossPerAOP) < 0 ? 'negative' : 'positive'}">${(grossPerAOP)}%</td>
                    <td></td>
                      <td class="${Number(grossPerVar) < 0 ? 'negative' : 'positive'}">${(grossPerVar)}%</td>
            <td class="${Number(grossPrePerAct) < 0 ? 'negative' : 'positive'}">${(grossPrePerAct)}%</td>
            <td></td>
            <td class="${Number((grossPerAct && grossPrePerAct) ? (Math.round(grossPerAct - grossPrePerAct).toFixed(1)) : 0) < 0 ? 'negative' : 'positive'}">${(grossPerAct && grossPrePerAct) ? (Math.round(grossPerAct - grossPrePerAct).toFixed(1)) : 0}%</td>
                </tr>`;
            }
            else if (classification === 'Other Operating Expenses' || classification === 'Other Operating Expenses ') {
                log.debug("other operating calc")
                const totalOperatingActual = fullYOperatingExpensesActualTotal + fullYOtherOperatingExpensesActualTotal;
                const totalOperatingAOP = fullYOperatingExpensesAOPTotal + fullYOtherOperatingExpensesAOPTotal;
                const totalOperatingDiff = Math.abs(totalOperatingAOP) - Math.abs(totalOperatingActual);
                const proFormaEbitaActuals = fullYGrossMarginActuals - totalOperatingActual;
                const proFormaEbitaAOP = fullYGrossMarginAOP - totalOperatingAOP;
                const proFormaEbitaDiff = proFormaEbitaAOP - proFormaEbitaActuals;


                const totalOperatingPreActual = fullYOperatingExpensesPreActuals + fullYOtherOperatingExpensesPreActuals;
                const totalOperatingVariance = totalOperatingActual - totalOperatingPreActual;
                const totalOperatingVarPer = (totalOperatingPreActual !== 0) && (totalOperatingVariance && totalOperatingPreActual)
                    ? ((totalOperatingVariance / totalOperatingPreActual * 100).toFixed(1) + '%')
                    : '0%'


                const proFormaEbitaPerActuals = (fullYTotalOperatingRevenueActuals !== 0) && (proFormaEbitaActuals && fullYTotalOperatingRevenueActuals)
                    ? ((proFormaEbitaActuals / fullYTotalOperatingRevenueActuals) * 100).toFixed(1)
                    : 0

                const proFormaEbitaPerAOP = (fullYTotalOperatingRevenueAOP !== 0) && (proFormaEbitaAOP && fullYTotalOperatingRevenueAOP)
                    ? ((proFormaEbitaAOP / fullYTotalOperatingRevenueAOP) * 100).toFixed(1)
                    : 0

                const proFormaEbitaPerDiff = proFormaEbitaPerActuals - proFormaEbitaPerAOP;

                const proFormaEbitaPreActuals = fullYGrossMarginPreActuals - totalOperatingPreActual;
                const proFormaEbitaVariance = proFormaEbitaActuals - proFormaEbitaPreActuals;

                const proFormaEbitaPrePerAct = (fullYTotalOperatingRevenuePreActuals !== 0) && (proFormaEbitaPreActuals && fullYTotalOperatingRevenuePreActuals)
                    ? ((proFormaEbitaPreActuals / fullYTotalOperatingRevenuePreActuals) * 100).toFixed(1)
                    : 0

                const proFormaEbitaPreVarPer = proFormaEbitaPerActuals - proFormaEbitaPrePerAct;


                const proFormaEbitaVarPer = (proFormaEbitaPreActuals !== 0) && (proFormaEbitaVariance && proFormaEbitaPreActuals)
                    ? ((proFormaEbitaVariance / proFormaEbitaPreActuals) * 100).toFixed(1)
                    : 0


                fullYHtml += `
            <tr class="total-row">
            <td>TOTAL ${classification}</td>
            <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
            <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
              <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
        <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr>
                <tr class="summary-rows">
                    <td>TOTAL OPERATING EXPENSES</td>
                    <td class="${Number(totalOperatingActual) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingActual).toLocaleString()}</td>
                    <td class="${Number(totalOperatingAOP) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingAOP).toLocaleString()}</td>
                    <td class="${Number(totalOperatingDiff) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingDiff).toLocaleString()}</td>
                    <td class="${Number((totalOperatingAOP !== 0) && (totalOperatingDiff && totalOperatingAOP)
                    ? ((totalOperatingDiff / totalOperatingAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(totalOperatingAOP !== 0) && (totalOperatingDiff && totalOperatingAOP)
                        ? ((totalOperatingDiff / totalOperatingAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(totalOperatingPreActual) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingPreActual).toLocaleString()}</td>
            <td class="${Number(totalOperatingVariance) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingVariance).toLocaleString()}</td>
            <td class="${Number(totalOperatingVarPer) < 0 ? 'negative' : 'positive'}">${totalOperatingVarPer}</td>
                </tr>
                <tr class="summary-rows">
                    <td>Pro Forma EBITDA</td>
                    <td class="${Number(proFormaEbitaActuals) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaActuals).toLocaleString()}</td>
                    <td class="${Number(proFormaEbitaAOP) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaAOP).toLocaleString()}</td>
                    <td  class="${Number(proFormaEbitaDiff) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaDiff).toLocaleString()}</td>
                    <td class="${Number((proFormaEbitaAOP !== 0) && (proFormaEbitaDiff && proFormaEbitaAOP)
                            ? ((proFormaEbitaDiff / proFormaEbitaAOP * 100).toFixed(1))
                            : 0) < 0 ? 'negative' : 'positive'}">${(proFormaEbitaAOP !== 0) && (proFormaEbitaDiff && proFormaEbitaAOP)
                                ? ((proFormaEbitaDiff / proFormaEbitaAOP * 100).toFixed(1) + '%')
                                : '0%'}</td>
                        <td class="${Number(proFormaEbitaPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaPreActuals).toLocaleString()}</td>
                        
            <td class="${Number(proFormaEbitaVariance) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaVariance).toLocaleString()}</td>
            <td class="${Number(proFormaEbitaVarPer) < 0 ? 'negative' : 'positive'}">${proFormaEbitaVarPer}</td>
                </tr>
                 <tr class="summary-rows">
                    <td>Pro Forma EBITDA %</td>
                    <td class="${Number(proFormaEbitaPerActuals) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerActuals}%</td>
                    <td class="${Number(proFormaEbitaPerAOP) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerAOP} %</td>
                    <td></td>
                    <td class="${Number(proFormaEbitaPerDiff) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerDiff ? (proFormaEbitaPerDiff.toFixed(1)) : '0'}%</td>
                    <td class="${Number(proFormaEbitaPrePerAct) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPrePerAct} %</td>
                    <td></td>
                    <td class="${Number(proFormaEbitaPreVarPer) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPreVarPer ? (proFormaEbitaPreVarPer.toFixed(1)) : 0}%</td>
                </tr>`;
            }
            else if (classification === 'OTHER INCOME') {
                log.debug("other income calc")
                fullYHtml += `
            <tr class="total-row">
            <td>TOTAL ${classification}</td>
            <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
            <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
              <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
        <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr>
                <tr class="summary-rows">
                    <td>Total Revenue</td>
                    <td class="${Number(fullYTotalRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueActuals).toLocaleString()}</td>
                    <td class="${Number(fullYTotalRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueAOP).toLocaleString()}</td>
                    <td class="${Number(fullYTotalRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueDiff).toLocaleString()}</td>
                    <td class="${Number((fullYTotalRevenueAOP !== 0) && (fullYTotalRevenueDiff && fullYTotalRevenueAOP)
                    ? ((fullYTotalRevenueDiff / fullYTotalRevenueAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(fullYTotalRevenueAOP !== 0) && (fullYTotalRevenueDiff && fullYTotalRevenueAOP)
                        ? ((fullYTotalRevenueDiff / fullYTotalRevenueAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(fullYTotalRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenuePreActuals).toLocaleString()}</td>
            <td class="${Number(fullYTotalRevenueVariance) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueVariance).toLocaleString()}</td>
            <td class="${Number((fullYTotalRevenuePreActuals !== 0) && (fullYTotalRevenueVariance && fullYTotalRevenuePreActuals)
                            ? ((fullYTotalRevenueVariance / fullYTotalRevenuePreActuals * 100).toFixed(1))
                            : 0) < 0 ? 'negative' : 'positive'}">${(fullYTotalRevenuePreActuals !== 0) && (fullYTotalRevenueVariance && fullYTotalRevenuePreActuals)
                                ? ((fullYTotalRevenueVariance / fullYTotalRevenuePreActuals * 100).toFixed(1) + '%')
                                : '0%'}</td>
                </tr>`;
            }
            else if (classification === 'Other expenses') {
                fullYNetProfitActuals = (fullYGrossMarginActuals + fullYOtherIncomeTotalActuals) -
                    (fullYOperatingExpensesActualTotal + fullYOtherOperatingExpensesActualTotal + fullYOtherExpensesTotalActuals);
                fullYNetProfitAOP = (fullYGrossMarginAOP + fullYOtherIncomeTotalAOP) -
                    (fullYOperatingExpensesAOPTotal + fullYOtherOperatingExpensesAOPTotal + fullYOtherExpensesTotalAOP);
                fullYNetProfitDiff = fullYNetProfitActuals - fullYNetProfitAOP;

                fullYNetProfitPreActuals = (fullYGrossMarginPreActuals + fullYOtherIncomeTotalPreActuals) -
                    (fullYOperatingExpensesPreActuals + fullYOtherOperatingExpensesPreActuals + fullYOtherExpensesPreActuals);

                fullNetProfitVariance = fullYNetProfitActuals - fullYNetProfitPreActuals;

                fullYHtml += `
            <tr class="total-row">
            <td>TOTAL ${classification}</td>
            <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
            <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
              <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
        <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr>
                <tr class="summary-rows">
                    <td>NET PROFIT</td>
                    <td class="${Number(fullYNetProfitActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitActuals).toLocaleString()}</td>
                    <td class="${Number(fullYNetProfitAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitAOP).toLocaleString()}</td>
                    <td class="${Number(fullYNetProfitDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitDiff).toLocaleString()}</td>
                    <td class="${Number((fullYNetProfitAOP !== 0) && (fullYNetProfitDiff && fullYNetProfitAOP)
                    ? ((fullYNetProfitDiff / fullYNetProfitAOP * 100).toFixed(1))
                    : 0) < 0 ? 'negative' : 'positive'}">${(fullYNetProfitAOP !== 0) && (fullYNetProfitDiff && fullYNetProfitAOP)
                        ? ((fullYNetProfitDiff / fullYNetProfitAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(fullYNetProfitPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitPreActuals).toLocaleString()}</td>
            <td class="${Number(fullNetProfitVariance) < 0 ? 'negative' : 'positive'}">${Math.round(fullNetProfitVariance).toLocaleString()}</td>
            <td class="${Number((fullYNetProfitPreActuals !== 0) && (fullNetProfitVariance && fullYNetProfitPreActuals)
                            ? ((fullNetProfitVariance / fullYNetProfitPreActuals * 100).toFixed(1))
                            : 0) < 0 ? 'negative' : 'positive'}">${(fullYNetProfitPreActuals !== 0) && (fullNetProfitVariance && fullYNetProfitPreActuals)
                                ? ((fullNetProfitVariance / fullYNetProfitPreActuals * 100).toFixed(1) + '%')
                                : '0%'}</td>
                </tr>`



            }
            else if (classification === 'OPERATING EXPENSES') {
                fullYHtml += `
    <tr class="total-row">
        <td>HEADCOUNT COST</td>
        <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
        <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
        <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
         <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
    </tr>`;
            }
            else {
                fullYHtml += `
    <tr class="total-row">
    <td>TOTAL ${classification}</td>
    <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
    <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
    <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
    <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
      <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
<td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
<td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
</tr>`;
            }



        }





        // Rest of the classification total and summary rows remain unchanged
        // ... (keep the existing code for classification totals and summary rows)

        fullYHtml += `<tr class="classification-section"><td colspan="8">CONTRACTED ARR ($)</td></tr>
    ${arrPart}
    <tr class="arrtable">
        <td>ARR Net New Bookings (MRR from SF x 12)</td>
        <td class="${Number(fullYnetNewActualsSum) < 0 ? 'negative' : 'positive'}">${Math.round(fullYnetNewActualsSum).toLocaleString()}</td>
        <td class="${Number(fullYnetNewAopSum) < 0 ? 'negative' : 'positive'}">${Math.round(fullYnetNewAopSum).toLocaleString()}</td>
        <td class="${Number(fullYnetNewActualsSum - fullYnetNewAopSum) < 0 ? 'negative' : 'positive'}">${Math.round(fullYnetNewActualsSum - fullYnetNewAopSum).toLocaleString()}</td>
        <td class="${((fullYnetNewActualsSum - fullYnetNewAopSum) / fullYnetNewAopSum) < 0 ? 'negative' : 'positive'}">
            ${(fullYnetNewAopSum !== 0) && (fullYnetNewActualsSum && fullYnetNewAopSum)
                ? ((fullYnetNewActualsSum - fullYnetNewAopSum) / fullYnetNewAopSum * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="total-row">
        <td>Total Contracted ARR</td>
        <td class="${Number(contractedActualsTotal) < 0 ? 'negative' : 'positive'}">${Math.round(contractedActualsTotal).toLocaleString()}</td>
        <td class="${Number(contractedAopTotal) < 0 ? 'negative' : 'positive'}">${Math.round(contractedAopTotal).toLocaleString()}</td>
        <td class="${Number(contractedVariance) < 0 ? 'negative' : 'positive'}">${Math.round(contractedVariance).toLocaleString()}</td>
        <td class="${((contractedActualsTotal - contractedAopTotal) / contractedAopTotal) < 0 ? 'negative' : 'positive'}">
            ${(contractedAopTotal !== 0) && (contractedActualsTotal && contractedAopTotal)
                ? ((contractedActualsTotal - contractedAopTotal) / contractedAopTotal * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="classification-section"><td colspan="8">CLIENT DATA</td></tr>
    
    <tr class="client-data">
        <td>New Clients</td>
        <td class="${Number(fullYnewClientsAct) < 0 ? 'negative' : 'positive'}">${fullYnewClientsAct || 0}</td>
        <td class="${Number(fullYnewClientsAop) < 0 ? 'negative' : 'positive'}">${fullYnewClientsAop || 0}</td>
        <td class="${Number(fullYnewClientsAct - fullYnewClientsAop) < 0 ? 'negative' : 'positive'}">${Number(fullYnewClientsAct) - Number(fullYnewClientsAop) || 0}</td>
        <td class="${((fullYnewClientsAct - fullYnewClientsAop) / fullYnewClientsAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYnewClientsAop !== 0) && (fullYnewClientsAct && fullYnewClientsAop)
                ? ((fullYnewClientsAct - fullYnewClientsAop) / fullYnewClientsAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="client-data">
        <td>Attrition</td>
        <td class="${Number(fullYattritionAct) < 0 ? 'negative' : 'positive'}">${fullYattritionAct || 0}</td>
        <td class="${Number(fullYattritionAop) < 0 ? 'negative' : 'positive'}">${fullYattritionAop || 0}</td>
        <td class="${Number(fullYattritionAct - fullYattritionAop) < 0 ? 'negative' : 'positive'}">${Number(fullYattritionAct) - Number(fullYattritionAop) || 0}</td>
        <td class="${((fullYattritionAct - fullYattritionAop) / fullYattritionAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYattritionAop !== 0) && (fullYattritionAct && fullYattritionAop)
                ? ((fullYattritionAct - fullYattritionAop) / fullYattritionAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="client-data">
        <td>Existing</td>
        <td class="${Number(fullYexistingAct) < 0 ? 'negative' : 'positive'}">${fullYexistingAct || 0}</td>
        <td class="${Number(fullYexistingAop) < 0 ? 'negative' : 'positive'}">${fullYexistingAop || 0}</td>
        <td class="${Number(fullYexistingAct - fullYexistingAop) < 0 ? 'negative' : 'positive'}">${Number(fullYexistingAct) - Number(fullYexistingAop) || 0}</td>
        <td class="${((fullYexistingAct - fullYexistingAop) / fullYexistingAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYexistingAop !== 0) && (fullYexistingAct && fullYexistingAop)
                ? ((fullYexistingAct - fullYexistingAop) / fullYexistingAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="total-row">
        <td>Total Clients</td>
        <td class="${Number(fullYtotalClientsAct) < 0 ? 'negative' : 'positive'}">${fullYtotalClientsAct || 0}</td>
        <td class="${Number(fullYtotalClientsAop) < 0 ? 'negative' : 'positive'}">${fullYtotalClientsAop || 0}</td>
        <td class="${Number(fullYtotalClientsAct - fullYtotalClientsAop) < 0 ? 'negative' : 'positive'}">${Number(fullYtotalClientsAct) - Number(fullYtotalClientsAop) || 0}</td>
        <td class="${((fullYtotalClientsAct - fullYtotalClientsAop) / fullYtotalClientsAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYtotalClientsAop !== 0) && (fullYtotalClientsAct && fullYtotalClientsAop)
                ? ((fullYtotalClientsAct - fullYtotalClientsAop) / fullYtotalClientsAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="classification-section"><td colspan="8">HEADCOUNT</td></tr>
    
    <tr class="parent-row">
        <td>Sales and Marketing</td>
        <td class="${Number(fullYsalesAndMarketingActuals) < 0 ? 'negative' : 'positive'}">${fullYsalesAndMarketingActuals}</td>
        <td class="${Number(fullYsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${fullYsalesAndMarketingAop}</td>
        <td class="${Number(fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop}</td>
        <td class="${((fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop) / fullYsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYsalesAndMarketingAop !== 0) && (fullYsalesAndMarketingActuals && fullYsalesAndMarketingAop)
                ? ((fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop) / fullYsalesAndMarketingAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>Product</td>
        <td class="${Number(fullYproductActuals) < 0 ? 'negative' : 'positive'}">${fullYproductActuals}</td>
        <td class="${Number(fullYproductAop) < 0 ? 'negative' : 'positive'}">${fullYproductAop}</td>
        <td class="${Number(fullYproductActuals - fullYproductAop) < 0 ? 'negative' : 'positive'}">${fullYproductActuals - fullYproductAop}</td>
        <td class="${((fullYproductActuals - fullYproductAop) / fullYproductAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYproductAop !== 0) && (fullYproductActuals && fullYproductAop)
                ? ((fullYproductActuals - fullYproductAop) / fullYproductAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>General &amp; Administrative</td>
        <td class="${Number(fullYgeneraladminActuals) < 0 ? 'negative' : 'positive'}">${fullYgeneraladminActuals}</td>
        <td class="${Number(fullYgeneralAdminAop) < 0 ? 'negative' : 'positive'}">${fullYgeneralAdminAop}</td>
        <td class="${Number(fullYgeneraladminActuals - fullYgeneralAdminAop) < 0 ? 'negative' : 'positive'}">${fullYgeneraladminActuals - fullYgeneralAdminAop}</td>
        <td class="${((fullYgeneraladminActuals - fullYgeneralAdminAop) / fullYgeneralAdminAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYgeneralAdminAop !== 0) && (fullYgeneraladminActuals && fullYgeneralAdminAop)
                ? ((fullYgeneraladminActuals - fullYgeneralAdminAop) / fullYgeneralAdminAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>Customer Success</td>
        <td class="${Number(fullYcustomersuccessActuals) < 0 ? 'negative' : 'positive'}">${fullYcustomersuccessActuals}</td>
        <td class="${Number(fullYcustomersuccessAop) < 0 ? 'negative' : 'positive'}">${fullYcustomersuccessAop}</td>
        <td class="${Number(fullYcustomersuccessActuals - fullYcustomersuccessAop) < 0 ? 'negative' : 'positive'}">${fullYcustomersuccessActuals - fullYcustomersuccessAop}</td>
        <td class="${((fullYcustomersuccessActuals - fullYcustomersuccessAop) / fullYcustomersuccessAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYcustomersuccessAop !== 0) && (fullYcustomersuccessActuals && fullYcustomersuccessAop)
                ? ((fullYcustomersuccessActuals - fullYcustomersuccessAop) / fullYcustomersuccessAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>R &amp; D</td>
        <td class="${Number(fullYranddActuals) < 0 ? 'negative' : 'positive'}">${fullYranddActuals}</td>
        <td class="${Number(fullYranddAop) < 0 ? 'negative' : 'positive'}">${fullYranddAop}</td>
        <td class="${Number(fullYranddActuals - fullYranddAop) < 0 ? 'negative' : 'positive'}">${fullYranddActuals - fullYranddAop}</td>
        <td class="${((fullYranddActuals - fullYranddAop) / fullYranddAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYranddAop !== 0) && (fullYranddActuals && fullYranddAop)
                ? ((fullYranddActuals - fullYranddAop) / fullYranddAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="total-row">
        <td>HeadCount Total </td>
        <td class="${Number(fullYheadcounttotalActuals) < 0 ? 'negative' : 'positive'}">${fullYheadcounttotalActuals}</td>
        <td class="${Number(fullYheadcounttotalAop) < 0 ? 'negative' : 'positive'}">${fullYheadcounttotalAop}</td>
        <td class="${Number(fullYheadcounttotalActuals - fullYheadcounttotalAop) < 0 ? 'negative' : 'positive'}">${fullYheadcounttotalActuals - fullYheadcounttotalAop}</td>
        <td class="${((fullYheadcounttotalActuals - fullYheadcounttotalAop) / fullYheadcounttotalAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYheadcounttotalAop !== 0) && (fullYheadcounttotalActuals && fullYheadcounttotalAop)
                ? ((fullYheadcounttotalActuals - fullYheadcounttotalAop) / fullYheadcounttotalAop * 100).toFixed(1) + '%'
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    </table>`

        log.debug("complete calculation done")
        var fullYOnlyHtml = fullYHtml

        tableHtml += fullYHtml

        var fullYClosurePart = `<script>
                    function printPDF() { window.print(); }
    let isExpanded = false;
    function toggleAllRows() {
        const allRows = document.querySelectorAll('[data-group]');
        allRows.forEach(row => {
            if (isExpanded) {
                row.style.display = 'none';
            } else {
                row.style.display = 'table-row';
            }
        });
        const buttons = document.querySelectorAll('.toggle-button, .subcategory-toggle');
        console.log('Toggle All: Found', buttons.length, 'buttons'); // Debug log
        buttons.forEach(button => {
            button.textContent = isExpanded ? '+' : '-';
            button.classList.toggle('plus-state', button.textContent === '+');
        });
        isExpanded = !isExpanded;
        document.getElementById('toggleAllBtn').title = isExpanded ? "Collapse All" : "Expand All";
        document.getElementById('toggleAllBtn').textContent = isExpanded ? '+' : '-';
    }
    function toggleRows(group, btn) {
        const rows = document.querySelectorAll('[data-group="' + group + '"]');
        console.log('Toggle Rows: Group', group, 'Found', rows.length, 'rows'); // Debug log
        const isVisible = rows.length > 0 && rows[0].style.display === 'table-row';
        rows.forEach(row => {
            row.style.display = isVisible ? 'none' : 'table-row';
        });
        btn.textContent = isVisible ? '+' : '-';
        btn.classList.toggle('plus-state', btn.textContent === '+');
        console.log('Button classes:', btn.className); // Debug log
    }
</script></body></html>`;


        tableHtml += fullYClosurePart
        var monthAndYear=getMonthAndYear(accountingPeriod)
        var htmlFile = file.create({
            name: 'fullYearFunction' + subsidiaryName + '_' + monthAndYear + '.html',         // file name
            fileType: file.Type.HTMLDOC, // saves as HTML
            contents: tableHtml,       // your HTML string
            folder: 11900             // Internal ID of target folder in File Cabinet
        });

        var fullYOnlyTableFile = file.create({
            name: 'fullYearTable' + subsidiaryName + '_' + monthAndYear + '.txt',         // file name
            fileType: file.Type.PLAINTEXT, // saves as HTML
            contents: fullYOnlyHtml,       // your HTML string
            folder: 11904             // Internal ID of target folder in File Cabinet
        });

        // Save file in File Cabinet
        var fileId = htmlFile.save();
        var fullYOnlyTableFileId = fullYOnlyTableFile.save();
        return { fileId: fileId, fullYOnlyTableFileId: fullYOnlyTableFileId };



     } 
    catch(e){
        log.error("error in full year report",e)
        
    }}
    function getBudgetId(monthNumber) {
        try{
        var customrecord_tyfone_budgetcatgorymonthsSearchObj = search.create({
            type: "customrecord_tyfone_budgetcatgorymonths",
            filters:
                [
                    ["custrecord_ty_month_dashboard", "anyof", monthNumber]
                ],
            columns:
                [
                    search.createColumn({ name: "custrecord_ty_budget_cat", label: "Category" })

                ]
        });
        var searchResultCount = customrecord_tyfone_budgetcatgorymonthsSearchObj.runPaged().count;

        log.debug("customrecord_tyfone_budgetcatgorymonthsSearchObj result count", searchResultCount);
        var budgetId = 0
        customrecord_tyfone_budgetcatgorymonthsSearchObj.run().each(function (result) {
            budgetId = result.getValue({ name: "custrecord_ty_budget_cat" })
            return false;
        });
        return budgetId;
    }
catch(e){
        log.error("error in getBudgetId function",e)
        
    } }
    function getFinancialYearMonthsFullYear(monthPeriodId) {
        try {
            // Step 1: Get the parent quarter and financial year
            var accountingperiodSearch = search.create({
                type: "accountingperiod",
                filters: [
                    ["internalid", "anyof", monthPeriodId]
                ],
                columns: [
                    search.createColumn({ name: "parent" }) // Quarter ID
                ]
            });

            var quarterId, financialYearId, financialYearName;

            accountingperiodSearch.run().each(function (result) {
                quarterId = result.getValue({ name: "parent" }); // Get quarter
                return true;
            });

            if (!quarterId) {
                log.error("Quarter Not Found", "Could not determine the quarter for the selected month.");
                return [];
            }

            // Step 2: Get the financial year (parent of the quarter)
            var quarterSearch = search.create({
                type: "accountingperiod",
                filters: [
                    ["internalid", "anyof", quarterId]
                ],
                columns: [
                    search.createColumn({ name: "parent" }) // Financial Year ID
                ]
            });

            quarterSearch.run().each(function (result) {
                financialYearId = result.getValue({ name: "parent" }); // Get Financial Year ID
                financialYearName = result.getText({ name: "parent" });
                return true;
            });

            if (!financialYearId) {
                log.error("Financial Year Not Found", "Could not determine the financial year.");
                return [];
            }

            // Step 3: Get all months within the financial year
            var monthIds = [];
            var financialYearSearch = search.create({
                type: "accountingperiod",
                filters: [
                    ["parent", "anyof", financialYearId], // Filter by financial year
                    "AND",
                    ["isquarter", "is", "F"], // Ensure only months, not quarters
                    "AND",
                    ["isyear", "is", "F"] // Exclude full-year periods
                ],
                columns: [
                    search.createColumn({ name: "internalid", sort: search.Sort.ASC })
                ]
            });

            financialYearSearch.run().each(function (result) {
                monthIds.push(result.getValue({ name: "internalid" }));
                return true;
            });

            log.debug("Financial Year Month IDs", monthIds);
            return { monthIds: monthIds, financialYearName: financialYearName };

        } catch (error) {
            log.error('Error in getFinancialYearMonthsFullYear function', error);
            
        }
    }



    function getPreviousYearAccountingPeriods(currentPeriodIds) {
try{
        var previousPeriodInternalIds = []; // Array to store previous year period IDs

        for (var i = 0; i < currentPeriodIds.length; i++) {
            log.debug("passed internl id to find prev month qtd", currentPeriodIds[i])
            var accountingperiodSearchObj = search.create({
                type: "accountingperiod",
                filters: [
                    ["internalid", "is", currentPeriodIds[i]] // Fetch period one by one
                ],
                columns: [
                    search.createColumn({ name: "periodname", label: "Name" })
                ]
            });

            var previousYearPeriodName = null;
            if (accountingperiodSearchObj) {
                // Extract period name and derive previous year period
                accountingperiodSearchObj.run().each(function (result) {
                    var periodName = result.getValue("periodname"); // e.g., "Apr 2024"
                    var parts = periodName.split(" "); // ["Apr", "2024"]

                    if (parts.length === 2) {
                        var month = parts[0]; // "Apr"
                        var year = parseInt(parts[1]); // 2024
                        var prevYear = year - 1; // 2023
                        previousYearPeriodName = month + " " + prevYear; // "Apr 2023"
                    }

                    return false; // Stop after the first match
                });
            }

            if (previousYearPeriodName) {
                var prevYearSearchObj = search.create({
                    type: "accountingperiod",
                    filters: [
                        ["periodname", "is", previousYearPeriodName] // Search for "Apr 2023"
                    ],
                    columns: [
                        search.createColumn({ name: "internalid", label: "Internal ID" })
                    ]
                });

                // Fetch internal ID for previous year period
                prevYearSearchObj.run().each(function (result) {
                    var prevYearInternalId = result.getValue("internalid");
                    previousPeriodInternalIds.push(parseInt(prevYearInternalId));
                    return false; // Stop after first match
                });

            }
        }

        return previousPeriodInternalIds.length > 0 ? previousPeriodInternalIds : null;
    }
catch(e){
    log.error("error in getPreviousYearAccountingPeriods function",e)
    

}
}

    function getFinancialYearMonthsYTD(selectedPeriodId) {
        try {
            // First get the selected period's start date
            var selectedPeriodSearch = search.create({
                type: "accountingperiod",
                filters: [["internalid", "anyof", selectedPeriodId]],
                columns: [
                    search.createColumn({ name: "startdate" }),
                    search.createColumn({ name: "parent" }) // Quarter ID
                ]
            });

            var selectedStartDate, financialYearId, financialYearName;
            selectedPeriodSearch.run().each(function (result) {
                selectedStartDate = result.getValue("startdate");
                var quarterId = result.getValue("parent");

                // Get financial year from quarter
                var quarterSearch = search.create({
                    type: "accountingperiod",
                    filters: [["internalid", "anyof", quarterId]],
                    columns: [search.createColumn({ name: "parent" })] // Financial Year ID
                });

                quarterSearch.run().each(function (qResult) {
                    financialYearId = qResult.getValue("parent");
                    financialYearName = qResult.getText("parent");
                    return true;
                });
                return true;
            });

            if (!financialYearId) {
                log.error("Financial Year Not Found", "Could not determine financial year");
                return null;
            }

            // Get all months in financial year up to selected date
            var monthIds = [];
            var monthNames = [];

            var monthSearch = search.create({
                type: "accountingperiod",
                filters: [
                    ["parent", "anyof", financialYearId],
                    "AND",
                    ["isquarter", "is", "F"],
                    "AND",
                    ["startdate", "onorbefore", selectedStartDate],
                    "AND",
                    ["isyear", "is", "F"]
                ],
                columns: [
                    search.createColumn({ name: "internalid" }),
                    search.createColumn({ name: "periodname", label: "Name" }),
                    search.createColumn({ name: "startdate", sort: search.Sort.ASC })
                ]
            });

            monthSearch.run().each(function (result) {
                var periodId = result.getValue("internalid");
                var periodName = result.getValue("periodname"); // e.g., "Apr 2024"
                var startDate = result.getValue("startdate"); // Get the start date

                if (periodId && periodName && startDate) {
                    monthIds.push(periodId);

                    // Convert the start date using the N/format module
                    var dateObj = format.parse({
                        value: startDate,
                        type: format.Type.DATE
                    });
                    // Extract full month name
                    var fullMonthName = dateObj.toLocaleString('en-US', { month: 'long' });

                    // Avoid duplicates in the monthNames array
                    if (monthNames.indexOf(fullMonthName) === -1) {
                        monthNames.push(fullMonthName);
                    }
                }
                return true;
            });

            // Define standard month order and financial year start (April)
            var monthOrder = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            var financialStartIndex = monthOrder.indexOf("April");

            // Sort using a custom sort that rotates the order based on the financial start (April)
            monthNames.sort(function (a, b) {
                var aIndex = (monthOrder.indexOf(a) - financialStartIndex + 12) % 12;
                var bIndex = (monthOrder.indexOf(b) - financialStartIndex + 12) % 12;
                return aIndex - bIndex;
            });

            var firstMonth = monthNames.length > 0 ? monthNames[0] : null;
            var lastMonth = monthNames.length > 0 ? monthNames[monthNames.length - 1] : null;

            log.debug("YTD Months", monthIds);
            log.debug("First and Last Month", { firstMonth: firstMonth, lastMonth: lastMonth });

            return {
                monthIds: monthIds,
                financialYearName: financialYearName,
                firstMonth: firstMonth,
                lastMonth: lastMonth
            };

        } catch (error) {
            log.error("Error in getFinancialYearMonthsYTD", error);
            
        }
    }




    function parseSubsidiaryHierarchy(results) {
        try{
        // Check if we have at least one result
        if (results.length === 0) {
            return [];
        }

        // Get the CSV string from the first record (adjust if needed for your use case)
        const csvString = results[0].custrecord_subsidiary_hierarchy;

        // Split the string on commas, trim extra spaces, and convert each string to a number.
        const numberArray = csvString.split(',')
            .map(value => value.trim())
            .map(value => Number(value)); // Or use parseInt(value, 10) if you expect integers

        return numberArray;
    }
    catch(e){
        log.error("error in parseSubsidiaryHierarchy function",e)
        
    }
    }
    function getAprilId(accountingPeriod) {
        try{
        var quarterId;
        var yearId;
        var aprilId;

        // Step 1: Get Quarter ID from Selected Accounting Period
        var accountingperiodSearchObj = search.create({
            type: "accountingperiod",
            filters: [["internalid", "anyof", accountingPeriod]],
            columns: [search.createColumn({ name: "parent", label: "Parent" })]
        });

        var searchResultCount = accountingperiodSearchObj.runPaged().count;
        log.debug("accountingperiodSearchObj result count", searchResultCount);

        accountingperiodSearchObj.run().each(function (result) {
            quarterId = result.getValue({ name: "parent" }) || null;
            return false; // Exit after first result
        });

        // Step 2: Get Year ID from Quarter
        if (quarterId) {
            var accountingperiodSearchObj1 = search.create({
                type: "accountingperiod",
                filters: [["internalid", "anyof", quarterId]],
                columns: [search.createColumn({ name: "parent", label: "Parent" })]
            });

            var searchResultCount1 = accountingperiodSearchObj1.runPaged().count;
            log.debug("accountingperiodSearchObj1 result count", searchResultCount1);

            accountingperiodSearchObj1.run().each(function (result) {
                yearId = result.getValue({ name: "parent" }) || null;
                return false; // Exit after first result
            });
            
        }

        // Step 3: Get April Month ID for the Year
        if (yearId) {
            var accountingperiodSearchObj2 = search.create({
                type: "accountingperiod",
                filters: [
                    ["parent", "anyof", yearId],
                    "AND",
                    ["periodname", "startswith", "Apr"]
                ],
                columns: [
                    search.createColumn({ name: "periodname", label: "Name" }),
                    search.createColumn({ name: "internalid", label: "Internal ID" })
                ]
            });

            var searchResultCount2 = accountingperiodSearchObj2.runPaged().count;
            log.debug("accountingperiodSearchObj2 result count", searchResultCount2);

            accountingperiodSearchObj2.run().each(function (result) {
                aprilId = result.getValue({ name: "internalid" }) || null;
                return false; // Exit after first result
            });
        }
        return aprilId;
    }
    catch(e){
            log.error("error in getAprilMonths function",e)
            
        }

    }



function getQuarterMonthIds(accountingPeriod) {
    try {
        var accountingperiodSearchObj = search.create({
            type: "accountingperiod",
            filters: [
                ["internalid", "anyof", accountingPeriod]
            ],
            columns: [
                search.createColumn({ name: "periodname", label: "Name" }),
                search.createColumn({ name: "startdate", label: "Start Date" }),
                search.createColumn({ name: "parent", label: "Parent" }),
            ]
        });

        var selectedStartDate;
        var selectedQuarter;
        var selectedQuarterName;
        var selectedQuarterFullName;

        accountingperiodSearchObj.run().each(function (result) {
            selectedStartDate = result.getValue({ name: "startdate" });
            selectedQuarter = result.getValue({ name: "parent" });
            selectedQuarterFullName = result.getText({ name: "parent" });
            selectedQuarterName = selectedQuarterFullName.split(" ")[0];
            return true; // Continue iterating
        });

        if (!selectedQuarter) {
            log.error("Quarter not found", "Could not determine the quarter for the selected accounting period.");
            return;
        }

        var quarterMonthIds = [];
        var quarterPeriodSearch = search.create({
            type: "accountingperiod",
            filters: [
                ["parent", "anyof", selectedQuarter],
                "AND",
                ["startdate", "onorbefore", selectedStartDate],
                "AND",
                ["isquarter", "is", "F"],
                "AND",
                ["isyear", "is", "F"]
            ],
            columns: [
                search.createColumn({ name: "startdate", sort: search.Sort.ASC }),
                search.createColumn({ name: "internalid" })
            ]
        });

        quarterPeriodSearch.run().each(function (result) {
            var quarterMonths = result.getValue({ name: "internalid" });
            quarterMonthIds.push(quarterMonths);
            return true; // Continue iterating
        });

        return {
            quarterMonthIds: quarterMonthIds,
            selectedQuarterName: selectedQuarterName,
            selectedQuarter: selectedQuarter,
            selectedQuarterFullName: selectedQuarterFullName
        };

    } catch (error) {
        log.error('Error in getQuarterMonthIds function', error);
    }
}




    function getMonthNumbersFromPeriods(periodIds) {
        try{
        var monthNumbers = [];
        var periodSearch = search.create({
            type: 'accountingperiod',
            filters: [['internalid', 'anyof', periodIds]],
            columns: ['startdate']
        });
        periodSearch.run().each(function (result) {
            var startDate = result.getValue('startdate');
            var parsedDate = format.parse({
                value: startDate,
                type: format.Type.DATE
            });

            // Get proper JS Date object
            var jsDate = new Date(parsedDate);

            // Get 1-based month (1-12)
            var month = jsDate.getMonth() + 1;
            log.debug("month from function", month)
            monthNumbers.push(month);
            return true;
        });
        return monthNumbers;
    }
    catch (error) {
            log.error('Error in getMonthNumbersFromPeriods function', error);
            
        }
    }



    function getPreviousYearAccountingPeriod(currentPeriodId) {
        try{
        var accountingperiodSearchObj = search.create({
            type: "accountingperiod",
            filters: [
                ["internalid", "anyof", currentPeriodId]
            ],
            columns: [
                search.createColumn({ name: "periodname", label: "Name" })
            ]
        });

        var previousYearPeriodName;

        accountingperiodSearchObj.run().each(function (result) {
            var periodName = result.getValue("periodname"); // e.g., "Apr 2024"
            var parts = periodName.split(" "); // ["Apr", "2024"]
            if (parts.length === 2) {
                var month = parts[0]; // "Apr"
                var year = parseInt(parts[1]); // 2024
                var prevYear = year - 1; // 2023

                previousYearPeriodName = month + " " + prevYear; // "Apr 2023"
            }
            return false; // Exit after the first record
        });

        if (previousYearPeriodName) {
            var prevYearSearchObj = search.create({
                type: "accountingperiod",
                filters: [
                    ["periodname", "is", previousYearPeriodName] // Search for "Apr 2023"
                ],
                columns: [
                    search.createColumn({ name: "internalid", label: "Internal ID" })
                ]
            });

            var prevYearInternalId = null;
            prevYearSearchObj.run().each(function (result) {
                prevYearInternalId = result.getValue("internalid");
                log.debug("Previous Year Period Internal ID", prevYearInternalId);

                return false; // Stop after first match
            });

            return prevYearInternalId;
        }

        return null;
    }
     catch (error) {
            log.error('Error in getPreviousYearAccountingPeriod function', error);
            
        }
    }

    /**
     * Get existing records where reports are not yet generated
     */
    function existingAndFilesNotGeneratedRecords(subsidiary, accountingPeriod) {
        try{
        var existingAndFilesNotGeneratedRecords = [];

        var customrecord_sut_report_table_SearchObj = search.create({
            type: "customrecord_sut_report_table_",
            filters: [
                ["custrecord_report_subs_hier_", "anyof", subsidiary],
                "AND",
                ["custrecord_report_acc_period_", "anyof", accountingPeriod],
                "AND",
                ["isinactive", "is", "F"]
            ],
            columns: [
                search.createColumn({ name: "internalid" }),
                search.createColumn({ name: "custrecord_report_subs_hier_" }),
                search.createColumn({ name: "custrecord_report_acc_period_" }),
                search.createColumn({ name: "custrecord_monthl_rep_gen_" }),
                search.createColumn({ name: "custrecord_qtd_rep_gen_" }),
                search.createColumn({ name: "custrecord_yearly_report_chk_" }),
                search.createColumn({ name: "custrecord_full_year_rpt_chk_" }),
                search.createColumn({ name: "custrecord_act_vs_aop_db_gen_" })
            ]
        });

        var pagedData = customrecord_sut_report_table_SearchObj.runPaged({ pageSize: 1000 });
        log.debug("Total Results (Not Generated)", pagedData.count);

        for (var i = 0; i < pagedData.pageRanges.length; i++) {
            var page = pagedData.fetch({ index: i });

            page.data.forEach(function (result) {
                existingAndFilesNotGeneratedRecords.push(result.getValue({ name: 'internalid' }));
            });

            log.debug("Page " + (i + 1) + " processed",
                "Collected so far: " + existingAndFilesNotGeneratedRecords.length);
        }

        return existingAndFilesNotGeneratedRecords;
    }
     catch (error) {
            log.error('Error in existingAndFilesNotGeneratedRecords function', error);
            
        }
}


    /**
     * Get existing records where reports are fully generated
     */
    function existingAndFilesGeneratedRecords(subsidiary, accountingPeriod) {
        try{
        var existingAndFilesGeneratedRecords = [];

        var customrecord_sut_report_table_SearchObj = search.create({
            type: "customrecord_sut_report_table_",
            filters: [
                ["custrecord_report_subs_hier_", "anyof", subsidiary],
                "AND",
                ["custrecord_report_acc_period_", "anyof", accountingPeriod],
                "AND",
                [
                    ["custrecord_monthl_rep_gen_", "is", "T"],
                    "AND", ["custrecord_qtd_rep_gen_", "is", "T"],
                    "AND", ["custrecord_yearly_report_chk_", "is", "T"],
                    "AND", ["custrecord_full_year_rpt_chk_", "is", "T"],
                    "AND", ["custrecord_act_vs_aop_db_gen_", "is", "T"]
                ]
            ],
            columns: [
                search.createColumn({ name: "internalid" }),
                search.createColumn({ name: "custrecord_report_subs_hier_" }),
                search.createColumn({ name: "custrecord_report_acc_period_" }),
                search.createColumn({ name: "custrecord_monthly_report_doc_" }),
                search.createColumn({ name: "custrecord_quarter_report_" }),
                search.createColumn({ name: "custrecord_year_to_date_report_" }),
                search.createColumn({ name: "custrecord_full_year_report" }),
                search.createColumn({ name: "custrecord_full_dashboard_report_doc_" }),
                search.createColumn({ name: "custrecord_monthl_rep_gen_" }),
                search.createColumn({ name: "custrecord_qtd_rep_gen_" }),
                search.createColumn({ name: "custrecord_yearly_report_chk_" }),
                search.createColumn({ name: "custrecord_full_year_rpt_chk_" }),
                search.createColumn({ name: "custrecord_act_vs_aop_db_gen_" })
            ]
        });

        var pagedData = customrecord_sut_report_table_SearchObj.runPaged({ pageSize: 1000 });
        log.debug("Total Results (Generated)", pagedData.count);

        for (var i = 0; i < pagedData.pageRanges.length; i++) {
            var page = pagedData.fetch({ index: i });

            page.data.forEach(function (result) {
                existingAndFilesGeneratedRecords.push(result.getValue({ name: 'internalid' }));
            });

            log.debug("Page " + (i + 1) + " processed",
                "Collected so far: " + existingAndFilesGeneratedRecords.length);
        }

        return existingAndFilesGeneratedRecords;
    }
     catch (error) {
            log.error('Error in existingAndFilesGeneratedRecords function', error);
            
        }
    }


    /**
     * Check if record exists for subsidiary + accountingPeriod
     */
    function recordNotExistCheck(subsidiary, accountingPeriod) {
        try{

        var customrecord_sut_report_table_SearchObj = search.create({
            type: "customrecord_sut_report_table_",
            filters: [
                ["custrecord_report_subs_hier_", "anyof", subsidiary],
                "AND",
                ["custrecord_report_acc_period_", "anyof", accountingPeriod]
            ],
            columns: [
                search.createColumn({ name: "internalid" })
            ]
        });

        var searchResultCount = customrecord_sut_report_table_SearchObj.runPaged().count;
        return searchResultCount; // 0 means no record exists
    }
    catch (error) {
            log.error('Error in recordNotExistCheck function', error);
            
        }
    }

    function getFirstQuarterAllMonthsData(selectedQuarterFullName, aprilId, subsidiaryChildPlaceHolders, subsidiaryIds) {
        try{
        log.debug("selectedQuarterFullName", selectedQuarterFullName)


        var selectedQuarterYear = selectedQuarterFullName.split(" ")[1]; // e.g., "2024"

        var previousQuarter = `Q1 ${selectedQuarterYear}`;

        log.debug("Previous Quarter", previousQuarter);
        var quarterInternalId = 0

        var quarterIdSearch = search.create({
            type: "accountingperiod",
            filters:
                [
                    ["isquarter", "is", "T"],
                    "AND",
                    ["periodname", "is", previousQuarter]
                ],
            columns:
                [
                    search.createColumn({ name: "periodname", label: "Name" }),
                    search.createColumn({ name: "internalid", label: "Internal ID" })
                ]
        });
        var searchResultCount = quarterIdSearch.runPaged().count;

        log.debug("quarterIdSearch result count", searchResultCount);
        quarterIdSearch.run().each(function (result) {
            quarterInternalId = result.getValue({ name: "internalid" })
            return false;
        });

        var accountingperiodSearchObj = search.create({
            type: "accountingperiod",
            filters:
                [
                    ["isquarter", "is", "F"],
                    "AND",
                    ["parent", "anyof", quarterInternalId]
                ],
            columns:
                [
                    search.createColumn({ name: "internalid", label: "Internal ID" })
                ]
        });
        var previousQuarterInternalIds = []
        var searchResultCount = accountingperiodSearchObj.runPaged().count;
        log.debug("accountingperiodSearchObj result count", searchResultCount);
        accountingperiodSearchObj.run().each(function (result) {
            previousQuarterInternalIds.push(result.getValue({ name: "internalid" }))
            return true;
        });

        log.debug("previous quarter months internal ids", previousQuarterInternalIds)


        var periodPlaceholders = previousQuarterInternalIds.map(() => '?').join(',');
        log.debug("periodPlaceholders", periodPlaceholders)




        var qClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders}) 
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;
`;

        log.debug("previos qt int", previousQuarterInternalIds)
        log.debug("placeholders", periodPlaceholders)
        log.debug("subsidiaryIds", subsidiaryIds)
        log.debug("subsidiary pl", subsidiaryChildPlaceHolders)

        var qClientResults;

                if((subsidiaryIds.length>0)&&(previousQuarterInternalIds.length>0) && (periodPlaceholders.length>0) && (subsidiaryChildPlaceHolders.length>0)){
         qClientResults = query.runSuiteQL({
            query: qClientQuery,
            params: [...previousQuarterInternalIds, ...subsidiaryIds]
        }).asMappedResults();
    }
    else{
        qClientResults=[]
    }
        log.debug("client results quarter", JSON.stringify(qClientResults))
        var qaprilExistingClientsQueryResults;
        var qaprilExistingClientsQuery;


        qaprilExistingClientsQuery = `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    -- AOP data from budgets
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary

    UNION ALL

    -- Actuals data from custom record
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;`

        var existingParams = [aprilId, ...subsidiaryIds]
        log.debug("existing params", existingParams)

    if((subsidiaryIds.length>0)&&(aprilId!=null) && (subsidiaryChildPlaceHolders.length>0)){


        qaprilExistingClientsQueryResults = query.runSuiteQL({
            query: qaprilExistingClientsQuery,
            params: existingParams
        }).asMappedResults();


    }
    else{
        qaprilExistingClientsQueryResults=[]
    }
        var qnewClientsAop = 0
        var qattritionAop = 0
        var qexistingAop = 0
        var qexistingAct = 0;
        var qattritionAct = 0;
        var qnewClientsAct = 0;

        var qtotalClientsAct = 0
        var qtotalClientsAop = 0

        if (qClientResults) {
            qClientResults.forEach(row => {
                qnewClientsAct += Number(row.newclient_actuals1) || 0;
                qattritionAct += Number(row.attrition_actuals1) || 0;
                qnewClientsAop += Number(row.newclients_aop1) || 0;
                qattritionAop += Number(row.attrition_aop1) || 0;
            });

            // var isNewClientsNegative = qnewClientsAct < 0 && qnewClientsAop < 0;
            // var isAttritionNegative = qattritionAct < 0 && qattritionAop < 0;

            // if (isNewClientsNegative) {
            //     qnewClientsAct = (qnewClientsAct);
            //     qnewClientsAop = (qnewClientsAop);
            // }
            // if (isAttritionNegative) {
            //     qattritionAct = (qattritionAct);
            //     qattritionAop = (qattritionAop);
            // }


            qaprilExistingClientsQueryResults.forEach(row => {
                qexistingAct += Number(row.existing_actuals1) || 0;
                qexistingAop += Number(row.existing_aop1) || 0;
            });

            log.debug("qnewClientsAct", qnewClientsAct)
            log.debug("qattritionAct", qattritionAct)
            log.debug("qexistingAct", qexistingAct)

            log.debug("qnewClientsAop", qnewClientsAop)
            log.debug("qattritionAop", qattritionAop)
            log.debug("qexistingAop", qexistingAop)
            qtotalClientsAct = (qnewClientsAct || 0) + (qattritionAct || 0) + (qexistingAct || 0);
            qtotalClientsAop = (qnewClientsAop || 0) + (qattritionAop || 0) + (qexistingAop || 0);
        }

        return ({ q1closingbalanceAct: qtotalClientsAct, q1closingbalanceAop: qtotalClientsAop })

    }
     catch (error) {
            log.error('Error in getFirstQuarterAllMonthsData function', error);
            
        }
    }




    function getSecondQuarterAllMonthsData(selectedQuarterFullName, q1closingbalanceAct, q1closingbalanceAop, subsidiaryChildPlaceHolders, subsidiaryIds) {
        try{
        log.debug("selectedQuarterFullName", selectedQuarterFullName)

        var selectedQuarterYear = selectedQuarterFullName.split(" ")[1]; // e.g., "2024"



        var previousQuarter = `Q2 ${selectedQuarterYear}`;

        log.debug("Previous Quarter", previousQuarter);
        var quarterInternalId = 0

        var quarterIdSearch = search.create({
            type: "accountingperiod",
            filters:
                [
                    ["isquarter", "is", "T"],
                    "AND",
                    ["periodname", "is", previousQuarter]
                ],
            columns:
                [
                    search.createColumn({ name: "periodname", label: "Name" }),
                    search.createColumn({ name: "internalid", label: "Internal ID" })
                ]
        });
        var searchResultCount = quarterIdSearch.runPaged().count;

        log.debug("quarterIdSearch result count", searchResultCount);
        quarterIdSearch.run().each(function (result) {
            quarterInternalId = result.getValue({ name: "internalid" })
            return false;
        });

        var accountingperiodSearchObj = search.create({
            type: "accountingperiod",
            filters:
                [
                    ["isquarter", "is", "F"],
                    "AND",
                    ["parent", "anyof", quarterInternalId]
                ],
            columns:
                [
                    search.createColumn({ name: "internalid", label: "Internal ID" })
                ]
        });
        var previousQuarterInternalIds = []
        var searchResultCount = accountingperiodSearchObj.runPaged().count;
        log.debug("accountingperiodSearchObj result count", searchResultCount);
        accountingperiodSearchObj.run().each(function (result) {
            previousQuarterInternalIds.push(result.getValue({ name: "internalid" }))
            return true;
        });

        log.debug("previous quarter months internal ids", previousQuarterInternalIds)

        var periodPlaceholders = previousQuarterInternalIds.map(() => '?').join(',');




        var qClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;
`;

        var aprilExistingClientsQuery = `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    -- AOP data from budgets
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary

    UNION ALL

    -- Actuals data from custom record
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;
`


        var prev_params = [...previousQuarterInternalIds, ...subsidiaryIds]
        log.debug("prev params", prev_params)
        log.debug("period placeholders", periodPlaceholders)
        log.debug("subsidiary child placeholders", subsidiaryChildPlaceHolders)
        var qClientResults;
        

 if((previousQuarterInternalIds.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         qClientResults = query.runSuiteQL({
            query: qClientQuery,
            params: prev_params
        }).asMappedResults();

    }
    else{
        qClientResults=[]
    }
        log.debug("client results quarter", JSON.stringify(qClientResults))
        var qaprilExistingClientsQueryResults;
        var qaprilExistingClientsQuery;


        //          qaprilExistingClientsQuery = `select z.period, sum(z.Existing_AOP) as existing_aop1, sum(z.Existing_actuals) as existing_actuals1  from (
        //  select  bm.period ,
        //  sum(bm.amount)  as Existing_AOP,  0 as Existing_actuals
        //  from budgetsmachine bm join budgets b on  bm.budget=b.id  join account a on a.id=b.account 
        //  where 
        //  b.category=4 
        //  --and bm.period in (483)
        //  and a.id=2311
        //  group by 
        //  a.displaynamewithhierarchy, bm.period
        //  union all
        //  select  custrecord_tyfone_date_dashboard  as period, 0 as Existing_AOP, 
        //      custrecord_ty_existing_clientdata_report as Existing_actuals
        //      from CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT 
        //  --where custrecord_tyfone_date_dashboard in (483)
        //  ) z
        //  where z.period = ?
        //  group by z.period`




        //          qaprilExistingClientsQueryResults = query.runSuiteQL({
        //              query: qaprilExistingClientsQuery,
        //              params: [juneId]
        //          }).asMappedResults();



        var qnewClientsAop = 0
        var qattritionAop = 0
        var qexistingAop = 0
        var qexistingAct = 0;
        var qattritionAct = 0;
        var qnewClientsAct = 0;

        var qtotalClientsAct = 0
        var qtotalClientsAop = 0

        if (qClientResults) {
            qClientResults.forEach(row => {
                qnewClientsAct += Number(row.newclient_actuals1) || 0;
                qattritionAct += Number(row.attrition_actuals1) || 0;
                qnewClientsAop += Number(row.newclients_aop1) || 0;
                qattritionAop += Number(row.attrition_aop1) || 0;
            });

            //  qaprilExistingClientsQueryResults.forEach(row => {
            //      qexistingAct = Number(row.existing_actuals1) || 0;
            //      qexistingAop = Number(row.existing_aop1) || 0;

            //  });


            var isNewClientsNegative = qnewClientsAct < 0 && qnewClientsAop < 0;
            var isAttritionNegative = qattritionAct < 0 && qattritionAop < 0;

            if (isNewClientsNegative) {
                qnewClientsAct = (qnewClientsAct);
                qnewClientsAop = (qnewClientsAop);
            }
            if (isAttritionNegative) {
                qattritionAct = (qattritionAct);
                qattritionAop = (qattritionAop);
            }

            qexistingAct = q1closingbalanceAct;
            qexistingAop = q1closingbalanceAop;

            qtotalClientsAct = (qnewClientsAct || 0) + (qattritionAct || 0) + (qexistingAct || 0);
            qtotalClientsAop = (qnewClientsAop || 0) + (qattritionAop || 0) + (qexistingAop || 0);
        }

        return ({ q2closingbalanceAct: qtotalClientsAct, q2closingbalanceAop: qtotalClientsAop })
    }
     catch (error) {
            log.error('Error in getSecondQuarterAllMonthsData function', error);
            
        }
    }

    function getThirdQuarterAllMonthsData(selectedQuarterFullName, q2closingbalanceAct, q2closingbalanceAop, subsidiaryChildPlaceHolders, subsidiaryIds) {
        try{
        log.debug("selectedQuarterFullName", selectedQuarterFullName);

        var selectedQuarterYear = selectedQuarterFullName.split(" ")[1]; // e.g., "2024"

        var previousQuarter = `Q3 ${selectedQuarterYear}`;

        log.debug("Previous Quarter", previousQuarter);
        var quarterInternalId = 0;

        var quarterIdSearch = search.create({
            type: "accountingperiod",
            filters: [
                ["isquarter", "is", "T"],
                "AND",
                ["periodname", "is", previousQuarter]
            ],
            columns: [
                search.createColumn({ name: "periodname", label: "Name" }),
                search.createColumn({ name: "internalid", label: "Internal ID" })
            ]
        });
        var searchResultCount = quarterIdSearch.runPaged().count;

        log.debug("quarterIdSearch result count", searchResultCount);
        quarterIdSearch.run().each(function (result) {
            quarterInternalId = result.getValue({ name: "internalid" });
            return false;
        });

        var accountingperiodSearchObj = search.create({
            type: "accountingperiod",
            filters: [
                ["isquarter", "is", "F"],
                "AND",
                ["parent", "anyof", quarterInternalId]
            ],
            columns: [
                search.createColumn({ name: "internalid", label: "Internal ID" })
            ]
        });
        var previousQuarterInternalIds = [];
        var searchResultCount = accountingperiodSearchObj.runPaged().count;
        log.debug("accountingperiodSearchObj result count", searchResultCount);
        accountingperiodSearchObj.run().each(function (result) {
            previousQuarterInternalIds.push(result.getValue({ name: "internalid" }));
            return true;
        });

        log.debug("previous quarter internal id for q3", previousQuarterInternalIds);

        var periodPlaceholders = previousQuarterInternalIds.map(() => '?').join(',');

        var qClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;
`;

        var aprilExistingClientsQuery = `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    -- AOP data from budgets
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary

    UNION ALL

    -- Actuals data from custom record
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;`;
var qClientResults;
if((subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         qClientResults = query.runSuiteQL({
            query: qClientQuery,
            params: [...previousQuarterInternalIds, ...subsidiaryIds]
        }).asMappedResults();
    }
    else{
        qClientResults=[]
    }

        log.debug("client results quarter third quarter function part", JSON.stringify(qClientResults));

        var qnewClientsAop = 0;
        var qattritionAop = 0;
        var qexistingAop = 0;
        var qexistingAct = 0;
        var qattritionAct = 0;
        var qnewClientsAct = 0;
        var qtotalClientsAct = 0;
        var qtotalClientsAop = 0;

        if (qClientResults) {
            qClientResults.forEach(row => {
                qnewClientsAct += parseInt(row.newclient_actuals1) || 0;
                qattritionAct += parseInt(row.attrition_actuals1) || 0;
                qnewClientsAop += parseInt(row.newclients_aop1) || 0;
                qattritionAop += parseInt(row.attrition_aop1) || 0;
            });
            log.debug("q2closingbalanceAct before assigning", q2closingbalanceAct);

            qexistingAct = parseInt(q2closingbalanceAct);

            log.debug("q2closingbalanceAop before assigning", q2closingbalanceAop);
            qexistingAop = parseInt(q2closingbalanceAop);

            log.debug("q2closingbalanceAop after assigning", qexistingAop);
            log.debug("qnewClientsAct", qnewClientsAct);
            log.debug("qattritionAct", qattritionAct);
            log.debug("qexistingAct", qexistingAct);
            log.debug("qnewClientsAop", qnewClientsAop);
            log.debug("qattritionAop", qattritionAop);
            log.debug("qexistingAop", qexistingAop);

            qtotalClientsAct = (parseInt(qexistingAct) || 0) + (parseInt(qnewClientsAct) || 0) + (parseInt(qattritionAct) || 0);
            qtotalClientsAop = (parseInt(qexistingAop) || 0) + (parseInt(qnewClientsAop) || 0) + (parseInt(qattritionAop) || 0);
        }

        return { q3closingbalanceAct: qtotalClientsAct, q3closingbalanceAop: qtotalClientsAop };
    }
     catch (error) {
            log.error('Error in getThirdQuarterAllMonthsData function', error);
            
        }
    }

    function getClientQueryResultsQ1(periodPlaceholders, stringArray, aprilId, subsidiaryChildPlaceHolders, subsidiaryIds) {
try{

        var qClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;`;
  var qClientResults;
 

 if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         qClientResults = query.runSuiteQL({
            query: qClientQuery,
            params: [...stringArray, ...subsidiaryIds]
        }).asMappedResults();
    }
    else{
        qClientResults=[]
    }
        log.debug("client results quarter", JSON.stringify(qClientResults))
        var qaprilExistingClientsQueryResults;
        var qaprilExistingClientsQuery;


        qaprilExistingClientsQuery = `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    -- AOP data from budgets
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary

    UNION ALL

    -- Actuals data from custom record
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;
`
        var arrNetQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  -- Budget data
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Custom record data
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
 z.period = ? and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;`


        log.debug("period placeholders", periodPlaceholders)
        log.debug("subsidiary child placeholders", subsidiaryChildPlaceHolders)
        log.debug("string array", stringArray)
        log.debug("subsidiary hierarchy child arr", subsidiaryIds)





 if((aprilId!=null) && (subsidiaryIds.length>0) &&  (subsidiaryChildPlaceHolders.length>0)){
        qaprilExistingClientsQueryResults = query.runSuiteQL({
            query: qaprilExistingClientsQuery,
            params: [aprilId, ...subsidiaryIds]
        }).asMappedResults();

    }
    else{
        qaprilExistingClientsQueryResults=[]
    }

        var qnewClientsAop = 0
        var qattritionAop = 0
        var qexistingAop = 0
        var qexistingAct = 0;
        var qattritionAct = 0;
        var qnewClientsAct = 0;

        var qtotalClientsAct = 0
        var qtotalClientsAop = 0

        if (qClientResults) {
            qClientResults.forEach(row => {
                qnewClientsAct += Number(row.newclient_actuals1) || 0;
                qattritionAct += Number(row.attrition_actuals1) || 0;
                qnewClientsAop += Number(row.newclients_aop1) || 0;
                qattritionAop += Number(row.attrition_aop1) || 0;
            });

            qaprilExistingClientsQueryResults.forEach(row => {
                qexistingAct += Number(row.existing_actuals1) || 0;
                log.debug("adding value actuals", row.existing_actuals1)
                qexistingAop += Number(row.existing_aop1) || 0;
            });

            qtotalClientsAct = (qnewClientsAct || 0) + (qattritionAct || 0) + (qexistingAct || 0);
            qtotalClientsAop = (qnewClientsAop || 0) + (qattritionAop || 0) + (qexistingAop || 0);
        }

        return ({ qnewClientsAct: qnewClientsAct, qattritionAct: qattritionAct, qnewClientsAop: qnewClientsAop, qattritionAop: qattritionAop, qexistingAct: qexistingAct, qexistingAop: qexistingAop, qtotalClientsAct: qtotalClientsAct, qtotalClientsAop: qtotalClientsAop });
    }
    catch (error) {
            log.error('Error in getClientQueryResultsQ1 function', error);
            
        }
}



    function getQuarterClientsDataQ2(periodPlaceholders, stringArray, q1closingbalanceAct, q1closingbalanceAop, subsidiaryIds, subsidiaryChildPlaceHolders) {
        try{

        var qClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;`;
        log.debug("period placeholders", periodPlaceholders)
        log.debug("subsidiary child placeholders", subsidiaryChildPlaceHolders)
        log.debug("string array", stringArray)
        log.debug("subsidiary hierarchy child arr", subsidiaryIds)
        var qClientResults;


 if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){         qClientResults = query.runSuiteQL({
            query: qClientQuery,
            params: [...stringArray, ...subsidiaryIds]
        }).asMappedResults();
    }
    else{
        qClientResults=[]
    }

        log.debug("client results quarter", JSON.stringify(qClientResults))
        //         var qaprilExistingClientsQueryResults;
        //         var qaprilExistingClientsQuery;


        //         qaprilExistingClientsQuery = `select z.period, sum(z.Existing_AOP) as existing_aop1, sum(z.Existing_actuals) as existing_actuals1  from (
        // select  bm.period ,
        // sum(bm.amount)  as Existing_AOP,  0 as Existing_actuals
        // from budgetsmachine bm join budgets b on  bm.budget=b.id  join account a on a.id=b.account 
        // where 
        // b.category=4 
        // --and bm.period in (483)
        // and a.id=2311
        // group by 
        // a.displaynamewithhierarchy, bm.period
        // union all
        // select  custrecord_tyfone_date_dashboard  as period, 0 as Existing_AOP, 
        //     custrecord_ty_existing_clientdata_report as Existing_actuals
        //     from CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT 
        // --where custrecord_tyfone_date_dashboard in (483)
        // ) z
        // where z.period = ?
        // group by z.period`




        // qaprilExistingClientsQueryResults = query.runSuiteQL({
        //     query: qaprilExistingClientsQuery,
        //     params: [aprilId]
        // }).asMappedResults();



        var qnewClientsAop = 0
        var qattritionAop = 0
        var qexistingAop = 0
        var qexistingAct = 0;
        var qattritionAct = 0;
        var qnewClientsAct = 0;

        if (qClientResults) {
            qClientResults.forEach(row => {
                qnewClientsAct += Number(row.newclient_actuals1) || 0;
                qattritionAct += Number(row.attrition_actuals1) || 0;
                qnewClientsAop += Number(row.newclients_aop1) || 0;
                qattritionAop += Number(row.attrition_aop1) || 0;
            });

            // qaprilExistingClientsQueryResults.forEach(row => {
            //     qexistingAct = Number(row.existing_actuals1) || 0;
            //     qexistingAop = Number(row.existing_aop1) || 0;
            // });

            qexistingAct = q1closingbalanceAct;
            log.debug("existing actuals in q2 from q1", qexistingAct)
            qexistingAop = q1closingbalanceAop;

            // qtotalClientsActq2 = (qnewClientsAct || 0) + (qattritionAct || 0) + (qexistingAct || 0);
            // qtotalClientsAopq2 = (qnewClientsAop || 0) + (qattritionAop || 0) + (qexistingAop || 0);
            log.debug("quarter new cl actuals before adding ", qnewClientsAct)
            log.debug("quarter attrition actuals before adding ", qattritionAct)
            log.debug("quarter existing actuals before adding ", qexistingAct)

            qtotalClientsActq2 = (qnewClientsAct || 0) + (qattritionAct || 0) + (qexistingAct || 0);

            qtotalClientsAopq2 = (qnewClientsAop || 0) + (qattritionAop || 0) + (qexistingAop || 0);

        }

        return ({ qnewClientsAct: qnewClientsAct, qattritionAct: qattritionAct, qnewClientsAop: qnewClientsAop, qattritionAop: qattritionAop, qexistingAct: qexistingAct, qexistingAop: qexistingAop, qtotalClientsActq2: qtotalClientsActq2, qtotalClientsAopq2: qtotalClientsAopq2 });
    }
     catch (error) {
            log.error('Error in getClientQueryResultsQ2 function', error);
            
        }
    }


    function getQuarterClientsDataQ3(periodPlaceholders, stringArray, q2closingbalanceAct, q2closingbalanceAop, subsidiaryIds, subsidiaryChildPlaceHolders) {
        try{
        var qClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;`;

        log.debug("period placeholders", periodPlaceholders)
        log.debug("subsidiary child placeholders", subsidiaryChildPlaceHolders)
        log.debug("string array", stringArray)
        log.debug("subsidiary hierarchy child arr", subsidiaryIds)


 if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){         qClientResults = query.runSuiteQL({
            query: qClientQuery,
            params: [...stringArray, ...subsidiaryIds]
        }).asMappedResults();
    }
    else{
        qClientResults=[]
    }
        log.debug("client results quarter q3", JSON.stringify(qClientResults));

        var qnewClientsAop = 0;
        var qattritionAop = 0;
        var qexistingAop = 0;
        var qexistingAct = 0;
        var qattritionAct = 0;
        var qnewClientsAct = 0;
        var qtotalClientsActq3 = 0;
        var qtotalClientsAopq3 = 0;

        if (qClientResults) {
            qClientResults.forEach(row => {
                qnewClientsAct += Number(row.newclient_actuals1) || 0;
                qattritionAct += Number(row.attrition_actuals1) || 0;
                qnewClientsAop += Number(row.newclients_aop1) || 0;
                qattritionAop += Number(row.attrition_aop1) || 0;
            });

            qexistingAct = q2closingbalanceAct;
            qexistingAop = q2closingbalanceAop;

            log.debug("existing actuals in q3 from q2", qexistingAct);

            log.debug("quarter new cl actuals before adding ", qnewClientsAct)
            log.debug("quarter attrition actuals before adding ", qattritionAct)
            log.debug("quarter existing actuals before adding ", qexistingAct)


            qtotalClientsActq3 = (qexistingAct || 0) + (qnewClientsAct || 0) + (qattritionAct || 0);
            qtotalClientsAopq3 = (qexistingAop || 0) + (qnewClientsAop || 0) + (qattritionAop || 0);
        }

        return {
            qnewClientsAct: qnewClientsAct,
            qattritionAct: qattritionAct,
            qnewClientsAop: qnewClientsAop,
            qattritionAop: qattritionAop,
            qexistingAct: qexistingAct,
            qexistingAop: qexistingAop,
            qtotalClientsActq3: qtotalClientsActq3,
            qtotalClientsAopq3: qtotalClientsAopq3
        };
    }
     catch (error) {
            log.error('Error in getClientQueryResultsQ3 function', error);
            
        }
    }
   
    function getQuarterClientsDataQ4(periodPlaceholders, stringArray, q3closingbalanceAct, q3closingbalanceAop, subsidiaryIds, subsidiaryChildPlaceHolders) {
        try{
        log.debug("subsidiaryIds", subsidiaryIds);
        log.debug("subsidiaryChildPlaceHolders", subsidiaryChildPlaceHolders);
        // Ensure q3 closing balances are numeric; if not, default to 0
        q3closingbalanceAct = Number(q3closingbalanceAct) || 0;
        q3closingbalanceAop = Number(q3closingbalanceAop) || 0;

        var qClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;`;

var qClientResults;
 if((stringArray.length>0) && (subsidiaryIds.length>0) && (subsidiaryChildPlaceHolders.length>0) && (periodPlaceholders.length>0)){
         qClientResults = query.runSuiteQL({
            query: qClientQuery,
            params: [...stringArray, ...subsidiaryIds]
        }).asMappedResults();
    }
    else{
        qClientResults=[]
    }

        log.debug("client results quarter", JSON.stringify(qClientResults));

        var qnewClientsAop = 0;
        var qattritionAop = 0;
        var qexistingAop = 0;
        var qexistingAct = 0;
        var qattritionAct = 0;
        var qnewClientsAct = 0;
        var qtotalClientsActq4 = 0;
        var qtotalClientsAopq4 = 0;

        if (qClientResults && Array.isArray(qClientResults)) {
            qClientResults.forEach(row => {
                qnewClientsAct += Number(row.newclient_actuals1) || 0;
                qattritionAct += Number(row.attrition_actuals1) || 0;
                qnewClientsAop += Number(row.newclients_aop1) || 0;
                qattritionAop += Number(row.attrition_aop1) || 0;
            });

            // Assign the q3 closing balances
            qexistingAct = q3closingbalanceAct;
            qexistingAop = q3closingbalanceAop;

            log.debug("existing actuals in q4 from q3", qexistingAct);

            // Calculate the totals
            qtotalClientsActq4 = (qexistingAct || 0) + (qnewClientsAct || 0) + (qattritionAct || 0);
            qtotalClientsAopq4 = (qexistingAop || 0) + (qnewClientsAop || 0) + (qattritionAop || 0);
        }

        return {
            qnewClientsAct: qnewClientsAct,
            qattritionAct: qattritionAct,
            qnewClientsAop: qnewClientsAop,
            qattritionAop: qattritionAop,
            qexistingAct: qexistingAct,
            qexistingAop: qexistingAop,
            qtotalClientsActq4: qtotalClientsActq4,
            qtotalClientsAopq4: qtotalClientsAopq4
        };
    }
    catch (error) {
            log.error('Error in getQuarterClientsDataQ4 function', error);
            
        }
    }

    

    function getPreviousQuarterMonthIds(currentQuarterName, accountingPeriod) {
        try{
        var internalIds = []
        var previousQuarter = ''
        if (!currentQuarterName.includes("q1")) {
            let quarterPart = currentQuarterName.split(" ")[0]
            let yearPart = currentQuarterName.split(" ")[1]
            let letter = quarterPart.charAt(0);      // Ex: Q2
            let number = quarterPart.substring(1);   // Ex: 2025

            let prevQuarterNum = parseInt(number) - 1;
            previousQuarter = letter + prevQuarterNum + " " + yearPart



            log.debug("previousQuarter", previousQuarter)

            var previousQuarterInternalId = 0;
            var quarterIdSearch = search.create({
                type: "accountingperiod",
                filters:
                    [
                        ["periodname", "is", previousQuarter],
                        "AND",
                        ["isquarter", "is", "T"]
                    ],
                columns:
                    [
                        search.createColumn({ name: "internalid", label: "Internal ID" })
                    ]
            });
            var searchResultCount = quarterIdSearch.runPaged().count;
            log.debug("quarterIdSearch result count", searchResultCount);
            quarterIdSearch.run().each(function (result) {
                previousQuarterInternalId = result.getValue({ name: "internalid" })
                return true;
            });

            var accountingperiodSearchObj = search.create({
                type: "accountingperiod",
                filters:
                    [
                        ["parent", "anyof", previousQuarterInternalId],
                        "AND",
                        ["isquarter", "is", "F"]
                    ],
                columns:
                    [
                        search.createColumn({ name: "internalid", label: "Internal ID" }),
                        search.createColumn({ name: "periodname", label: "Name" }),
                        search.createColumn({ name: "startdate", label: "Start Date" })
                    ]
            });
            var searchResultCount = accountingperiodSearchObj.runPaged().count;
            log.debug("accountingperiodSearchObj result count", searchResultCount);
            accountingperiodSearchObj.run().each(function (result) {
                internalIds.push(result.getValue({ name: "internalid" }))
                return true;
            });

            log.debug("previous quarter months internalIds", internalIds);
            return internalIds;
        }
        else {
            var internalIds = getAprilId(accountingPeriod);
            return internalIds;
        }
    }
    catch (error) {
            log.error('Error in getPreviousQuarterMonthIds function', error);
            
        }
    }
    return {
        getInputData: getInputData,
        map: map,
        reduce: reduce,
        summarize: summarize
    };

})