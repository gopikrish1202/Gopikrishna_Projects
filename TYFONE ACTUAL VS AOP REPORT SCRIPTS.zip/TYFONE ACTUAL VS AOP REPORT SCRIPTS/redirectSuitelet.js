/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/query','N/file', 'N/render', 'N/log', 'N/search', 'N/record'], function (query, file, render, log, search, record) {
    function onRequest(context) {
        if (context.request.method === 'GET') {
            try {
                let fileId = context.request.parameters.fileId;
                let accountingPeriod=context.request.parameters.accountingPeriod;
                let arrPart=context.request.parameters.arrPart;
                let arrActTotal=context.request.parameters.arrActTotal;
                let arrAopTotal=context.request.parameters.arrAopTotal;
                let arrDiff=context.request.parameters.arrDiff;
                let arrPer=context.request.parameters.arrPer;
                let aprilId=context.request.parameters.aprilId;
                let monthNumber=context.request.parameters.monthNumber;
                let yearName=context.request.parameters.yearName;
                let subsidiary= context.request.parameters.subsidiary;
              

              
                log.debug("yearname from params",yearName)
                yearName=parseInt(yearName);

              log.debug("fileId",fileId)

                var subsidiaryChildsQuery = `select custrecord_subsidiary_hierarchy from customrecord_tyf_subs_hier_ where id=?`;
                    var subsidiaryChildResults = query.runSuiteQL({ query: subsidiaryChildsQuery, params: [subsidiary] }).asMappedResults();
                    log.debug("subsidiary child ids", subsidiaryChildResults);
                    var subsidiaryHierarchyChildArr = parseSubsidiaryHierarchy(subsidiaryChildResults);
                    var subsidiaryChildPlaceHolders = subsidiaryHierarchyChildArr.map(item => "?").join(",");
var fullYHtml=generateFullYearReport(accountingPeriod, arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer, aprilId, monthNumber, yearName, subsidiary, subsidiaryHierarchyChildArr, subsidiaryChildPlaceHolders) 
              var fileObj = file.load({ id: fileId });

                // Get the contents of the file
                var tableHtml = fileObj.getContents();

                if(fullYHtml){
                    tableHtml+="<div class='table-wrapper'>"+fullYHtml+"</div></table>"
                }

                 tableHtml += `</div><script>
                    function printPDF() {
    window.print();
}
     let isExpanded = false; // Track toggle state

function toggleAllRows() {
    let buttons = document.querySelectorAll('.toggle-button');
    
    buttons.forEach(button => {
        let childRowId = button.getAttribute('onclick').match(/'([^']+)'/)[1]; // Extract child row ID
        let childRow = document.getElementById(childRowId);

        if (childRow) {
            if (isExpanded) {
                childRow.style.display = 'none';
                button.textContent = '+';
            } else {
                childRow.style.display = 'table-row';
                button.textContent = '-';
            }
        }
    });

    isExpanded = !isExpanded; // Toggle state
    document.getElementById('toggleAllBtn').textContent = isExpanded ? "Collapse All" : "Expand All";
}
function toggleChild(id, btn) {
    const row = document.getElementById(id);
    const isVisible = row.style.display === 'table-row';
    row.style.display = isVisible ? 'none' : 'table-row';
    btn.textContent = isVisible ? '+' : '-';
}
</script></body></html>`;

            // Step 3: Save the updated file
                var updatedFileObj = file.create({
                    name: fileObj.name, // Retain original file name
                    fileType: fileObj.fileType, // Retain original file type (e.g., HTMLDOC)
                    contents: tableHtml, // Updated contents
                    folder: fileObj.folder // Save in the same folder
                });
              

              
                var newFileId = updatedFileObj.save();
                log.debug("Updated file saved with ID", newFileId);

              var updatedFileObj2 = file.create({
                    name: "CSV_FILE", // Retain original file name
                    fileType: file.Type.CSV,
                    contents: tableHtml, // Updated contents
                    folder: fileObj.folder, // Save in the same folder
                    encoding: file.Encoding.UTF8
                });
              var csvfile=updatedFileObj2.save()
              log.debug("saved csv",csvfile)

                // Step 4: Load the saved file again
                var reloadedFileObj = file.load({ id: newFileId });
                var updatedContents = reloadedFileObj.getContents();

                // Step 5: Write the updated file contents to the response
                context.response.write(updatedContents);  
              


                

            } catch (error) {
                log.error({ title: 'Error Generating PDF', details: error });
                context.response.write('Error processing the file.');
            }
        }
    }


 function parseSubsidiaryHierarchy(results) {
        // Check if we have at least one result
        if (results.length === 0) {
          return [];
        }
        
        // Get the CSV string from the first record (adjust if needed for your use case)
        const csvString = results[0].custrecord_subsidiary_hierarchy;
      
        // Split the string on commas, trim extra spaces, and convert each string to a number.
        const numberArray = csvString.split(',')
                                     .map(value => value.trim())
                                     .map(value => Number(value)); // Or use parseInt(value, 10) if you expect integers
        
        return numberArray;

      }
      var departmentIds=[]


      function generateFullYearReport(accountingPeriod, arrPart, arrActTotal, arrAopTotal, arrDiff, arrPer, aprilId, monthNumber, yearName, subsidiary, subsidiaryHierarchyChildArr, subsidiaryChildPlaceHolders) {
        var fullYMappedResults;
        var financialYearMonthsFullYFunction = getFinancialYearMonthsFullYear(accountingPeriod);

    var financialYearMonthsFullY=financialYearMonthsFullYFunction.monthIds;
    var financialYearName=financialYearMonthsFullYFunction.financialYearName;

        // var fullYMonthNumbers = getMonthNumbersFromPeriods(financialYearMonthsFullY);
        // log.debug("fullY month numbers", fullYMonthNumbers)
        // var fullYPlaceHolders = fullYMonthNumbers.map(() => '?').join(',');

        
 // Convert to string array
 var stringArray = [];


 for (var i = 0; i < financialYearMonthsFullY.length; i++) {
     stringArray.push(financialYearMonthsFullY[i].toString());
 }
 
 var periodPlaceholders = stringArray.map(() => '?').join(',');



 var previousMonthsPlaceHolders;

 var previousYearsMonths=getPreviousYearAccountingPeriods(stringArray);
 if(previousYearsMonths){
  previousMonthsPlaceHolders = previousYearsMonths.map(() => '?').join(',');

 }




 var monthIdArray=[];
 monthIdArray.push(monthNumber);


    var clientParams=[
            ...stringArray,
            ...subsidiaryHierarchyChildArr
        ]
        
        // var fullYNetNewBookings = (fullYNetResults[0].total || 0)
        var fullYClientQuery = `SELECT 
  z.period, 
  SUM(z.Existing_AOP) AS existing_aop1, 
  SUM(z.Newclients_AOP) AS newclients_aop1, 
  SUM(z.Attrition_AOP) AS attrition_aop1,
  SUM(z.NewClients_actuals) AS newclient_actuals1, 
  SUM(z.Attrition_actuals) AS attrition_actuals1, 
  SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
  
  -- Existing AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    SUM(bm.amount) AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2311
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- New Clients AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    SUM(bm.amount) AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2309
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Attrition AOP
  SELECT  
    bm.period, 
    b.subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    SUM(bm.amount) AS Attrition_AOP, 
    0 AS NewClients_actuals, 
    0 AS Attrition_actuals, 
    0 AS Existing_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2310
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from custom record
  SELECT  
    custrecord_tyfone_date_dashboard AS period, 
    custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
    0 AS Existing_AOP,  
    0 AS Newclients_AOP, 
    0 AS Attrition_AOP, 
    custrecord_ty_newclients_clientdata_repo AS NewClients_actuals,
    custrecord_ty_attrition_clientdata_repo AS Attrition_actuals, 
    custrecord_ty_existing_clientdata_report AS Existing_actuals
  FROM CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
  z.period in (${periodPlaceholders})
  AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period, 
  z.subsidiary;`
            
        
        let fullYClientResults = query.runSuiteQL({
            query: fullYClientQuery,
            params: clientParams
        }).asMappedResults();
        

        
        
        
        
        
        
        
        let fullYnewClientsAop = 0
        let fullYattritionAop = 0
        let fullYexistingAop = 0
        let fullYexistingAct=0;
        let fullYattritionAct=0;
        let fullYnewClientsAct=0;
        
        let fullYtotalClientsAct=0
        let fullYtotalClientsAop=0


        let fullYaprilExistingClientsQuery= `SELECT 
    z.period, 
    z.subsidiary,
    SUM(z.Existing_AOP) AS existing_aop1, 
    SUM(z.Existing_actuals) AS existing_actuals1  
FROM (
    -- AOP data from budgets
    SELECT  
        bm.period, 
        b.subsidiary,
        SUM(bm.amount) AS Existing_AOP,  
        0 AS Existing_actuals
    FROM 
        budgetsmachine bm 
        JOIN budgets b ON bm.budget = b.id  
        JOIN account a ON a.id = b.account 
    WHERE 
        b.category = 4  
        AND a.id = 2311
    GROUP BY 
        bm.period, b.subsidiary

    UNION ALL

    -- Actuals data from custom record
    SELECT  
        custrecord_tyfone_date_dashboard AS period,  
        custrecord_tyfone_subsidiary_dashboard1 AS subsidiary,
        0 AS Existing_AOP,  
        custrecord_ty_existing_clientdata_report AS Existing_actuals
    FROM 
        CUSTOMRECORD_TYFONE_CLIENT_DATA_REPORT
) z
WHERE 
    z.period = ?
    AND z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.period, z.subsidiary;
`
              let arrNetQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  -- Budget data
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Custom record data
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
 z.period in (${periodPlaceholders}) and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;`


        let fullYaprilExistingClientsQueryResults=query.runSuiteQL({
            query: fullYaprilExistingClientsQuery,
            params: [aprilId, ...subsidiaryHierarchyChildArr]
        }).asMappedResults();
        
        
        
        fullYClientResults.forEach(row => {
            fullYnewClientsAct += Number(row.newclient_actuals1) || 0;
        
            fullYattritionAct += Number(row.attrition_actuals1) || 0;

        
           
            fullYnewClientsAop +=Number(row.newclients_aop1) || 0;
          
        
            fullYattritionAop +=Number(row.attrition_aop1) || 0;
        
        
        });
        
      
        
        
        fullYaprilExistingClientsQueryResults.forEach(row => {
            fullYexistingAct+= Number(row.existing_actuals1)
            fullYexistingAop+= Number(row.existing_aop1)
        
        })
        
        fullYtotalClientsAct=fullYnewClientsAct+fullYattritionAct+fullYexistingAct
        fullYtotalClientsAop=fullYnewClientsAop+fullYattritionAop+fullYexistingAop
        
        
        var fullYsalesAndMarketing = 0;
        var fullYproduct = 0;
        var fullYgeneraladmin = 0;
        var fullYcustomersuccess = 0;
        var fullYrandd = 0;
        var fullYprofservices = 0;
    
        var fullYheadCountQuery = `SELECT 
  period,  
  SUM(z.SM_HC_aop) AS SM_HC_aop1, 
  SUM(z.Product_HC_aop) AS Product_HC_aop1, 
  SUM(z.GA_HC_AOP) AS GA_HC_AOP1,
  SUM(z.Cs_hc_aop) AS Cs_hc_aop1, 
  SUM(z.rd_hc_aop) AS rd_hc_aop1,
  SUM(z.pso_hc_aop) AS pso_hc_aop1,
  SUM(z.salesandmarketting) AS salesandmarketting, 
  SUM(z.product) AS product1,
  SUM(z.generaladmin) AS generaladmin1,
  SUM(z.customersuccess) AS customersuccess1,
  SUM(z.randd) AS randd1,
  SUM(z.profservices) AS profservices1
FROM (

  -- SM_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    SUM(bm.amount) AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2301
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Product_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    SUM(bm.amount) AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2302
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- GA_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    SUM(bm.amount) AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2303
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- CS_HC_AOP
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    SUM(bm.amount) AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2304
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- R&D
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    SUM(bm.amount) AS rd_hc_aop, 
    0 AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2305
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- PSO
  SELECT  
    bm.period,
    b.subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    SUM(bm.amount) AS pso_hc_aop,
    0 AS salesandmarketting, 
    0 AS product,
    0 AS generaladmin,  
    0 AS customersuccess, 
    0 AS randd, 
    0 AS profservices
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE b.category = 4 AND a.id = 2306
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Actuals from Custom Record
  SELECT  
    custrecord1 AS period,
    custrecord_tyfone_subsidiary_dashboard2 AS subsidiary,
    0 AS SM_HC_aop,  
    0 AS Product_HC_aop, 
    0 AS GA_HC_AOP, 
    0 AS Cs_hc_aop, 
    0 AS rd_hc_aop, 
    0 AS pso_hc_aop,
    custrecord_ty_headcount_sal_mar AS salesandmarketting, 
    custrecord_ty_headcount_product_report AS product, 
    custrecord_ty_headcount_generaladmin AS generaladmin, 
    custrecord_ty_headcount_cust_success_ AS customersuccess, 
    custrecord_ty_headcount_rd_report AS randd, 
    custrecord_ty_headcount_profser_report AS profservices
  FROM CUSTOMRECORD_TYFONE_HEADCOUNT_REPORT

) z
WHERE 
  z.period = ?
  AND z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY 
  z.period;`
let fullYsalesAndMarketingActuals,fullYproductActuals,fullYgeneraladminActuals,fullYcustomersuccessActuals,fullYranddActuals,fullYprofservicesActuals,
fullYheadcounttotalActuals,fullYsalesAndMarketingAop,fullYproductAop,fullYgeneralAdminAop,fullYcustomersuccessAop,fullYranddAop,fullYprofservicesAop,fullYheadcounttotalAop;
    
         var fullYheadCountResults = query.runSuiteQL({ query: fullYheadCountQuery ,params: [accountingPeriod, ...subsidiaryHierarchyChildArr]}).asMappedResults();
         fullYheadCountResults.forEach(row => {
           fullYsalesAndMarketingActuals = Number(row.salesandmarketting) || 0;
           fullYproductActuals = Number(row.product1) || 0;
           fullYgeneraladminActuals = Number(row.generaladmin1) || 0;
           fullYcustomersuccessActuals = Number(row.customersuccess1) || 0;
           fullYranddActuals = Number(row.randd1) || 0;
           fullYprofservicesActuals = Number(row.profservices1) || 0;

           fullYheadcounttotalActuals=fullYsalesAndMarketingActuals+fullYproductActuals+fullYgeneraladminActuals+fullYcustomersuccessActuals+fullYranddActuals


           fullYsalesAndMarketingAop= Number(row.sm_hc_aop1) || 0;	
           fullYproductAop= Number(row.product_hc_aop1) || 0;
           fullYgeneralAdminAop= Number(row.ga_hc_aop1) || 0;
           fullYcustomersuccessAop= Number(row.cs_hc_aop1) || 0;
           fullYranddAop= Number(row.rd_hc_aop1) || 0;
           fullYprofservicesAop=Number(row.rd_hc_aop1) || 0;

           fullYheadcounttotalAop=fullYsalesAndMarketingAop+fullYproductAop+fullYgeneralAdminAop+fullYcustomersuccessAop+fullYranddAop

        });
    
        var stringArray = [];
        var replicatingArray = []
        for (var i = 0; i < financialYearMonthsFullY.length; i++) {
            stringArray.push(financialYearMonthsFullY[i].toString());
        }
        periodPlaceholders = stringArray.map(() => '?').join(',');
        log.debug("period placeholders",periodPlaceholders)
        for (var k = 0; k < stringArray.length; k++) {
            replicatingArray.push(stringArray[k]);
        }
        replicatingArray = replicatingArray.concat(replicatingArray)  //since we have to use same parameter twice in single query , creating duplication of values inside same array using self concatenation.

        
    
    
        var parentResults = [];
        var childResults = [];

var queryParams=[];



        var fullYNetNewQuery = `SELECT 
  z.period, 
  SUM(z.arr_netnew_aop) AS arr_netnew_aop1, 
  SUM(z.arr_netnew_actuals) AS arr_netnew_actuals1,
  z.subsidiary  
FROM (
  -- Budget data
  SELECT  
    bm.period,
    b.subsidiary AS subsidiary,
    SUM(bm.amount) AS arr_netnew_aop,  
    0 AS arr_netnew_actuals
  FROM budgetsmachine bm 
  JOIN budgets b ON bm.budget = b.id  
  JOIN account a ON a.id = b.account 
  WHERE 
    b.category = 4 
    AND a.id = 2307
  GROUP BY bm.period, b.subsidiary

  UNION ALL

  -- Custom record data
  SELECT  
    custrecord2 AS period, 
    custrecord_tyfone_subsidiary_dashboard3 AS subsidiary,
    0 AS arr_netnew_aop, 
    custrecord_tyfone_arrnewbooki_valu_rep AS arr_netnew_actuals
  FROM CUSTOMRECORD_TY_ARR_NEWBOOKING_REPORT
) z
WHERE 
 z.period in (${periodPlaceholders}) and z.subsidiary in (${subsidiaryChildPlaceHolders})
GROUP BY z.period, z.subsidiary;`
                    var fullYNetResults = query.runSuiteQL({ query: fullYNetNewQuery, params: clientParams }).asMappedResults();


                    let fullYnetNewAop=0;
                    let fullYnetNewActuals=0;
                    let fullYnetNewVariance=0;
                    let fullYnetNewVariancePer=0
                    let fullYnetNewActualsSum=0;
                    let fullYnetNewAopSum=0;
                    let fullYnetNewVarianceSum=0;
                    let fullYnetNewVariancePerSum=0;
            
                
                    fullYNetResults.forEach(row => {
                    fullYnetNewAop=row.arr_netnew_aop1;
                    fullYnetNewActuals=row.arr_netnew_actuals1;
                    fullYnetNewVariance=fullYnetNewActuals-fullYnetNewAop;
                    fullYnetNewVariancePer=(fullYnetNewVariance/fullYnetNewAop)*100
            
                    fullYnetNewActualsSum+=fullYnetNewActuals;
                    fullYnetNewAopSum+=fullYnetNewAop;
                    fullYnetNewVarianceSum+=fullYnetNewVariance;
                    fullYnetNewVariancePerSum+=fullYnetNewVariancePer;
            
            
                        })

                        
                        
var fullYearQueryParent = ``
var fullYearQueryChild = ``
var monthPlaceHolders=monthIdArray.map(() => '?').join(',');



if(departmentIds.length>0){

     if (monthNumber != 3) {
            log.debug("non march part")

            fullYearQueryParent = `SELECT
    z.id,
    z.Classification,
    z.name,
    ROUND(SUM(z.Actuals)) AS actuals,
    ROUND(SUM(z.AOP))     AS aop,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals) - SUM(z.AOP))
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
    END AS Variance,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.prev_Actuals) * -1)
        ELSE ROUND(SUM(z.prev_Actuals))
    END AS pre_actuals1,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals) - (SUM(z.prev_Actuals * -1)))
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals))
    END AS Pre_Variance2,
    z.custrecord_dashboard_classification
FROM (
    /* ───── Budget AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        SUM(bm.amount)          AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary            AS subsidiary,
        b.department            AS department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Current Actuals ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        SUM(bm.amount)          AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary            AS subsidiary,
        b.department            AS department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category IN (
            SELECT custrecord_ty_budget_cat
            FROM   CUSTOMRECORD_TYFONE_BUDGETCATGORYMONTHS
            WHERE  custrecord_ty_month_dashboard = ?
          )
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Previous AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        SUM(bm.amount)          AS prev_AOP,
        b.subsidiary            AS subsidiary,
        b.department            AS department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${previousMonthsPlaceHolders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Previous Actuals ───── */
    SELECT
        h.id,
        dc.name                           AS Classification,
        h.name,
        dc.id                             AS custrecord_dashboard_classification,
        0                                 AS Actuals,
        0                                 AS AOP,
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS prev_Actuals,
        0                                 AS prev_AOP,
        a.subsidiary                      AS subsidiary,
        a.department                      AS department
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading       h  ON h.id  = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        dc.id, dc.name,
        h.id, h.name,
        a.subsidiary,
        a.department
) z
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders}) AND z.department IN (${departmentPlaceHolders})
GROUP BY
    z.id,
    z.Classification,
    z.name,
    z.custrecord_dashboard_classification
ORDER BY
    z.custrecord_dashboard_classification,
    z.id;

`;
            fullYearQueryChild = `
                          SELECT
    z.id,
    z.Classification,
    z.name,
      z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,                     -- ← NEW
    ROUND(SUM(z.Actuals))              AS actuals,
    ROUND(SUM(z.AOP))                  AS aop,

    /* current variance */
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals) - SUM(z.AOP))
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
    END                                AS Variance,

    /* previous actuals (sign-flip for 1-3) */
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.prev_Actuals) * -1)
        ELSE ROUND(SUM(z.prev_Actuals))
    END                                AS pre_actuals1,

    /* variance vs. previous period */
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals)        - (SUM(z.prev_Actuals) * -1))
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals))
    END                                AS Pre_Variance2,

    z.custrecord_dashboard_classification
FROM (
    /* ───── Budget AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
          a.accountsearchdisplaynamecopy,
    a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = a.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        SUM(bm.amount)          AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary,
        b.department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY a.custrecord_dashboard1_heading_tyfone,
             a.custrecord_dashboard_classification,
             a.accountsearchdisplaynamecopy,
    a.acctnumber,
             a.custrecord_tyfone_subcategory_dashboard,          -- NEW
             b.subsidiary,
             b.department

    UNION ALL

    /* ───── Current Actuals ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
            a.accountsearchdisplaynamecopy,
    a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = a.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        a.custrecord_dashboard_classification,
        SUM(bm.amount)          AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary,
        b.department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category IN (
            SELECT custrecord_ty_budget_cat
            FROM   CUSTOMRECORD_TYFONE_BUDGETCATGORYMONTHS
            WHERE  custrecord_ty_month_dashboard = ?
          )
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY a.custrecord_dashboard1_heading_tyfone,
             a.custrecord_dashboard_classification,
                 a.accountsearchdisplaynamecopy,
    a.acctnumber,
             a.custrecord_tyfone_subcategory_dashboard,          -- NEW
             b.subsidiary,
             b.department

    UNION ALL

    /* ───── Previous AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
            a.accountsearchdisplaynamecopy,
    a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = a.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        SUM(bm.amount)          AS prev_AOP,
        b.subsidiary,
        b.department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${previousMonthsPlaceHolders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY a.custrecord_dashboard1_heading_tyfone,
             a.custrecord_dashboard_classification,
                 a.accountsearchdisplaynamecopy,
    a.acctnumber,
             a.custrecord_tyfone_subcategory_dashboard,          -- NEW
             b.subsidiary,
             b.department

    UNION ALL

    /* ───── Previous Actuals ───── */
    SELECT
        h.id,
        dc.name                             AS Classification,
        h.name,
            ac.accountsearchdisplaynamecopy,
    ac.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = ac.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        dc.id                               AS custrecord_dashboard_classification,
        0                                   AS Actuals,
        0                                   AS AOP,
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS prev_Actuals,
        0                                   AS prev_AOP,
        a.subsidiary,
        a.department
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading       h  ON h.id  = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY dc.id, dc.name, h.id, h.name,     ac.accountsearchdisplaynamecopy,
    ac.acctnumber,
             ac.custrecord_tyfone_subcategory_dashboard,          -- NEW
             a.subsidiary, a.department
) z
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders}) AND z.department IN (${departmentPlaceHolders})
GROUP BY
    z.id,
    z.Classification,
    z.name,
       z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,                     -- NEW
    z.custrecord_dashboard_classification
ORDER BY
    z.custrecord_dashboard_classification,
    z.id,
    z.subcategory;                      -- optional, keeps sort stable
`;

            queryParams = [
                ...stringArray,
                  monthNumber,
                ...stringArray,
                ...previousYearsMonths,
                ...previousYearsMonths,
                ...subsidiaryHierarchyChildArr,
                ...departmentIds
            ]

            log.debug("queryParams", queryParams)
        }
        else {
            log.debug("entered march month part")
        fullYearQueryParent = `SELECT
    z.id,
    z.Classification,
    z.name,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals * -1))
        ELSE ROUND(SUM(z.Actuals))
    END AS actuals,
    ROUND(SUM(z.AOP)) AS aop,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP))
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
    END AS Variance,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Pre_Actuals * -1))
        ELSE ROUND(SUM(z.Pre_Actuals))
    END AS pre_actuals1,
    ROUND(SUM(z.Pre_AOP)) AS Pre_aop,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals * -1) - (SUM(z.Pre_Actuals * -1)))
        ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals))
    END AS Pre_Variance2,
    z.custrecord_dashboard_classification
FROM (
    /* ───── Budget AOP ───── */
    SELECT
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0 AS Actuals,
        SUM(bm.amount) AS AOP,
        0 AS Pre_Actuals,
        0 AS Pre_AOP,
        b.subsidiary AS subsidiary,
        b.department AS department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category IN (4)
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Current Actuals ───── */
    SELECT
        (SELECT id FROM customrecord_dashboard1_heading
            WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification
            WHERE id = ac.custrecord_dashboard_classification)  AS Classification,
        (SELECT name FROM customrecord_dashboard1_heading
            WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name,
        ac.custrecord_dashboard_classification,
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS Actuals,
        0 AS AOP,
        0 AS Pre_Actuals,
        0 AS Pre_AOP,
        a.subsidiary AS subsidiary,
        a.department AS department
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON b.id = c.transaction AND a.id = c.transactionline
    JOIN account ac ON ac.id = c.account
    WHERE a.expenseaccount = ac.id
      AND b.postingperiod IN (${periodPlaceholders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        ac.custrecord_dashboard1_heading_tyfone,
        ac.custrecord_dashboard_classification,
        a.subsidiary,
        a.department

    UNION ALL

    /* ───── Previous AOP ───── */
    SELECT
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0 AS Actuals,
        0 AS AOP,
        0 AS Pre_Actuals,
        SUM(bm.amount) AS Pre_AOP,
        b.subsidiary AS subsidiary,
        b.department AS department
    FROM budgetsmachine bm
    JOIN budgets b ON bm.budget = b.id
    JOIN account a ON a.id    = b.account
    WHERE b.category = 4
      AND bm.period  IN (${previousMonthsPlaceHolders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Previous Actuals ───── */
    SELECT
        h.id,
        dc.name  AS Classification,
        h.name,
        dc.id    AS custrecord_dashboard_classification,
        0 AS Actuals,
        0 AS AOP,
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS Pre_Actuals,
        0 AS Pre_AOP,
        a.subsidiary AS subsidiary,
        a.department AS department
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading       h  ON h.id  = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        dc.id,
        dc.name,
        h.id,
        h.name,
        a.subsidiary,
        a.department
) z
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders})
  AND z.department  IN (${departmentPlaceHolders})
GROUP BY
    z.name,
    z.department,
    z.custrecord_dashboard_classification,
    z.Classification,
    z.id
ORDER BY
    z.custrecord_dashboard_classification,
    z.id,`

fullYearQueryChild= `SELECT 
    z.id,
    z.Classification,
    z.name,
    z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Actuals * -1))
        ELSE ROUND(SUM(z.Actuals))
    END AS actuals,
    ROUND(SUM(z.AOP)) AS aop,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP)) 
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))  
    END AS Variance,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.prev_Actuals * -1))  
        ELSE ROUND(SUM(z.prev_Actuals))   
    END AS pre_actuals1,
    ROUND(SUM(z.prev_AOP)) AS prev_aop1, 
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Actuals * -1) - (SUM(z.prev_Actuals * -1)))
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals))
    END AS Pre_Variance2,
    z.custrecord_dashboard_classification  
FROM (
    -- Budget AOP
    SELECT  
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        a.custrecord_dashboard_classification,
        0 AS Actuals, 
        SUM(bm.amount) AS AOP, 
        0 AS prev_Actuals, 
        0 AS prev_AOP,
        b.subsidiary AS subsidiary,
        b.department AS department
    FROM budgetsmachine bm 
    JOIN budgets b ON bm.budget = b.id  
    JOIN account a ON a.id = b.account 
    WHERE b.category IN (4)
      AND bm.period IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY 
        a.custrecord_dashboard1_heading_tyfone, 
        a.custrecord_dashboard_classification, 
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        a.custrecord_tyfone_subcategory_dashboard,
        b.subsidiary,
        b.department

    UNION ALL  

    -- Actuals
    SELECT 
        (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = ac.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name,
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        ac.custrecord_dashboard_classification,
        SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals,
        0 AS AOP,
        0 AS prev_Actuals,
        0 AS prev_AOP,
        a.subsidiary AS subsidiary,
        a.department AS department
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id
    WHERE b.postingperiod IN (${periodPlaceholders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY 
        ac.custrecord_dashboard1_heading_tyfone, 
        ac.custrecord_dashboard_classification, 
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        ac.custrecord_tyfone_subcategory_dashboard,
        a.subsidiary,
        a.department

    UNION ALL

    -- Previous AOP
    SELECT 
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        a.custrecord_dashboard_classification,
        0 AS Actuals,  
        0 AS AOP,  
        0 AS prev_Actuals, 
        SUM(bm.amount) AS prev_AOP,
        b.subsidiary AS subsidiary,
        b.department AS department
    FROM budgetsmachine bm 
    JOIN budgets b ON bm.budget = b.id  
    JOIN account a ON a.id = b.account  
    WHERE b.category = 4  
      AND bm.period IN (${previousMonthsPlaceHolders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)  
    GROUP BY 
        a.custrecord_dashboard1_heading_tyfone, 
        a.custrecord_dashboard_classification, 
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        a.custrecord_tyfone_subcategory_dashboard,
        b.subsidiary,
        b.department

    UNION ALL    

    -- Previous Actuals
    SELECT 
        h.id,
        dc.name AS Classification,
        h.name,
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        dc.id AS custrecord_dashboard_classification,
        0 AS Actuals,  
        0 AS AOP,  
        SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS prev_Actuals,
        0 AS prev_AOP,
        a.subsidiary AS subsidiary,
        a.department AS department
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id  
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading h ON h.id = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification  
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) 
    GROUP BY 
        dc.id, 
        dc.name, 
        h.id, 
        h.name, 
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        ac.custrecord_tyfone_subcategory_dashboard,
        a.subsidiary,
        a.department
) z 
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders}) AND z.department in (${departmentPlaceHolders})
GROUP BY 
    z.id, 
    z.Classification, 
    z.name, 
    z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,
    z.custrecord_dashboard_classification
ORDER BY 
    z.custrecord_dashboard_classification, 
    z.id,
    z.subcategory;
`
            queryParams = [
                ...stringArray,
                ...stringArray,
                ...previousYearsMonths,
                ...previousYearsMonths,
                ...subsidiaryHierarchyChildArr,
                ...departmentIds
            ]
        }
    }

    else{

         if (monthNumber != 3) {
            queryParams = [
                ...stringArray,
                monthNumber,
                ...stringArray,
                ...previousYearsMonths,
                ...previousYearsMonths,
                ...subsidiaryHierarchyChildArr
            ]
            fullYearQueryParent = `SELECT
    z.id,
    z.Classification,
    z.name,
    ROUND(SUM(z.Actuals)) AS actuals,
    ROUND(SUM(z.AOP))     AS aop,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals) - SUM(z.AOP))
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
    END AS Variance,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.prev_Actuals) * -1)
        ELSE ROUND(SUM(z.prev_Actuals))
    END AS pre_actuals1,
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals) - (SUM(z.prev_Actuals * -1)))
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals))
    END AS Pre_Variance2,
    z.custrecord_dashboard_classification
FROM (
    /* ───── Budget AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        SUM(bm.amount)          AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary            AS subsidiary,
        b.department            AS department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Current Actuals ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        SUM(bm.amount)          AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary            AS subsidiary,
        b.department            AS department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category IN (
            SELECT custrecord_ty_budget_cat
            FROM   CUSTOMRECORD_TYFONE_BUDGETCATGORYMONTHS
            WHERE  custrecord_ty_month_dashboard = ?
          )
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Previous AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        SUM(bm.amount)          AS prev_AOP,
        b.subsidiary            AS subsidiary,
        b.department            AS department
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${previousMonthsPlaceHolders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary,
        b.department

    UNION ALL

    /* ───── Previous Actuals ───── */
    SELECT
        h.id,
        dc.name                           AS Classification,
        h.name,
        dc.id                             AS custrecord_dashboard_classification,
        0                                 AS Actuals,
        0                                 AS AOP,
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS prev_Actuals,
        0                                 AS prev_AOP,
        a.subsidiary                      AS subsidiary,
        a.department                      AS department
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading       h  ON h.id  = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        dc.id, dc.name,
        h.id, h.name,
        a.subsidiary,
        a.department
) z
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY
    z.id,
    z.Classification,
    z.name,
    z.custrecord_dashboard_classification
ORDER BY
    z.custrecord_dashboard_classification,
    z.id;`

           fullYearQueryChild = `SELECT
    z.id,
    z.Classification,
    z.name,
    z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,                     -- ← NEW
    ROUND(SUM(z.Actuals))              AS actuals,
    ROUND(SUM(z.AOP))                  AS aop,

    /* current variance */
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals) - SUM(z.AOP))
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
    END                                AS Variance,

    /* previous actuals (sign-flip for 1-3) */
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.prev_Actuals) * -1)
        ELSE ROUND(SUM(z.prev_Actuals))
    END                                AS pre_actuals1,

    /* variance vs. previous period */
    CASE
        WHEN z.custrecord_dashboard_classification IN (1,2,3)
             THEN ROUND(SUM(z.Actuals)        - (SUM(z.prev_Actuals) * -1))
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals))
    END                                AS Pre_Variance2,

    z.custrecord_dashboard_classification
FROM (
    /* ───── Budget AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = a.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        SUM(bm.amount)          AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY a.custrecord_dashboard1_heading_tyfone,
             a.custrecord_dashboard_classification,
             a.accountsearchdisplaynamecopy,
             a.acctnumber,
             a.custrecord_tyfone_subcategory_dashboard,          -- NEW
             b.subsidiary

    UNION ALL

    /* ───── Current Actuals ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = a.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        a.custrecord_dashboard_classification,
        SUM(bm.amount)          AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        0                       AS prev_AOP,
        b.subsidiary
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category IN (
            SELECT custrecord_ty_budget_cat
            FROM   CUSTOMRECORD_TYFONE_BUDGETCATGORYMONTHS
            WHERE  custrecord_ty_month_dashboard = ?
          )
      AND bm.period  IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY a.custrecord_dashboard1_heading_tyfone,
             a.custrecord_dashboard_classification,
             a.accountsearchdisplaynamecopy,
             a.acctnumber,
             a.custrecord_tyfone_subcategory_dashboard,          -- NEW
             b.subsidiary

    UNION ALL

    /* ───── Previous AOP ───── */
    SELECT
        (SELECT id   FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = a.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        a.custrecord_dashboard_classification,
        0                       AS Actuals,
        0                       AS AOP,
        0                       AS prev_Actuals,
        SUM(bm.amount)          AS prev_AOP,
        b.subsidiary
    FROM budgetsmachine bm
    JOIN budgets  b ON bm.budget = b.id
    JOIN account  a ON a.id     = b.account
    WHERE b.category = 4
      AND bm.period  IN (${previousMonthsPlaceHolders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY a.custrecord_dashboard1_heading_tyfone,
             a.custrecord_dashboard_classification,
             a.accountsearchdisplaynamecopy,
             a.acctnumber,
             a.custrecord_tyfone_subcategory_dashboard,          -- NEW
             b.subsidiary

    UNION ALL

    /* ───── Previous Actuals ───── */
    SELECT
        h.id,
        dc.name                             AS Classification,
        h.name,
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD
                WHERE id = ac.custrecord_tyfone_subcategory_dashboard)                                         AS subcategory, -- NEW
        dc.id                               AS custrecord_dashboard_classification,
        0                                   AS Actuals,
        0                                   AS AOP,
        SUM(BUILTIN.CONSOLIDATE(c.amount,'INCOME','DEFAULT','DEFAULT',7,b.postingperiod,'DEFAULT')) AS prev_Actuals,
        0                                   AS prev_AOP,
        a.subsidiary
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading       h  ON h.id  = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY dc.id, dc.name, h.id, h.name,
             ac.accountsearchdisplaynamecopy,
             ac.acctnumber,
             ac.custrecord_tyfone_subcategory_dashboard,       
             a.subsidiary
) z
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY
    z.id,
    z.Classification,
    z.name,
    z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,                     -- NEW
    z.custrecord_dashboard_classification
ORDER BY
    z.custrecord_dashboard_classification,
    z.id,
    z.subcategory;`

         }
         else{
            queryParams = [
                ...stringArray,
                ...stringArray,
                ...previousYearsMonths,
                ...previousYearsMonths,
                ...subsidiaryHierarchyChildArr
            ]

               fullYearQueryParent = `SELECT 
    z.id,
    z.Classification,
    z.name,
   CASE 
    WHEN z.custrecord_dashboard_classification IN (1,2,3) 
      THEN ROUND(SUM(z.Actuals * -1))
    ELSE ROUND(SUM(z.Actuals))
  END AS actuals,
    ROUND(SUM(z.AOP)) AS aop,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP))
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))
    END AS Variance,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Pre_Actuals * -1))
        ELSE ROUND(SUM(z.Pre_Actuals))
    END AS pre_actuals1,
    ROUND(SUM(z.Pre_AOP)) AS Pre_aop,
CASE 
    WHEN z.custrecord_dashboard_classification IN (1,2,3) 
        THEN ROUND(SUM(z.Actuals * -1) - (SUM(z.Pre_Actuals * -1)))
    ELSE ROUND(SUM(z.Pre_Actuals) - SUM(z.Actuals))
END AS Pre_Variance2,
    z.custrecord_dashboard_classification
FROM (
    -- Budget AOP
    SELECT  
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0 AS Actuals,
        SUM(bm.amount) AS AOP,
        0 AS Pre_Actuals,
        0 AS Pre_AOP,
        b.subsidiary AS subsidiary
    FROM budgetsmachine bm
    JOIN budgets b ON bm.budget = b.id  
    JOIN account a ON a.id = b.account
    WHERE b.category IN (4)
        AND bm.period IN (${periodPlaceholders})
        AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary

    UNION ALL  

    -- Actuals
    SELECT
        (SELECT id FROM customrecord_dashboard1_heading 
            WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification 
            WHERE id = ac.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_dashboard1_heading 
            WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name,
        ac.custrecord_dashboard_classification,
        SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals,
        0 AS AOP,
        0 AS Pre_Actuals,
        0 AS Pre_AOP,
        a.subsidiary AS subsidiary
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON b.id = c.transaction AND a.id = c.transactionline
    JOIN account ac ON ac.id = c.account
    WHERE a.expenseaccount = ac.id
        AND b.postingperiod IN (${periodPlaceholders})
        AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        ac.custrecord_dashboard1_heading_tyfone,
        ac.custrecord_dashboard_classification,
        a.subsidiary

    UNION ALL

    -- Previous AOP
    SELECT
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.custrecord_dashboard_classification,
        0 AS Actuals,
        0 AS AOP,
        0 AS Pre_Actuals,
        SUM(bm.amount) AS Pre_AOP,
        b.subsidiary AS subsidiary
    FROM budgetsmachine bm
    JOIN budgets b ON bm.budget = b.id  
    JOIN account a ON a.id = b.account  
    WHERE b.category = 4
        AND bm.period IN (${previousMonthsPlaceHolders})	
        AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        a.custrecord_dashboard_classification,
        a.custrecord_dashboard1_heading_tyfone,
        b.subsidiary

    UNION ALL    

    -- Previous Actuals
    SELECT
        h.id,
        dc.name AS Classification,
        h.name,
        dc.id AS custrecord_dashboard_classification,
        0 AS Actuals,
        0 AS AOP,
        SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Pre_Actuals,
        0 AS Pre_AOP,
        a.subsidiary AS subsidiary
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id  
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading h ON h.id = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification  
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
        AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY
        dc.id,
        dc.name,
        h.id,
        h.name,
        a.subsidiary
) z
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.name, 
    z.custrecord_dashboard_classification, 
    z.Classification, 
    z.id
ORDER BY 
    z.custrecord_dashboard_classification, 
    z.id;`
    

    fullYearQueryChild= `SELECT 
    z.id,
    z.Classification,
    z.name,
    z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Actuals * -1))
        ELSE ROUND(SUM(z.Actuals))
    END AS actuals,
    ROUND(SUM(z.AOP)) AS aop,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Actuals * -1) - SUM(z.AOP)) 
        ELSE ROUND(SUM(z.AOP) - SUM(z.Actuals))  
    END AS Variance,
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.prev_Actuals * -1))  
        ELSE ROUND(SUM(z.prev_Actuals))   
    END AS pre_actuals1,
    ROUND(SUM(z.prev_AOP)) AS prev_aop1, 
    CASE 
        WHEN z.custrecord_dashboard_classification IN (1,2,3) 
            THEN ROUND(SUM(z.Actuals * -1) - (SUM(z.prev_Actuals * -1)))
        ELSE ROUND(SUM(z.prev_Actuals) - SUM(z.Actuals))
    END AS Pre_Variance2,
    z.custrecord_dashboard_classification  
FROM (
    -- Budget AOP
    SELECT  
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        a.custrecord_dashboard_classification,
        0 AS Actuals, 
        SUM(bm.amount) AS AOP, 
        0 AS prev_Actuals, 
        0 AS prev_AOP,
        b.subsidiary AS subsidiary
    FROM budgetsmachine bm 
    JOIN budgets b ON bm.budget = b.id  
    JOIN account a ON a.id = b.account 
    WHERE b.category IN (4)
      AND bm.period IN (${periodPlaceholders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY 
        a.custrecord_dashboard1_heading_tyfone, 
        a.custrecord_dashboard_classification, 
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        a.custrecord_tyfone_subcategory_dashboard,
        b.subsidiary

    UNION ALL  

    -- Actuals
    SELECT 
        (SELECT id FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = ac.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_dashboard1_heading WHERE id = ac.custrecord_dashboard1_heading_tyfone) AS name,
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        ac.custrecord_dashboard_classification,
        SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS Actuals,
        0 AS AOP,
        0 AS prev_Actuals,
        0 AS prev_AOP,
        a.subsidiary AS subsidiary
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction
    JOIN account ac ON ac.id = c.account AND a.expenseaccount = ac.id
    WHERE b.postingperiod IN (${periodPlaceholders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)
    GROUP BY 
        ac.custrecord_dashboard1_heading_tyfone, 
        ac.custrecord_dashboard_classification, 
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        ac.custrecord_tyfone_subcategory_dashboard,
        a.subsidiary

    UNION ALL

    -- Previous AOP
    SELECT 
        (SELECT id FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS id,
        (SELECT name FROM customrecord_dashboard1_classification WHERE id = a.custrecord_dashboard_classification) AS Classification,
        (SELECT name FROM customrecord_DASHBOARD1_HEADING WHERE id = a.custrecord_dashboard1_heading_tyfone) AS name,
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = a.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        a.custrecord_dashboard_classification,
        0 AS Actuals,  
        0 AS AOP,  
        0 AS prev_Actuals, 
        SUM(bm.amount) AS prev_AOP,
        b.subsidiary AS subsidiary
    FROM budgetsmachine bm 
    JOIN budgets b ON bm.budget = b.id  
    JOIN account a ON a.id = b.account  
    WHERE b.category = 4  
      AND bm.period IN (${previousMonthsPlaceHolders})
      AND a.custrecord_dashboard_classification IN (1,2,3,4,5,6,7)  
    GROUP BY 
        a.custrecord_dashboard1_heading_tyfone, 
        a.custrecord_dashboard_classification, 
        a.accountsearchdisplaynamecopy,
        a.acctnumber,
        a.custrecord_tyfone_subcategory_dashboard,
        b.subsidiary

    UNION ALL    

    -- Previous Actuals
    SELECT 
        h.id,
        dc.name AS Classification,
        h.name,
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        (SELECT name FROM CUSTOMLIST_TYF_SUBCATEGORIES_DASHBOARD WHERE id = ac.custrecord_tyfone_subcategory_dashboard) AS subcategory,
        dc.id AS custrecord_dashboard_classification,
        0 AS Actuals,  
        0 AS AOP,  
        SUM(BUILTIN.CONSOLIDATE(c.amount, 'INCOME', 'DEFAULT', 'DEFAULT', 7, b.postingperiod, 'DEFAULT')) AS prev_Actuals,
        0 AS prev_AOP,
        a.subsidiary AS subsidiary
    FROM transactionline a
    JOIN transaction b ON a.transaction = b.id  
    JOIN transactionaccountingline c ON a.id = c.transactionline AND b.id = c.transaction  
    JOIN account ac ON ac.id = c.account
    JOIN customrecord_dashboard1_heading h ON h.id = ac.custrecord_dashboard1_heading_tyfone
    JOIN customrecord_dashboard1_classification dc ON dc.id = ac.custrecord_dashboard_classification  
    WHERE b.postingperiod IN (${previousMonthsPlaceHolders})
      AND ac.custrecord_dashboard_classification IN (1,2,3,4,5,6,7) 
    GROUP BY 
        dc.id, 
        dc.name, 
        h.id, 
        h.name, 
        ac.accountsearchdisplaynamecopy,
        ac.acctnumber,
        ac.custrecord_tyfone_subcategory_dashboard,
        a.subsidiary
) z 
WHERE z.subsidiary IN (${subsidiaryChildPlaceHolders})
GROUP BY 
    z.id, 
    z.Classification, 
    z.name, 
    z.accountsearchdisplaynamecopy,
    z.acctnumber,
    z.subcategory,
    z.custrecord_dashboard_classification
ORDER BY 
    z.custrecord_dashboard_classification, 
    z.id,
    z.subcategory;
`

         }


    }


log.debug("queryParams before running",queryParams)
        parentResults = query.runSuiteQL({
            query: fullYearQueryParent,
            params: queryParams
        }).asMappedResults();

        log.debug("parent results", parentResults)
    
        childResults = query.runSuiteQL({
            query: fullYearQueryChild,
            params: queryParams,
        }).asMappedResults();

      
    
        // Initialize Full Year totals
        let fullYTotalOperatingRevenueActuals = 0;
        let fullYTotalOperatingRevenueAOP = 0;
        let fullYTotalOperatingRevenueDiff = 0;
        let fullYTotalOperatingRevenuePreActuals=0;
        let fullYTotalOperatingRevenuePreVariance=0;
        let fullYTotalOperatingRevenuePreVariancePercent;
        let fullYGrossMarginPreActuals=0;
        let fullYGrossMarginPreVariance=0;
        let fullYGrossMarginPreVariancePercent;
        let fullYTotalRevenueActuals = 0;
        let fullYTotalRevenueAOP = 0;
        let fullYTotalRevenueDiff = 0;
        let fullYTotalCostOfRevenueActuals = 0;
        let fullYTotalCostOfRevenueAOP = 0;
        let fullYTotalCostOfRevenuePreActuals=0;
        let fullYGrossMarginActuals = 0;
        let fullYGrossMarginAOP = 0;
        let grossPerAct=0;
        let grossPerAOP=0;
        let grossPerVar=0;
        let grossPrePerAct=0;



        let fullYGrossMarginDiff = 0;
        let fullYOperatingExpensesActualTotal = 0;
        let fullYOperatingExpensesAOPTotal = 0;
        let fullYOperatingExpensesPreActuals=0;
        let fullYOperatingExpensesPreVariance=0;
        let fullYOtherOperatingExpensesActualTotal = 0;
        let fullYOtherOperatingExpensesAOPTotal = 0;
        let fullYOtherIncomeTotalActuals = 0;
        let fullYOtherIncomeTotalPreActuals=0;
        let fullYTotalRevenuePreActuals=0;
        let fullYTotalRevenueVariance=0;
        let fullYOtherIncomeTotalVariance=0;
        let fullYOtherIncomeTotalAOP = 0;
        let fullYNetProfitActuals = 0;
        let fullYNetProfitAOP = 0;
        let fullYNetProfitDiff = 0;
        let fullYOtherExpensesTotalActuals = 0;
let fullYOtherExpensesTotalAOP = 0;
    
      let fullYChildData = {};
let fullYSubcategoryTotals = {};

childResults.forEach(childRow => {
    const classification = childRow.classification.trim();
    const parentName = childRow.name;
    const subcategory = childRow.subcategory || parentName; // Handle null subcategories

    // Ensure nested structure exists
    if (!fullYChildData[classification]) {
        fullYChildData[classification] = {};
        fullYSubcategoryTotals[classification] = {};
    }
    if (!fullYChildData[classification][parentName]) {
        fullYChildData[classification][parentName] = {};
        fullYSubcategoryTotals[classification][parentName] = {};
    }
    if (!fullYChildData[classification][parentName][subcategory]) {
        fullYChildData[classification][parentName][subcategory] = [];
        fullYSubcategoryTotals[classification][parentName][subcategory] = {
            actuals: 0,
            aop: 0,
            variance: 0,
            pre_actuals1: 0,
            pre_variance2: 0
        };
    }

    // Add child row to the appropriate subcategory
    fullYChildData[classification][parentName][subcategory].push(childRow);

    // Accumulate subcategory totals
    fullYSubcategoryTotals[classification][parentName][subcategory].actuals += Number(childRow.actuals) || 0;
    fullYSubcategoryTotals[classification][parentName][subcategory].aop += Number(childRow.aop) || 0;
    fullYSubcategoryTotals[classification][parentName][subcategory].variance += Number(childRow.variance) || 0;
    fullYSubcategoryTotals[classification][parentName][subcategory].pre_actuals1 += Number(childRow.pre_actuals1) || 0;
    fullYSubcategoryTotals[classification][parentName][subcategory].pre_variance2 += Number(childRow.pre_variance2) || 0;
});

        // Group parent data
        let fullYGrouped = {};
   
      let nfinia={}
      let nfiniaThree={}
      

        parentResults.forEach(row => {
            const classification = row.classification.trim(); // Add trim()
            if (!fullYGrouped[classification]) fullYGrouped[classification] = [];
            if(row.classification.trim()=='Non Recurring Revenue'){
                if (!nfinia[classification]) nfinia[classification] = [];
                nfinia[classification].push(row);
                
            }
            else if((row.name.trim()=='3rd Party (nfinia)')){
                if (!nfiniaThree[classification]) nfiniaThree[classification] = [];
                nfiniaThree[classification].push(row);

            }
            
            fullYGrouped[classification].push(row);
        });
    
        
        // var arrActualsSum=fullYNetNewBookings+arrActTotal

        var contractedActualsTotal=parseInt(arrActTotal)+parseInt(fullYnetNewActualsSum);
        var contractedAopTotal=parseInt(arrAopTotal)+parseInt(fullYnetNewAopSum);
        var contractedVariance=parseInt(contractedActualsTotal)-parseInt(contractedAopTotal);
        var contractedVariancePer=(arrPer && fullYnetNewVariancePerSum)?(Number(arrPer)+Number(fullYnetNewVariancePerSum)).toFixed(1) +'%':"0%";

        const months = [
            'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 
            'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
        ];
        var monthName=months[monthNumber-1];

                var subsidiaryRec=record.load({
                    type: 'customrecord_tyf_subs_hier_',
                    id: subsidiary
                  })

                  var subsidiaryName=subsidiaryRec.getValue({fieldId: 'name'})

       
        // Build HTML
        let fullYHtml = `
        <table width="100%"><thead>
                               <tr><th colspan="8" style="text-align: center; color: white; background-color: #454444; font-weight: 800; font-size: 15pt;">${subsidiaryName} - Full Year (${monthName} ' ${yearName})</th></tr><tr>
                <th width="30%">Particulars</th>
                <th width="10%">Actuals</th>
                <th width="10%">AOP</th>
                <th width="10%">Variance</th>
                <th width="10%">Variance (%)</th>
                 <th width="10%">Previous Year<br/>Actuals</th>
                <th width="10%">Previous Year<br/>Variance</th>
        <th width="10%">Previous Year<br/>Variance (%)</th>
            </tr></thead>`;
    
        // Process each classification
        for (let classification in fullYGrouped) {
            // Classification header
            fullYHtml += `
                <tr>
                    <td class="classification-section" colspan="8">${classification}</td>
                </tr>`;
    
            let classificationTotal = {
                actuals: 0,
                aop: 0,
                difference: 0,
                pre_actuals: 0,
                pre_variance: 0
            };
    
            // Process parent rows
         fullYGrouped[classification].forEach((parentRow, parentIdx) => {
    log.debug("classification parent row", classification);
    const parentIndex = parentIdx + 1; // Unique index for each parent row
    const parentGroup = `fullY_parent_${parentIndex}_subcats`; // Unique group ID for subcategories
    const actuals = Number(parentRow.actuals) || 0;
    const aop = Number(parentRow.aop) || 0;
    const variance = Number(parentRow.variance) || 0;
    const variancePercent = (aop !== 0) ? ((variance / aop) * 100).toFixed(1) : 0;
    const preActuals = Number(parentRow.pre_actuals1) || 0;
    const preVariance = Number(parentRow.pre_variance2) || 0;
    const preVariancePercent = (preActuals !== 0) ? ((preVariance / preActuals) * 100).toFixed(1): 0;
    const varianceClass = variance < 0 ? 'negative' : 'positive';
    const subcategories = fullYChildData[classification]?.[parentRow.name];
    const hasSubcategories = subcategories && Object.keys(subcategories).length > 0;

    // Update classification totals
    classificationTotal.actuals += actuals;
    classificationTotal.aop += aop;
    classificationTotal.difference += variance;
    classificationTotal.pre_actuals += preActuals;
    classificationTotal.pre_variance += preVariance;

    // Parent row with toggle button if subcategories exist
    fullYHtml += `
        <tr class="parent-row">
            <td width="30%">
                ${hasSubcategories ? `<button class="toggle-button" onclick="toggleRows('${parentGroup}', this)">+</button>` : ''}
                ${parentRow.name}
            </td>
            <td width="10%" class="${Number(actuals) < 0 ? 'negative' : 'positive'}">${Math.round(actuals).toLocaleString()}</td>
            <td width="10%" class="${Number(aop) < 0 ? 'negative' : 'positive'}">${Math.round(aop).toLocaleString()}</td>
            <td width="10%" class="${Number(variance) < 0 ? 'negative' : 'positive'}">${Math.round(variance).toLocaleString()}</td>
            <td width="10%" class="${Number(variancePercent) < 0 ? 'negative' : 'positive'}">${variancePercent} %</td>
            <td width="10%" class="${Number(preActuals) < 0 ? 'negative' : 'positive'}">${Math.round(preActuals).toLocaleString()}</td>
            <td width="10%" class="${Number(preVariance) < 0 ? 'negative' : 'positive'}">${Math.round(preVariance).toLocaleString()}</td>
            <td width="10%" class="${Number(preVariancePercent) < 0 ? 'negative' : 'positive'}">${preVariancePercent} %</td>
        </tr>`;

    // Add subcategory rows if they exist
    if (hasSubcategories) {
        let subcatIndex = 0;
        for (let subcategory in subcategories) {
            subcatIndex++;
            const subcatGroup = `fullY_subcat_${parentIndex}_${subcatIndex}_children`; // Unique group ID for child rows
            const subcatTotal = fullYSubcategoryTotals[classification][parentRow.name][subcategory];
            const subcatActuals = subcatTotal.actuals || 0;
            const subcatAop = subcatTotal.aop || 0;
            const subcatVariance = subcatTotal.variance || 0;
            const subcatVariancePercent = (subcatAop !== 0) ? ((subcatVariance / subcatAop) * 100).toFixed(1) : 0;
            const subcatPreActuals = subcatTotal.pre_actuals1 || 0;
            const subcatPreVariance = subcatTotal.pre_variance2 || 0;
            const subcatPreVariancePercent = (subcatPreActuals !== 0) ? ((subcatPreVariance / subcatPreActuals) * 100).toFixed(1): 0;
            const subcatVarianceClass = subcatVariance < 0 ? 'negative' : 'positive';

            // Subcategory row
            fullYHtml += `
                <tr class="subcategory-row" data-group="${parentGroup}" style="display:none;">
                    <td width="30%">
                        <button class="subcategory-toggle" onclick="toggleRows('${subcatGroup}', this)">+</button>
                        ${subcategory}
                    </td>
                    <td width="10%" class="${Number(subcatActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatAop) < 0 ? 'negative' : 'positive'}">${Math.round(subcatAop).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatVariance).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatVariancePercent) < 0 ? 'negative' : 'positive'}">${subcatVariancePercent} %</td>
                    <td width="10%" class="${Number(subcatPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreActuals).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(subcatPreVariance).toLocaleString()}</td>
                    <td width="10%" class="${Number(subcatPreVariancePercent) < 0 ? 'negative' : 'positive'}">${subcatPreVariancePercent} %</td>
                </tr>`;

            // Child rows under each subcategory
            subcategories[subcategory].forEach(child => {
                const childActuals = Number(child.actuals) || 0;
                const childAop = Number(child.aop) || 0;
                const childVariance = Number(child.variance) || 0;
                const childVariancePercent = (childAop !== 0) ? ((childVariance / childAop) * 100).toFixed(1) : 0;
                const childPreActuals = Number(child.pre_actuals1) || 0;
                const childPreVariance = Number(child.pre_variance2) || 0;
                const childPreVariancePercent = (childPreActuals !== 0) ? ((childPreVariance / childPreActuals) * 100).toFixed(1) : 0;
                const childVarianceClass = childVariance < 0 ? 'negative' : 'positive';

                fullYHtml += `
                    <tr class="child-row" data-group="${subcatGroup}" style="display:none;">
                        <td width="30%">${child.acctnumber} ${child.accountsearchdisplaynamecopy}</td>
                        <td width="10%" class="${Number(childActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(childAop) < 0 ? 'negative' : 'positive'}">${Math.round(childAop).toLocaleString()}</td>
                        <td width="10%" class="${Number(childVariance) < 0 ? 'negative' : 'positive'}">${Math.round(childVariance).toLocaleString()}</td>
                        <td width="10%" class="${Number(childVariancePercent) < 0 ? 'negative' : 'positive'}">${childVariancePercent} %</td>
                        <td width="10%" class="${Number(childPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(childPreActuals).toLocaleString()}</td>
                        <td width="10%" class="${Number(childPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(childPreVariance).toLocaleString()}</td>
                        <td width="10%" class="${Number(childPreVariancePercent) < 0 ? 'negative' : 'positive'}">${childPreVariancePercent} %</td>
                    </tr>`;
            });
        }
    }
});


        // Classification total row
        const totalVariancePercent = (classificationTotal.aop !== 0) && (classificationTotal.difference && classificationTotal.aop)
            ? ((classificationTotal.difference / classificationTotal.aop) * 100).toFixed(1)
            : 0
        const varianceClass = classificationTotal.difference < 0 ? 'negative' : 'positive';
        const totalPrevVarPercent=(classificationTotal.pre_actuals !== 0) && (classificationTotal.pre_variance && classificationTotal.pre_actuals)
            ? ((classificationTotal.pre_variance / classificationTotal.pre_actuals) * 100).toFixed(1)
            : 0

       

        // Update Full Year totals and add summary rows
          // First Condition Set: Update totals
          if (classification === 'Recurring Revenue' || classification === 'Non Recurring Revenue') {
            fullYTotalOperatingRevenueActuals += classificationTotal.actuals;
            fullYTotalOperatingRevenueAOP += classificationTotal.aop;
            fullYTotalOperatingRevenueDiff += classificationTotal.difference;
            fullYTotalOperatingRevenuePreActuals += classificationTotal.pre_actuals;
            fullYTotalOperatingRevenuePreVariance += classificationTotal.pre_variance;
            fullYTotalOperatingRevenuePreVariancePercent = (fullYTotalOperatingRevenuePreVariance !== 0) && (fullYTotalOperatingRevenuePreActuals && fullYTotalOperatingRevenuePreVariance)
                ? ((fullYTotalOperatingRevenuePreVariance / fullYTotalOperatingRevenuePreActuals) * 100).toFixed(1)
                : 0;
        } 
        else if (classification === 'Cost of Revenue') {
            fullYTotalCostOfRevenueActuals = classificationTotal.actuals;
            fullYTotalCostOfRevenueAOP = classificationTotal.aop;
            fullYTotalCostOfRevenuePreActuals= classificationTotal.pre_actuals;
            fullYGrossMarginActuals = fullYTotalOperatingRevenueActuals - fullYTotalCostOfRevenueActuals;
            fullYGrossMarginAOP = fullYTotalOperatingRevenueAOP - fullYTotalCostOfRevenueAOP;
            fullYGrossMarginDiff =  Math.abs(fullYGrossMarginAOP) - Math.abs(fullYGrossMarginActuals);
            fullYGrossMarginPreActuals = fullYTotalOperatingRevenuePreActuals - fullYTotalCostOfRevenuePreActuals;
            fullYGrossMarginPreVariance =   fullYGrossMarginPreActuals - fullYGrossMarginActuals;
            fullYGrossMarginPreVariancePercent = (fullYGrossMarginPreVariance !== 0) && (fullYGrossMarginPreActuals && fullYGrossMarginPreVariance)
                ? ((fullYGrossMarginPreVariance / fullYGrossMarginPreActuals) * 100).toFixed(1)
                : 0

          log.debug("gross margin act ",fullYGrossMarginActuals)
          log.debug("total op rev act",fullYTotalOperatingRevenueActuals)
               grossPerAct = (fullYTotalOperatingRevenueActuals !== 0) && (fullYGrossMarginActuals && fullYTotalOperatingRevenueActuals)
    ? ((fullYGrossMarginActuals / fullYTotalOperatingRevenueActuals * 100).toFixed(1))
    : 0;
grossPerAOP = (fullYTotalOperatingRevenueAOP !== 0) && (fullYGrossMarginAOP && fullYTotalOperatingRevenueAOP)
    ? ((fullYGrossMarginAOP / fullYTotalOperatingRevenueAOP * 100).toFixed(1))
    : 0;
grossPerVar = (grossPerAct && grossPerAOP) ? (Math.abs(grossPerAct) - Math.abs(grossPerAOP)).toFixed(1)+'%' : '0%';

            grossPrePerAct=(fullYTotalOperatingRevenuePreActuals !== 0) && (fullYGrossMarginPreActuals && fullYTotalOperatingRevenuePreActuals)
                ? (((fullYGrossMarginPreActuals) / fullYTotalOperatingRevenuePreActuals * 100).toFixed(1))
                : 0

          log.debug("pre actuals",fullYGrossMarginPreActuals)

          log.debug("pre variance",fullYGrossMarginPreVariance)
            

        }
        else if (classification === 'OPERATING EXPENSES') {
            fullYOperatingExpensesActualTotal = classificationTotal.actuals;
            fullYOperatingExpensesAOPTotal = classificationTotal.aop;
            fullYOperatingExpensesPreActuals = classificationTotal.pre_actuals;
            fullYOperatingExpensesPreVariance = classificationTotal.pre_variance;
        }
        else if (classification === 'Other Operating Expenses' || classification === 'Other Operating Expenses ') {
            fullYOtherOperatingExpensesActualTotal = classificationTotal.actuals;
            fullYOtherOperatingExpensesAOPTotal = classificationTotal.aop;
            fullYOtherOperatingExpensesPreActuals = classificationTotal.pre_actuals;
            fullYOtherOperatingExpensesPreVariance = classificationTotal.pre_variance;
        }
        else if (classification === 'OTHER INCOME') {
            fullYOtherIncomeTotalActuals = classificationTotal.actuals;
            fullYOtherIncomeTotalAOP = classificationTotal.aop;
            fullYTotalRevenueActuals = fullYTotalOperatingRevenueActuals + fullYOtherIncomeTotalActuals;
            fullYTotalRevenueAOP = fullYTotalOperatingRevenueAOP + fullYOtherIncomeTotalAOP;
            fullYTotalRevenueDiff = fullYTotalRevenueActuals - fullYTotalRevenueAOP;
            fullYOtherIncomeTotalPreActuals=classificationTotal.pre_actuals;
fullYTotalRevenuePreActuals=fullYTotalOperatingRevenuePreActuals + fullYOtherIncomeTotalPreActuals
fullYTotalRevenueVariance=fullYTotalRevenueActuals-fullYTotalRevenuePreActuals;




           
            fullYOtherIncomeTotalVariance=fullYOtherIncomeTotalActuals-fullYOtherIncomeTotalPreActuals;
          

        }
        else if (classification === 'Other expenses') {
            fullYOtherExpensesTotalActuals = classificationTotal.actuals;
            fullYOtherExpensesTotalAOP = classificationTotal.aop;
            fullYOtherExpensesPreActuals=classificationTotal.pre_actuals;
            fullYOtherExpensesVariance=classificationTotal.pre_variance;
        }



        if (classification === 'Non Recurring Revenue') {
            fullYHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
                  <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
            </tr>
                <tr class="summary-rows">
                    <td>TOTAL OPERATING REVENUE</td>
                    <td class="${Number(fullYTotalOperatingRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalOperatingRevenueActuals).toLocaleString()}</td>
                    <td class="${Number(fullYTotalOperatingRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalOperatingRevenueAOP).toLocaleString()}</td>
                    <td class="${Number(fullYTotalOperatingRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalOperatingRevenueDiff).toLocaleString()}</td>
                    <td class="${Number((fullYTotalOperatingRevenueAOP !== 0) && (fullYTotalOperatingRevenueDiff && fullYTotalOperatingRevenueAOP)
                        ? ((fullYTotalOperatingRevenueDiff / fullYTotalOperatingRevenueAOP * 100).toFixed(1))
                        : 0) < 0 ? 'negative' : 'positive'}">${(fullYTotalOperatingRevenueAOP !== 0) && (fullYTotalOperatingRevenueDiff && fullYTotalOperatingRevenueAOP)
                        ? ((fullYTotalOperatingRevenueDiff / fullYTotalOperatingRevenueAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                          <td class="${Number(fullYTotalOperatingRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${fullYTotalOperatingRevenuePreActuals?(Math.round(fullYTotalOperatingRevenuePreActuals).toLocaleString()):0}</td>
            <td class="${Number(fullYTotalOperatingRevenuePreVariance) < 0 ? 'negative' : 'positive'}">${fullYTotalOperatingRevenuePreVariance?(Math.round(fullYTotalOperatingRevenuePreVariance).toLocaleString()):0}</td>
            <td class="${Number(fullYTotalOperatingRevenuePreVariancePercent) < 0 ? 'negative' : 'positive'}">${fullYTotalOperatingRevenuePreVariancePercent}</td>
                </tr>`;
        }
        else if (classification === 'Cost of Revenue') {
            const grossMarginPer = (fullYGrossMarginAOP !== 0) && (fullYGrossMarginDiff && fullYGrossMarginAOP)
                ? ((fullYGrossMarginDiff / fullYGrossMarginAOP) * 100).toFixed(1)
                : 0

            fullYHtml += `
            <tr class="total-row">
                <td>TOTAL ${classification}</td>
                <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
                <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
                <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
                <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
                  <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
            </tr>
                <tr class="summary-rows">
                    <td>Gross Margin (excl. other income)</td>
                    <td class="${Number(fullYGrossMarginActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginActuals).toLocaleString()}</td>
                    <td class="${Number(fullYGrossMarginAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginAOP).toLocaleString()}</td>
                    <td class="${Number(fullYGrossMarginDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginDiff).toLocaleString()}</td>
                    <td class="${Number(grossMarginPer) < 0 ? 'negative' : 'positive'}">${grossMarginPer}</td>
                      <td class="${Number(fullYGrossMarginPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginPreActuals).toLocaleString()}</td>
            <td class="${Number(fullYGrossMarginPreVariance) < 0 ? 'negative' : 'positive'}">${Math.round(fullYGrossMarginPreVariance).toLocaleString()}</td>
            <td class="${Number((fullYGrossMarginPreActuals !== 0) && (fullYGrossMarginPreVariance && fullYGrossMarginPreActuals)
                ? ((fullYGrossMarginPreVariance / fullYGrossMarginPreActuals) * 100).toFixed(1)
                : 0) < 0 ? 'negative' : 'positive'}">${(fullYGrossMarginPreActuals !== 0) && (fullYGrossMarginPreVariance && fullYGrossMarginPreActuals)
                ? ((fullYGrossMarginPreVariance / fullYGrossMarginPreActuals) * 100).toFixed(1) + '%'
                : '0%'}</td>
                </tr>
                <tr class="summary-rows">
                    <td>Gross Margin %</td>
                    <td class="${Number(grossPerAct) < 0 ? 'negative' : 'positive'}">${(grossPerAct)}%</td>
                    <td class="${Number(grossPerAOP) < 0 ? 'negative' : 'positive'}">${(grossPerAOP)}%</td>
                    <td></td>
                      <td class="${Number(grossPerVar) < 0 ? 'negative' : 'positive'}">${(grossPerVar)}%</td>
            <td class="${Number(grossPrePerAct) < 0 ? 'negative' : 'positive'}">${(grossPrePerAct)}%</td>
            <td></td>
            <td class="${Number((grossPerAct && grossPrePerAct)?(Math.round(grossPerAct-grossPrePerAct).toFixed(1)):0) < 0 ? 'negative' : 'positive'}">${(grossPerAct && grossPrePerAct)?(Math.round(grossPerAct-grossPrePerAct).toFixed(1)):0}%</td>
                </tr>`;
        }
        else if (classification === 'Other Operating Expenses' || classification === 'Other Operating Expenses ') {
            const totalOperatingActual = fullYOperatingExpensesActualTotal + fullYOtherOperatingExpensesActualTotal;
            const totalOperatingAOP = fullYOperatingExpensesAOPTotal + fullYOtherOperatingExpensesAOPTotal;
            const totalOperatingDiff = Math.abs(totalOperatingAOP) - Math.abs(totalOperatingActual);
            const proFormaEbitaActuals = fullYGrossMarginActuals - totalOperatingActual;
            const proFormaEbitaAOP = fullYGrossMarginAOP - totalOperatingAOP;
            const proFormaEbitaDiff = proFormaEbitaAOP - proFormaEbitaActuals;
            

            const totalOperatingPreActual= fullYOperatingExpensesPreActuals+fullYOtherOperatingExpensesPreActuals;
            const totalOperatingVariance=totalOperatingActual-totalOperatingPreActual;
            const totalOperatingVarPer=(totalOperatingPreActual !== 0) && (totalOperatingVariance && totalOperatingPreActual)
            ? ((totalOperatingVariance / totalOperatingPreActual * 100).toFixed(1) + '%')
            : '0%'

            
            const proFormaEbitaPerActuals = (fullYTotalOperatingRevenueActuals !== 0) && (proFormaEbitaActuals && fullYTotalOperatingRevenueActuals)
            ? ((proFormaEbitaActuals / fullYTotalOperatingRevenueActuals) * 100).toFixed(1)
            : 0

        const proFormaEbitaPerAOP = (fullYTotalOperatingRevenueAOP !== 0) && (proFormaEbitaAOP && fullYTotalOperatingRevenueAOP)
            ? ((proFormaEbitaAOP / fullYTotalOperatingRevenueAOP) * 100).toFixed(1)
            : 0

            const proFormaEbitaPerDiff=proFormaEbitaPerActuals - proFormaEbitaPerAOP;

            const proFormaEbitaPreActuals=fullYGrossMarginPreActuals - totalOperatingPreActual;
            const proFormaEbitaVariance=proFormaEbitaActuals-proFormaEbitaPreActuals;

            const proFormaEbitaPrePerAct=(fullYTotalOperatingRevenuePreActuals !== 0) && (proFormaEbitaPreActuals && fullYTotalOperatingRevenuePreActuals)
            ? ((proFormaEbitaPreActuals / fullYTotalOperatingRevenuePreActuals) * 100).toFixed(1)
            : 0

            const proFormaEbitaPreVarPer=proFormaEbitaPerActuals - proFormaEbitaPrePerAct;

           
            const proFormaEbitaVarPer= (proFormaEbitaPreActuals !== 0) && (proFormaEbitaVariance && proFormaEbitaPreActuals)
            ? ((proFormaEbitaVariance / proFormaEbitaPreActuals) * 100).toFixed(1)
            : 0
            

            fullYHtml += `
            <tr class="total-row">
            <td>TOTAL ${classification}</td>
            <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
            <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
              <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
        <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr>
                <tr class="summary-rows">
                    <td>TOTAL OPERATING EXPENSES</td>
                    <td class="${Number(totalOperatingActual) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingActual).toLocaleString()}</td>
                    <td class="${Number(totalOperatingAOP) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingAOP).toLocaleString()}</td>
                    <td class="${Number(totalOperatingDiff) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingDiff).toLocaleString()}</td>
                    <td class="${Number((totalOperatingAOP !== 0) && (totalOperatingDiff && totalOperatingAOP)
                        ? ((totalOperatingDiff / totalOperatingAOP * 100).toFixed(1))
                        : 0) < 0 ? 'negative' : 'positive'}">${(totalOperatingAOP !== 0) && (totalOperatingDiff && totalOperatingAOP)
                        ? ((totalOperatingDiff / totalOperatingAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(totalOperatingPreActual) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingPreActual).toLocaleString()}</td>
            <td class="${Number(totalOperatingVariance) < 0 ? 'negative' : 'positive'}">${Math.round(totalOperatingVariance).toLocaleString()}</td>
            <td class="${Number(totalOperatingVarPer) < 0 ? 'negative' : 'positive'}">${totalOperatingVarPer}</td>
                </tr>
                <tr class="summary-rows">
                    <td>Pro Forma EBITDA</td>
                    <td class="${Number(proFormaEbitaActuals) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaActuals).toLocaleString()}</td>
                    <td class="${Number(proFormaEbitaAOP) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaAOP).toLocaleString()}</td>
                    <td  class="${Number(proFormaEbitaDiff) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaDiff).toLocaleString()}</td>
                    <td class="${Number((proFormaEbitaAOP !== 0) && (proFormaEbitaDiff && proFormaEbitaAOP)
                        ? ((proFormaEbitaDiff / proFormaEbitaAOP * 100).toFixed(1))
                        : 0) < 0 ? 'negative' : 'positive'}">${(proFormaEbitaAOP !== 0) && (proFormaEbitaDiff && proFormaEbitaAOP)
                        ? ((proFormaEbitaDiff / proFormaEbitaAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(proFormaEbitaPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaPreActuals).toLocaleString()}</td>
                        
            <td class="${Number(proFormaEbitaVariance) < 0 ? 'negative' : 'positive'}">${Math.round(proFormaEbitaVariance).toLocaleString()}</td>
            <td class="${Number(proFormaEbitaVarPer) < 0 ? 'negative' : 'positive'}">${proFormaEbitaVarPer}</td>
                </tr>
                 <tr class="summary-rows">
                    <td>Pro Forma EBITDA %</td>
                    <td class="${Number(proFormaEbitaPerActuals) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerActuals}%</td>
                    <td class="${Number(proFormaEbitaPerAOP) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerAOP} %</td>
                    <td></td>
                    <td class="${Number(proFormaEbitaPerDiff) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPerDiff?(proFormaEbitaPerDiff.toFixed(1)):'0'}%</td>
                    <td class="${Number(proFormaEbitaPrePerAct) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPrePerAct} %</td>
                    <td></td>
                    <td class="${Number(proFormaEbitaPreVarPer) < 0 ? 'negative' : 'positive'}">${proFormaEbitaPreVarPer?(proFormaEbitaPreVarPer.toFixed(1)):0}%</td>
                </tr>`;
        }
        else if (classification === 'OTHER INCOME') {
            fullYHtml += `
            <tr class="total-row">
            <td>TOTAL ${classification}</td>
            <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
            <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
              <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
        <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr>
                <tr class="summary-rows">
                    <td>Total Revenue</td>
                    <td class="${Number(fullYTotalRevenueActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueActuals).toLocaleString()}</td>
                    <td class="${Number(fullYTotalRevenueAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueAOP).toLocaleString()}</td>
                    <td class="${Number(fullYTotalRevenueDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueDiff).toLocaleString()}</td>
                    <td class="${Number((fullYTotalRevenueAOP !== 0) && (fullYTotalRevenueDiff && fullYTotalRevenueAOP)
                        ? ((fullYTotalRevenueDiff / fullYTotalRevenueAOP * 100).toFixed(1))
                        : 0) < 0 ? 'negative' : 'positive'}">${(fullYTotalRevenueAOP !== 0) && (fullYTotalRevenueDiff && fullYTotalRevenueAOP)
                        ? ((fullYTotalRevenueDiff / fullYTotalRevenueAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(fullYTotalRevenuePreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenuePreActuals).toLocaleString()}</td>
            <td class="${Number(fullYTotalRevenueVariance) < 0 ? 'negative' : 'positive'}">${Math.round(fullYTotalRevenueVariance).toLocaleString()}</td>
            <td class="${Number((fullYTotalRevenuePreActuals !== 0) && (fullYTotalRevenueVariance && fullYTotalRevenuePreActuals)
                ? ((fullYTotalRevenueVariance / fullYTotalRevenuePreActuals * 100).toFixed(1))
                : 0) < 0 ? 'negative' : 'positive'}">${(fullYTotalRevenuePreActuals !== 0) && (fullYTotalRevenueVariance && fullYTotalRevenuePreActuals)
                ? ((fullYTotalRevenueVariance / fullYTotalRevenuePreActuals * 100).toFixed(1) + '%')
                : '0%'}</td>
                </tr>`;
        }
        else if (classification === 'Other expenses') {
            fullYNetProfitActuals = (fullYGrossMarginActuals + fullYOtherIncomeTotalActuals) - 
                (fullYOperatingExpensesActualTotal + fullYOtherOperatingExpensesActualTotal + fullYOtherExpensesTotalActuals);
            fullYNetProfitAOP = (fullYGrossMarginAOP + fullYOtherIncomeTotalAOP) - 
                (fullYOperatingExpensesAOPTotal + fullYOtherOperatingExpensesAOPTotal + fullYOtherExpensesTotalAOP);
            fullYNetProfitDiff = fullYNetProfitActuals - fullYNetProfitAOP;

            fullYNetProfitPreActuals= (fullYGrossMarginPreActuals + fullYOtherIncomeTotalPreActuals) - 
            (fullYOperatingExpensesPreActuals + fullYOtherOperatingExpensesPreActuals + fullYOtherExpensesPreActuals);

            fullNetProfitVariance =fullYNetProfitActuals - fullYNetProfitPreActuals;

            fullYHtml += `
            <tr class="total-row">
            <td>TOTAL ${classification}</td>
            <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
            <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
            <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
              <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
        <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
        </tr>
                <tr class="summary-rows">
                    <td>NET PROFIT</td>
                    <td class="${Number(fullYNetProfitActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitActuals).toLocaleString()}</td>
                    <td class="${Number(fullYNetProfitAOP) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitAOP).toLocaleString()}</td>
                    <td class="${Number(fullYNetProfitDiff) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitDiff).toLocaleString()}</td>
                    <td class="${Number((fullYNetProfitAOP !== 0) && (fullYNetProfitDiff && fullYNetProfitAOP)
                        ? ((fullYNetProfitDiff / fullYNetProfitAOP * 100).toFixed(1))
                        : 0) < 0 ? 'negative' : 'positive'}">${(fullYNetProfitAOP !== 0) && (fullYNetProfitDiff && fullYNetProfitAOP)
                        ? ((fullYNetProfitDiff / fullYNetProfitAOP * 100).toFixed(1) + '%')
                        : '0%'}</td>
                        <td class="${Number(fullYNetProfitPreActuals) < 0 ? 'negative' : 'positive'}">${Math.round(fullYNetProfitPreActuals).toLocaleString()}</td>
            <td class="${Number(fullNetProfitVariance) < 0 ? 'negative' : 'positive'}">${Math.round(fullNetProfitVariance).toLocaleString()}</td>
            <td class="${Number((fullYNetProfitPreActuals !== 0) && (fullNetProfitVariance && fullYNetProfitPreActuals)
                ? ((fullNetProfitVariance / fullYNetProfitPreActuals * 100).toFixed(1))
                : 0) < 0 ? 'negative' : 'positive'}">${(fullYNetProfitPreActuals !== 0) && (fullNetProfitVariance && fullYNetProfitPreActuals)
                ? ((fullNetProfitVariance / fullYNetProfitPreActuals * 100).toFixed(1) + '%')
                : '0%'}</td>
                </tr>`


        
    }
    else if(classification === 'OPERATING EXPENSES'){
        fullYHtml += `
    <tr class="total-row">
        <td>HEADCOUNT COST</td>
        <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
        <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
        <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
        <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent} %</td>
         <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
            <td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
            <td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent} %</td>
    </tr>`;
    }
else{
    fullYHtml += `
    <tr class="total-row">
    <td>TOTAL ${classification}</td>
    <td class="${Number(classificationTotal.actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.actuals).toLocaleString()}</td>
    <td class="${Number(classificationTotal.aop) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.aop).toLocaleString()}</td>
    <td class="${Number(classificationTotal.difference) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.difference).toLocaleString()}</td>
    <td class="${Number(totalVariancePercent) < 0 ? 'negative' : 'positive'}">${totalVariancePercent}</td>
      <td class="${Number(classificationTotal.pre_actuals) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_actuals).toLocaleString()}</td>
<td class="${Number(classificationTotal.pre_variance) < 0 ? 'negative' : 'positive'}">${Math.round(classificationTotal.pre_variance).toLocaleString()}</td>
<td class="${Number(totalPrevVarPercent) < 0 ? 'negative' : 'positive'}">${totalPrevVarPercent}</td>
</tr>`;
}


  
    }



    

    // Rest of the classification total and summary rows remain unchanged
    // ... (keep the existing code for classification totals and summary rows)

    fullYHtml += `<tr class="classification-section"><td colspan="8">CONTRACTED ARR ($)</td></tr>
    ${arrPart}
    <tr class="arrtable">
        <td>ARR Net New Bookings (MRR from SF x 12)</td>
        <td class="${Number(fullYnetNewActualsSum) < 0 ? 'negative' : 'positive'}">${Math.round(fullYnetNewActualsSum).toLocaleString()}</td>
        <td class="${Number(fullYnetNewAopSum) < 0 ? 'negative' : 'positive'}">${Math.round(fullYnetNewAopSum).toLocaleString()}</td>
        <td class="${Number(fullYnetNewActualsSum - fullYnetNewAopSum) < 0 ? 'negative' : 'positive'}">${Math.round(fullYnetNewActualsSum - fullYnetNewAopSum).toLocaleString()}</td>
        <td class="${((fullYnetNewActualsSum - fullYnetNewAopSum) / fullYnetNewAopSum) < 0 ? 'negative' : 'positive'}">
            ${(fullYnetNewAopSum !== 0) && (fullYnetNewActualsSum && fullYnetNewAopSum)
                ? ((fullYnetNewActualsSum - fullYnetNewAopSum) / fullYnetNewAopSum * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="total-row">
        <td>Total Contracted ARR</td>
        <td class="${Number(contractedActualsTotal) < 0 ? 'negative' : 'positive'}">${Math.round(contractedActualsTotal).toLocaleString()}</td>
        <td class="${Number(contractedAopTotal) < 0 ? 'negative' : 'positive'}">${Math.round(contractedAopTotal).toLocaleString()}</td>
        <td class="${Number(contractedVariance) < 0 ? 'negative' : 'positive'}">${Math.round(contractedVariance).toLocaleString()}</td>
        <td class="${((contractedActualsTotal - contractedAopTotal) / contractedAopTotal) < 0 ? 'negative' : 'positive'}">
            ${(contractedAopTotal !== 0) && (contractedActualsTotal && contractedAopTotal)
                ? ((contractedActualsTotal - contractedAopTotal) / contractedAopTotal * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="classification-section"><td colspan="8">CLIENT DATA</td></tr>
    
    <tr class="client-data">
        <td>New Clients</td>
        <td class="${Number(fullYnewClientsAct) < 0 ? 'negative' : 'positive'}">${fullYnewClientsAct || 0}</td>
        <td class="${Number(fullYnewClientsAop) < 0 ? 'negative' : 'positive'}">${fullYnewClientsAop || 0}</td>
        <td class="${Number(fullYnewClientsAct - fullYnewClientsAop) < 0 ? 'negative' : 'positive'}">${Number(fullYnewClientsAct) - Number(fullYnewClientsAop) || 0}</td>
        <td class="${((fullYnewClientsAct - fullYnewClientsAop) / fullYnewClientsAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYnewClientsAop !== 0 ) && (fullYnewClientsAct && fullYnewClientsAop)
                ? ((fullYnewClientsAct - fullYnewClientsAop) / fullYnewClientsAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="client-data">
        <td>Attrition</td>
        <td class="${Number(fullYattritionAct) < 0 ? 'negative' : 'positive'}">${fullYattritionAct || 0}</td>
        <td class="${Number(fullYattritionAop) < 0 ? 'negative' : 'positive'}">${fullYattritionAop || 0}</td>
        <td class="${Number(fullYattritionAct - fullYattritionAop) < 0 ? 'negative' : 'positive'}">${Number(fullYattritionAct) - Number(fullYattritionAop) || 0}</td>
        <td class="${((fullYattritionAct - fullYattritionAop) / fullYattritionAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYattritionAop !== 0) && (fullYattritionAct && fullYattritionAop)
                ? ((fullYattritionAct - fullYattritionAop) / fullYattritionAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="client-data">
        <td>Existing</td>
        <td class="${Number(fullYexistingAct) < 0 ? 'negative' : 'positive'}">${fullYexistingAct || 0}</td>
        <td class="${Number(fullYexistingAop) < 0 ? 'negative' : 'positive'}">${fullYexistingAop || 0}</td>
        <td class="${Number(fullYexistingAct - fullYexistingAop) < 0 ? 'negative' : 'positive'}">${Number(fullYexistingAct) - Number(fullYexistingAop) || 0}</td>
        <td class="${((fullYexistingAct - fullYexistingAop) / fullYexistingAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYexistingAop !== 0) && (fullYexistingAct && fullYexistingAop)
                ? ((fullYexistingAct - fullYexistingAop) / fullYexistingAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="total-row">
        <td>Total Clients</td>
        <td class="${Number(fullYtotalClientsAct) < 0 ? 'negative' : 'positive'}">${fullYtotalClientsAct || 0}</td>
        <td class="${Number(fullYtotalClientsAop) < 0 ? 'negative' : 'positive'}">${fullYtotalClientsAop || 0}</td>
        <td class="${Number(fullYtotalClientsAct - fullYtotalClientsAop) < 0 ? 'negative' : 'positive'}">${Number(fullYtotalClientsAct) - Number(fullYtotalClientsAop) || 0}</td>
        <td class="${((fullYtotalClientsAct - fullYtotalClientsAop) / fullYtotalClientsAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYtotalClientsAop !== 0) && (fullYtotalClientsAct && fullYtotalClientsAop)
                ? ((fullYtotalClientsAct - fullYtotalClientsAop) / fullYtotalClientsAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="classification-section"><td colspan="8">HEADCOUNT</td></tr>
    
    <tr class="parent-row">
        <td>Sales and Marketing</td>
        <td class="${Number(fullYsalesAndMarketingActuals) < 0 ? 'negative' : 'positive'}">${fullYsalesAndMarketingActuals}</td>
        <td class="${Number(fullYsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${fullYsalesAndMarketingAop}</td>
        <td class="${Number(fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">${fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop}</td>
        <td class="${((fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop) / fullYsalesAndMarketingAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYsalesAndMarketingAop !== 0) && (fullYsalesAndMarketingActuals && fullYsalesAndMarketingAop)
                ? ((fullYsalesAndMarketingActuals - fullYsalesAndMarketingAop) / fullYsalesAndMarketingAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>Product</td>
        <td class="${Number(fullYproductActuals) < 0 ? 'negative' : 'positive'}">${fullYproductActuals}</td>
        <td class="${Number(fullYproductAop) < 0 ? 'negative' : 'positive'}">${fullYproductAop}</td>
        <td class="${Number(fullYproductActuals - fullYproductAop) < 0 ? 'negative' : 'positive'}">${fullYproductActuals - fullYproductAop}</td>
        <td class="${((fullYproductActuals - fullYproductAop) / fullYproductAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYproductAop !== 0) && (fullYproductActuals && fullYproductAop)
                ? ((fullYproductActuals - fullYproductAop) / fullYproductAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>General &amp; Administrative</td>
        <td class="${Number(fullYgeneraladminActuals) < 0 ? 'negative' : 'positive'}">${fullYgeneraladminActuals}</td>
        <td class="${Number(fullYgeneralAdminAop) < 0 ? 'negative' : 'positive'}">${fullYgeneralAdminAop}</td>
        <td class="${Number(fullYgeneraladminActuals - fullYgeneralAdminAop) < 0 ? 'negative' : 'positive'}">${fullYgeneraladminActuals - fullYgeneralAdminAop}</td>
        <td class="${((fullYgeneraladminActuals - fullYgeneralAdminAop) / fullYgeneralAdminAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYgeneralAdminAop !== 0) && (fullYgeneraladminActuals && fullYgeneralAdminAop)
                ? ((fullYgeneraladminActuals - fullYgeneralAdminAop) / fullYgeneralAdminAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>Customer Success</td>
        <td class="${Number(fullYcustomersuccessActuals) < 0 ? 'negative' : 'positive'}">${fullYcustomersuccessActuals}</td>
        <td class="${Number(fullYcustomersuccessAop) < 0 ? 'negative' : 'positive'}">${fullYcustomersuccessAop}</td>
        <td class="${Number(fullYcustomersuccessActuals - fullYcustomersuccessAop) < 0 ? 'negative' : 'positive'}">${fullYcustomersuccessActuals - fullYcustomersuccessAop}</td>
        <td class="${((fullYcustomersuccessActuals - fullYcustomersuccessAop) / fullYcustomersuccessAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYcustomersuccessAop !== 0) && (fullYcustomersuccessActuals && fullYcustomersuccessAop)
                ? ((fullYcustomersuccessActuals - fullYcustomersuccessAop) / fullYcustomersuccessAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="parent-row">
        <td>R &amp; D</td>
        <td class="${Number(fullYranddActuals) < 0 ? 'negative' : 'positive'}">${fullYranddActuals}</td>
        <td class="${Number(fullYranddAop) < 0 ? 'negative' : 'positive'}">${fullYranddAop}</td>
        <td class="${Number(fullYranddActuals - fullYranddAop) < 0 ? 'negative' : 'positive'}">${fullYranddActuals - fullYranddAop}</td>
        <td class="${((fullYranddActuals - fullYranddAop) / fullYranddAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYranddAop !== 0) && (fullYranddActuals && fullYranddAop)
                ? ((fullYranddActuals - fullYranddAop) / fullYranddAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    
    <tr class="total-row">
        <td>HeadCount Total</td>
        <td class="${Number(fullYheadcounttotalActuals) < 0 ? 'negative' : 'positive'}">${fullYheadcounttotalActuals}</td>
        <td class="${Number(fullYheadcounttotalAop) < 0 ? 'negative' : 'positive'}">${fullYheadcounttotalAop}</td>
        <td class="${Number(fullYheadcounttotalActuals - fullYheadcounttotalAop) < 0 ? 'negative' : 'positive'}">${fullYheadcounttotalActuals - fullYheadcounttotalAop}</td>
        <td class="${((fullYheadcounttotalActuals - fullYheadcounttotalAop) / fullYheadcounttotalAop) < 0 ? 'negative' : 'positive'}">
            ${(fullYheadcounttotalAop !== 0) && (fullYheadcounttotalActuals && fullYheadcounttotalAop)
                ? ((fullYheadcounttotalActuals - fullYheadcounttotalAop) / fullYheadcounttotalAop * 100).toFixed(1) + '%' 
                : '0%'}</td>
        <td></td><td></td><td></td>
    </tr>
    </table><script>
                    function printPDF() { window.print(); }
    let isExpanded = false;
    function toggleAllRows() {
        const allRows = document.querySelectorAll('[data-group]');
        allRows.forEach(row => {
            if (isExpanded) {
                row.style.display = 'none';
            } else {
                row.style.display = 'table-row';
            }
        });
        const buttons = document.querySelectorAll('.toggle-button, .subcategory-toggle');
        console.log('Toggle All: Found', buttons.length, 'buttons'); // Debug log
        buttons.forEach(button => {
            button.textContent = isExpanded ? '+' : '-';
            button.classList.toggle('plus-state', button.textContent === '+');
        });
        isExpanded = !isExpanded;
        document.getElementById('toggleAllBtn').title = isExpanded ? "Collapse All" : "Expand All";
        document.getElementById('toggleAllBtn').textContent = isExpanded ? '+' : '-';
    }
    function toggleRows(group, btn) {
        const rows = document.querySelectorAll('[data-group="' + group + '"]');
        console.log('Toggle Rows: Group', group, 'Found', rows.length, 'rows'); // Debug log
        const isVisible = rows.length > 0 && rows[0].style.display === 'table-row';
        rows.forEach(row => {
            row.style.display = isVisible ? 'none' : 'table-row';
        });
        btn.textContent = isVisible ? '+' : '-';
        btn.classList.toggle('plus-state', btn.textContent === '+');
        console.log('Button classes:', btn.className); // Debug log
    }
</script></body></html>`;
    return fullYHtml;
    

    }
    function getFinancialYearMonthsFullYear(monthPeriodId) {
        try {
            // Step 1: Get the parent quarter and financial year
            var accountingperiodSearch = search.create({
                type: "accountingperiod",
                filters: [
                    ["internalid", "anyof", monthPeriodId]
                ],
                columns: [
                    search.createColumn({ name: "parent" }) // Quarter ID
                ]
            });

            var quarterId, financialYearId, financialYearName;

            accountingperiodSearch.run().each(function (result) {
                quarterId = result.getValue({ name: "parent" }); // Get quarter
                return true;
            });

            if (!quarterId) {
                log.error("Quarter Not Found", "Could not determine the quarter for the selected month.");
                return [];
            }

            // Step 2: Get the financial year (parent of the quarter)
            var quarterSearch = search.create({
                type: "accountingperiod",
                filters: [
                    ["internalid", "anyof", quarterId]
                ],
                columns: [
                    search.createColumn({ name: "parent" }) // Financial Year ID
                ]
            });

            quarterSearch.run().each(function (result) {
                financialYearId = result.getValue({ name: "parent" }); // Get Financial Year ID
                financialYearName=result.getText({name: "parent"});
                return true;
            });

            if (!financialYearId) {
                log.error("Financial Year Not Found", "Could not determine the financial year.");
                return [];
            }

            // Step 3: Get all months within the financial year
            var monthIds = [];
            var financialYearSearch = search.create({
                type: "accountingperiod",
                filters: [
                    ["parent", "anyof", financialYearId], // Filter by financial year
                    "AND",
                    ["isquarter", "is", "F"], // Ensure only months, not quarters
                    "AND",
                    ["isyear", "is", "F"] // Exclude full-year periods
                ],
                columns: [
                    search.createColumn({ name: "internalid", sort: search.Sort.ASC })
                ]
            });

            financialYearSearch.run().each(function (result) {
                monthIds.push(result.getValue({ name: "internalid" }));
                return true;
            });

            log.debug("Financial Year Month IDs", monthIds);
            return {monthIds: monthIds, financialYearName: financialYearName};

        } catch (error) {
            log.error('Error Processing Request', error);
            return [];
        }
    }

   
    
    function getPreviousYearAccountingPeriods(currentPeriodIds) {
        var previousPeriodInternalIds = []; // Array to store previous year period IDs

        for (var i = 0; i < currentPeriodIds.length; i++) {
            log.debug("passed internl id to find prev month qtd",currentPeriodIds[i])
            var accountingperiodSearchObj = search.create({
                type: "accountingperiod",
                filters: [
                    ["internalid", "is", currentPeriodIds[i]] // Fetch period one by one
                ],
                columns: [
                    search.createColumn({ name: "periodname", label: "Name" })
                ]
            });
    
            var previousYearPeriodName = null;
    if(accountingperiodSearchObj){
            // Extract period name and derive previous year period
            accountingperiodSearchObj.run().each(function (result) {
                var periodName = result.getValue("periodname"); // e.g., "Apr 2024"
                var parts = periodName.split(" "); // ["Apr", "2024"]
    
                if (parts.length === 2) {
                    var month = parts[0]; // "Apr"
                    var year = parseInt(parts[1]); // 2024
                    var prevYear = year - 1; // 2023
                    previousYearPeriodName = month + " " + prevYear; // "Apr 2023"
                }
    
                return false; // Stop after the first match
            });
        }
    
            if (previousYearPeriodName) {
                var prevYearSearchObj = search.create({
                    type: "accountingperiod",
                    filters: [
                        ["periodname", "is", previousYearPeriodName] // Search for "Apr 2023"
                    ],
                    columns: [
                        search.createColumn({ name: "internalid", label: "Internal ID" })
                    ]
                });
    
                // Fetch internal ID for previous year period
                prevYearSearchObj.run().each(function (result) {
                    var prevYearInternalId = result.getValue("internalid");
                    previousPeriodInternalIds.push(prevYearInternalId);
                    return false; // Stop after first match
                });
                
            }
        }
    
        return previousPeriodInternalIds.length > 0 ? previousPeriodInternalIds : null;
    }

    return { onRequest };
});




